#!/usr/bin/env bash
# =============================================================================
# WTM（战雷手游语音包管理器）—— 无 Gradle APK 构建脚本
#
# 接口契约（Lead 直接调用，默认值即契约；可用同名环境变量覆盖，smoke 因此复用同一流水线）：
#   输入 : $WTM_APP_DIR/AndroidManifest.xml、res/**、assets/**（可选）、java/**/*.java
#   库   : $WTM_LIBS_DIR/*.jar（可选，没有就跳过）
#   输出 : $WTM_DIST_DIR/$WTM_APK_NAME
#   中间 : $WTM_BUILD_DIR/**（保留，便于排查）
#
# 用法：
#   bash /root/workspace/wtm/build.sh
#   失败时非零退出，并在 stderr 打印失败行号与命令。
# =============================================================================
set -Eeuo pipefail
trap 'printf "[build] ❌ 第 %s 行失败: %s\n" "$LINENO" "$BASH_COMMAND" >&2' ERR

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT=${WTM_ROOT:-$SCRIPT_DIR}
APP_DIR=${WTM_APP_DIR:-$ROOT/app/src/main}
BUILD_DIR=${WTM_BUILD_DIR:-$ROOT/build}
LIBS_DIR=${WTM_LIBS_DIR:-$ROOT/libs}
ANDROID_JAR=${WTM_ANDROID_JAR:-/opt/android-sdk/platforms/android-34/android.jar}
R8_JAR=${WTM_R8_JAR:-/opt/android-sdk/r8/r8.jar}
KEYSTORE=${WTM_KEYSTORE:-$ROOT/keystore/wtmvoice.jks}
KEYSTORE_PASS=${WTM_KEYSTORE_PASS:-android}
KEY_ALIAS=${WTM_KEY_ALIAS:-wtmvoice}
DIST_DIR=${WTM_DIST_DIR:-$ROOT/dist}
APK_NAME=${WTM_APK_NAME:-战雷手游语音包管理器.apk}
MIN_API=${WTM_MIN_API:-24}

MANIFEST=$APP_DIR/AndroidManifest.xml
RES_DIR=$APP_DIR/res
JAVA_DIR=$APP_DIR/java
ASSETS_DIR=$APP_DIR/assets
GEN_DIR=$BUILD_DIR/gen
CLASSES_DIR=$BUILD_DIR/classes
DEX_DIR=$BUILD_DIR/dex
BASE_APK=$BUILD_DIR/base.apk
CLASSES_JAR=$BUILD_DIR/classes.jar
UNSIGNED_APK=$BUILD_DIR/unsigned.apk
ALIGNED_APK=$BUILD_DIR/aligned.apk
OUT_APK=$DIST_DIR/$APK_NAME

log()   { printf '[build] %s\n' "$*"; }
step()  { printf '\n[build] ===== %s =====\n' "$*"; }
warn()  { printf '[build] ⚠️  %s\n' "$*" >&2; }
die()   { printf '[build] ❌ %s\n' "$*" >&2; exit 1; }
need()  { command -v "$1" >/dev/null 2>&1 || die "缺少命令 $1 —— 先执行 bash $ROOT/toolchain/setup.sh"; }

# ---------------------------------------------------------------------------
# 0) 前置检查
# ---------------------------------------------------------------------------
step "0/7 前置检查"
need java; need javac; need aapt; need zip; need unzip; need zipalign; need apksigner
[ -f "$MANIFEST" ]   || die "找不到 AndroidManifest.xml: $MANIFEST"
[ -d "$RES_DIR" ]    || die "找不到资源目录: $RES_DIR"
[ -d "$JAVA_DIR" ]   || die "找不到 Java 源码目录: $JAVA_DIR"
[ -s "$ANDROID_JAR" ] || die "找不到 android.jar: $ANDROID_JAR（先跑 toolchain/setup.sh）"
PKG_NAME=$(sed -n 's/.*[[:space:]<]package="\([^"]*\)".*/\1/p' "$MANIFEST" | head -1)
[ -n "$PKG_NAME" ] || die "无法从 manifest 解析 package 属性"
log "应用包名: $PKG_NAME"
log "android.jar: $ANDROID_JAR"
log "输出: $OUT_APK"

rm -rf "$GEN_DIR" "$CLASSES_DIR" "$DEX_DIR" "$CLASSES_JAR"
mkdir -p "$GEN_DIR" "$CLASSES_DIR" "$DEX_DIR" "$DIST_DIR"

# ---------------------------------------------------------------------------
# 1/7 aapt 打包资源 + 生成 R.java
# ---------------------------------------------------------------------------
step "1/7 aapt 打包资源（aapt v1）"
AAPT_ARGS=(-f -J "$GEN_DIR" -M "$MANIFEST" -S "$RES_DIR" -I "$ANDROID_JAR" -F "$BASE_APK")
if [ -d "$ASSETS_DIR" ]; then
  log "包含 assets: $ASSETS_DIR"
  AAPT_ARGS+=(-A "$ASSETS_DIR")
else
  log "无 assets 目录，跳过 -A"
fi
aapt package "${AAPT_ARGS[@]}" 2>&1 | tee "$BUILD_DIR/aapt.log"
[ -f "$BASE_APK" ] || die "aapt 未产出 $BASE_APK"
[ -f "$GEN_DIR/$PKG_NAME/R.java" ] || warn "没找到 $GEN_DIR/$PKG_NAME/R.java（若源码不用 R 可忽略）"
log "✓ base.apk: $(du -h "$BASE_APK" | cut -f1)"

# ---------------------------------------------------------------------------
# 2/7 javac 编译 Java（Java 8 语言级别 + android.jar 当 bootclasspath）
# ---------------------------------------------------------------------------
step "2/7 javac 编译"
mapfile -t SRC_FILES < <(find "$JAVA_DIR" -type f -name '*.java' | sort)
# aapt 生成的 R.java 也是源码，必须一起编译（它在 $GEN_DIR 里，不在 java/ 下）
while IFS= read -r _r; do SRC_FILES+=("$_r"); done < <(find "$GEN_DIR" -type f -name '*.java' 2>/dev/null)
[ ${#SRC_FILES[@]} -gt 0 ] || die "$JAVA_DIR 下没有 .java 文件"
log "源码 ${#SRC_FILES[@]} 个"

# JDK17 的 --release 与 -bootclasspath 互斥，这里探针一次决定用哪组参数
PROBE=$(mktemp -d)
printf 'class __WtmProbe {}\n' > "$PROBE/__WtmProbe.java"
JAVAC_FLAGS=()
if javac --release 8 -bootclasspath "$ANDROID_JAR" -d "$PROBE" "$PROBE/__WtmProbe.java" >/dev/null 2>&1; then
  JAVAC_FLAGS=(--release 8 -bootclasspath "$ANDROID_JAR")
else
  JAVAC_FLAGS=(-source 8 -target 8 -bootclasspath "$ANDROID_JAR" -Xlint:-options)
  javac "${JAVAC_FLAGS[@]}" -d "$PROBE" "$PROBE/__WtmProbe.java" >/dev/null 2>&1 \
    || die "javac 无法组合出 Java8 + android.jar bootclasspath 的编译参数"
fi
rm -rf "$PROBE"
log "javac 参数: ${JAVAC_FLAGS[*]}"

jcp="$GEN_DIR"
if [ -d "$LIBS_DIR" ] && compgen -G "$LIBS_DIR/*.jar" >/dev/null; then
  jcp="$LIBS_DIR/*:$GEN_DIR"
  log "classpath 含 $LIBS_DIR/*.jar"
fi
if ! javac -J-Xmx512m "${JAVAC_FLAGS[@]}" -encoding UTF-8 -d "$CLASSES_DIR" -cp "$jcp" "${SRC_FILES[@]}" \
      2>&1 | tee "$BUILD_DIR/javac.log"; then
  die "javac 编译失败（详见 $BUILD_DIR/javac.log）"
fi
[ -d "$CLASSES_DIR" ] || die "javac 未产出 class 文件"
log "✓ 编译产物: $(find "$CLASSES_DIR" -name '*.class' | wc -l) 个 class"

# ---------------------------------------------------------------------------
# 2.5/7 依赖完整性自检（历史上漏过 shizuku-aidl/shared，真机上才炸）
# ---------------------------------------------------------------------------
if command -v jdeps >/dev/null 2>&1 && [ -d "$LIBS_DIR" ]; then
  SHIZUKU_JARS=$(ls "$LIBS_DIR"/shizuku-*.jar 2>/dev/null | tr '\n' ':' || true)
  if [ -n "$SHIZUKU_JARS" ]; then
    CP_CHK="${SHIZUKU_JARS}${ANDROID_JAR}"
    MISSING=$(jdeps -verbose:class -cp "$CP_CHK" "$LIBS_DIR"/shizuku-api.jar 2>/dev/null \
      | grep 'not found' | grep -v 'androidx\.' | grep -v '^shizuku-api.jar' || true)
    if [ -n "$MISSING" ]; then
      warn "Shizuku 相关类有缺失依赖（真机上可能报「Shizuku 库缺失」）："
      printf '%s\n' "$MISSING" | sed 's/^/    /' >&2
      warn "检查 libs/ 是否漏了 shizuku-aidl.jar / shizuku-shared.jar（跑 toolchain/setup.sh 会补齐）"
    else
      log "✓ Shizuku 依赖自检通过"
    fi
  fi
fi

# ---------------------------------------------------------------------------
# 3/7 d8 dex
# ---------------------------------------------------------------------------
step "3/7 d8 dex（min-api $MIN_API）"
jar --create --file "$CLASSES_JAR" -C "$CLASSES_DIR" . || die "打包 classes.jar 失败"
DEX_IN=("$CLASSES_JAR")
if [ -d "$LIBS_DIR" ]; then
  for j in "$LIBS_DIR"/*.jar; do [ -e "$j" ] && DEX_IN+=("$j"); done
fi
log "dex 输入: ${#DEX_IN[@]} 个条目"
DEX_OK=0
if [ -s "$R8_JAR" ]; then
  if java -Xmx512m -cp "$R8_JAR" com.android.tools.r8.D8 \
        --min-api "$MIN_API" --lib "$ANDROID_JAR" --release \
        --output "$DEX_DIR" "${DEX_IN[@]}" 2>&1 | tee "$BUILD_DIR/d8.log"; then
    [ -f "$DEX_DIR/classes.dex" ] && DEX_OK=1
  else
    warn "d8 失败，尝试兜底工具（详见 $BUILD_DIR/d8.log）"
  fi
else
  warn "没有 $R8_JAR，尝试兜底工具"
fi
if [ "$DEX_OK" -ne 1 ]; then
  if command -v dalvik-exchange >/dev/null 2>&1; then
    log "兜底: dalvik-exchange (dx)"
    dalvik-exchange --dex --min-sdk-version="$MIN_API" --output="$DEX_DIR/classes.dex" "${DEX_IN[@]}" \
      2>&1 | tee "$BUILD_DIR/dx.log" || die "dalvik-exchange 也失败了"
  elif command -v dx >/dev/null 2>&1; then
    log "兜底: dx"
    dx --dex --min-sdk-version="$MIN_API" --output="$DEX_DIR/classes.dex" "${DEX_IN[@]}" \
      2>&1 | tee "$BUILD_DIR/dx.log" || die "dx 也失败了"
  elif command -v d8 >/dev/null 2>&1; then
    log "兜底: 系统 d8"
    d8 --min-api "$MIN_API" --lib "$ANDROID_JAR" --release --output "$DEX_DIR" "${DEX_IN[@]}" \
      2>&1 | tee "$BUILD_DIR/d8.log" || die "系统 d8 也失败了"
  else
    die "没有可用的 dex 工具（r8/d8/dalvik-exchange 都不可用）"
  fi
  [ -f "$DEX_DIR/classes.dex" ] || die "没有产出 classes.dex"
fi
log "✓ classes.dex: $(du -h "$DEX_DIR/classes.dex" | cut -f1)"

# ---------------------------------------------------------------------------
# 4/7 把 classes.dex 塞进 base.apk
# ---------------------------------------------------------------------------
step "4/7 合并 classes.dex 进 APK"
cp -f "$BASE_APK" "$UNSIGNED_APK"
zip -q -j "$UNSIGNED_APK" "$DEX_DIR/classes.dex" || die "zip 追加 classes.dex 失败"
unzip -l "$UNSIGNED_APK" | grep -q 'classes\.dex' || die "unsigned.apk 里没有 classes.dex"
unzip -l "$UNSIGNED_APK" | grep -q 'resources\.arsc' || warn "unsigned.apk 里没有 resources.arsc（aapt 没打进资源？）"
log "✓ 含 classes.dex + resources.arsc"

# ---------------------------------------------------------------------------
# 5/7 zipalign
# ---------------------------------------------------------------------------
step "5/7 zipalign -p 4"
zipalign -p -f 4 "$UNSIGNED_APK" "$ALIGNED_APK" || die "zipalign 失败"
zipalign -c -p 4 "$ALIGNED_APK" || die "zipalign 校验失败"
log "✓ 对齐完成"

# ---------------------------------------------------------------------------
# 6/7 keystore（不存在则生成）
# ---------------------------------------------------------------------------
step "6/7 keystore"
mkdir -p "$(dirname "$KEYSTORE")"
if [ ! -s "$KEYSTORE" ]; then
  log "生成 $KEYSTORE (alias=$KEY_ALIAS, pass=$KEYSTORE_PASS, CN=WTMVoice)"
  # 用 JKS（而非 JDK17 默认 PKCS12），保证 apksigner --ks 与 keypass 组合最兼容
  keytool -genkeypair -keystore "$KEYSTORE" -storetype JKS \
    -storepass "$KEYSTORE_PASS" -keypass "$KEYSTORE_PASS" \
    -alias "$KEY_ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=WTMVoice" -noprompt || die "keytool 生成 keystore 失败"
else
  log "复用已有 keystore"
fi

# ---------------------------------------------------------------------------
# 7/7 签名 + 自检
# ---------------------------------------------------------------------------
step "7/7 apksigner 签名"
apksigner sign \
  --ks "$KEYSTORE" --ks-key-alias "$KEY_ALIAS" \
  --ks-pass "pass:$KEYSTORE_PASS" --key-pass "pass:$KEYSTORE_PASS" \
  --min-sdk-version "$MIN_API" \
  --out "$OUT_APK" "$ALIGNED_APK" || die "apksigner sign 失败"
[ -s "$OUT_APK" ] || die "签名后没有产出 APK"

apksigner verify --verbose "$OUT_APK" 2>&1 | tee "$BUILD_DIR/sign-verify.log" \
  || die "apksigner verify 失败（详见 $BUILD_DIR/sign-verify.log）"
aapt dump badging "$OUT_APK" 2>&1 | sed -n '1,6p' || true

printf '\n[build] ✅ 构建完成: %s (%s)\n' "$OUT_APK" "$(du -h "$OUT_APK" | cut -f1)"
printf '[build]    中间产物保留在: %s\n' "$BUILD_DIR"
exit 0
