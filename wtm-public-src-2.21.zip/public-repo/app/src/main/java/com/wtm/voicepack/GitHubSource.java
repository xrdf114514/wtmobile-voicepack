package com.wtm.voicepack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * GitHub Release 源：不用自己搭服务器，也没有 index.json 要维护。
 *
 * 制作者只要把成品 zip 传到仓库的 Release，用户在这里填 `github:用户/仓库`
 * （或直接填 https://github.com/用户/仓库），就能列出所有 Release 附件直接下载。
 *
 * 用的是 GitHub 公开 API：GET https://api.github.com/repos/{owner}/{repo}/releases?per_page=30
 * 未登录每小时 60 次，正常浏览够用；附件下载走 github.com/.../releases/download/... 直链。
 */
public final class GitHubSource {

    public static final String API = "https://api.github.com/repos/";
    public static final String NAME = "GitHub";

    private GitHubSource() {
    }

    /** 支持 `github:owner/repo`、`https://github.com/owner/repo`、带 /releases 后缀。 */
    public static String normalizeRepo(String input) {
        if (input == null) return null;
        String s = input.trim();
        if (s.length() == 0) return null;
        if (s.startsWith("github:")) {
            return cleanRepo(s.substring("github:".length()));
        }
        String lower = s.toLowerCase(Locale.US);
        if (lower.startsWith("https://github.com/") || lower.startsWith("http://github.com/")) {
            String rest = s.substring(s.indexOf("github.com/") + "github.com/".length());
            String r = rest.endsWith("/") ? rest.substring(0, rest.length() - 1) : rest;
            String[] parts = r.split("/");
            // 只认 /owner/repo 或 /owner/repo/releases...；
            // /owner/repo/raw/main/index.json 这类是普通 json 地址，交给 json 源处理
            if (parts.length == 2) return cleanRepo(rest);
            if (parts.length >= 3 && parts[2].toLowerCase(Locale.US).startsWith("releases")) {
                return cleanRepo(rest);
            }
            return null;
        }
        return null;
    }

    private static String cleanRepo(String rest) {
        String r = rest.trim();
        if (r.endsWith("/")) r = r.substring(0, r.length() - 1);
        int cut = r.indexOf("/releases");
        if (cut > 0) r = r.substring(0, cut);
        // 只接受 owner/repo 两段
        String[] parts = r.split("/");
        if (parts.length < 2) return null;
        String owner = parts[0].trim();
        String repo = parts[1].trim();
        if (owner.length() == 0 || repo.length() == 0) return null;
        if (!owner.matches("[A-Za-z0-9_.-]+") || !repo.matches("[A-Za-z0-9_.-]+")) return null;
        return owner + "/" + repo;
    }

    public static List<OnlinePack> fetch(String repo, String search) throws Exception {
        String json = Net.get(API + repo + "/releases?per_page=30", null);
        return parse(repo, json, search);
    }

    public static List<OnlinePack> parse(String repo, String json, String search) throws Exception {
        List<OnlinePack> out = new ArrayList<OnlinePack>();
        JSONArray releases;
        if (json.trim().startsWith("[")) {
            releases = new JSONArray(json);
        } else {
            JSONObject o = new JSONObject(json);
            if (o.has("message")) throw new Exception("GitHub 返回：" + o.optString("message"));
            releases = new JSONArray();
        }

        String q = search == null ? "" : search.trim().toLowerCase(Locale.US);
        if (q.startsWith("#")) q = q.substring(1);

        for (int i = 0; i < releases.length() && out.size() < 200; i++) {
            JSONObject rel = releases.optJSONObject(i);
            if (rel == null) continue;
            if (rel.optBoolean("draft", false)) continue;
            String tag = rel.optString("tag_name", rel.optString("name", ""));
            String published = rel.optString("published_at", "");
            if (published.length() > 10) published = published.substring(0, 10);
            JSONArray assets = rel.optJSONArray("assets");
            if (assets == null) continue;
            for (int k = 0; k < assets.length(); k++) {
                JSONObject a = assets.optJSONObject(k);
                if (a == null) continue;
                String name = a.optString("name", "");
                String url = a.optString("browser_download_url", "");
                if (name.length() == 0 || url.length() == 0) continue;
                String lower = name.toLowerCase(Locale.US);
                boolean archive = lower.endsWith(".zip") || lower.endsWith(".bank")
                        || lower.endsWith(".7z") || lower.endsWith(".rar");
                if (!archive) continue;

                OnlinePack p = new OnlinePack();
                p.source = NAME + " · " + repo;
                p.sourceType = "github";
                p.id = repo + "@" + k + "@" + tag;
                p.url = url;
                p.size = a.optLong("size", 0);
                p.title = WtLive.prettyTitle(name);
                StringBuilder note = new StringBuilder();
                if (tag.length() > 0) note.append(tag);
                if (published.length() > 0) {
                    if (note.length() > 0) note.append(" · ");
                    note.append(published);
                }
                p.note = note.toString();
                p.pageUrl = "https://github.com/" + repo + "/releases";

                if (q.length() > 0) {
                    String hay = (name + " " + tag + " " + repo).toLowerCase(Locale.US);
                    if (!hay.contains(q)) continue;
                }
                out.add(p);
            }
        }
        return out;
    }
}
