package com.wtm.voicepack;

import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 启动自检：检查游戏 mod 目录里的文件是不是「同一套语音包」，有没有重复/残留/和记录对不上。
 *
 * 为什么要做：换包是「先清旧再写新」，但用户手动复制、旧版本写错位置、换包中途失败、
 * 或者把别的包的文件塞进去，都会让目录变成"混着好几套"的状态——游戏里就会出现
 * 一部分是新语音、一部分是旧的，很难自己查出来。这里在每次启动时静默查一遍。
 *
 * 实现尽量便宜：先按文件名/大小和库里每个包的记录比对，只有发现大小相同的疑似重复
 * 才去算 md5，避免每次启动都把几百 MB 全哈希一遍。
 */
public final class ModCheck {

    public static final class Issue {
        public boolean hasProblem = false;
        public boolean mixed = false;          // 混了多个语音包的文件
        public int unknown = 0;                // 不属于库里任何包的文件
        public int duplicates = 0;             // 内容重复的文件（多出来的那份算重复）
        public boolean mismatch = false;       // 和「当前生效」记录对不上
        public boolean near = false;           // 和库里某个包是"增量/减量"关系（一方是另一方的真子集）
        public String nearPackId = "";
        public String nearPackName = "";
        public int nearMissing = 0;            // 库里那个包比目录多的文件数
        public int nearExtra = 0;              // 目录比库里那个包多的文件数
        public int unsaved = 0;                // 目录里不属于任何库包的文件数
        public String appliedName = "";
        public boolean appliedPackMissing = false;
        public final List<String> detail = new ArrayList<String>();
        public int total = 0;

        public String summary() {
            StringBuilder sb = new StringBuilder();
            if (total == 0) {
                sb.append("游戏目录里现在没有自制语音文件（游戏用原版语音）。");
            } else {
                sb.append("游戏目录里共 ").append(total).append(" 个 .bank");
                if (appliedName.length() > 0 && !mismatch) {
                    sb.append("，和「").append(appliedName).append("」一致");
                }
                sb.append("。");
            }
            if (mixed) sb.append("\n· 混了多个语音包的文件");
            if (unknown > 0) sb.append("\n· ").append(unknown).append(" 个文件不属于语音包库里的任何包");
            if (duplicates > 0) sb.append("\n· ").append(duplicates).append(" 个文件内容重复");
            if (mismatch) sb.append("\n· 与「当前生效」记录不一致");
            if (appliedPackMissing) sb.append("\n· 记录里的语音包已不在库中");
            return sb.toString();
        }
    }

    private ModCheck() {
    }

    /** 需要权限通道；没通道直接返回 null（不打扰用户）。 */
    public static Issue check(Context c) {
        if (!Access.ready()) return null;
        try {
            Issue is = new Issue();
            List<String> modBanks = GameDir.listBanks(c);
            is.total = modBanks.size();
            List<Pack> packs = PackStore.list(c);

            String appliedId = Prefs.appliedId(c);
            is.appliedName = Prefs.appliedName(c);
            Pack applied = null;
            if (appliedId != null && appliedId.length() > 0) {
                applied = PackStore.findById(c, appliedId);
                if (applied == null) is.appliedPackMissing = true;
            }

            if (modBanks.isEmpty()) {
                // 目录空的：如果记录说应用了，就是不一致
                if (appliedId != null && appliedId.length() > 0) {
                    is.hasProblem = true;
                    is.mismatch = true;
                    is.detail.add("记录显示正在使用「" + is.appliedName + "」，但目录里没有文件");
                }
                return is;
            }

            // 库里每个包：文件名 -> 大小
            Map<String, Map<String, Long>> packFiles = new HashMap<String, Map<String, Long>>();
            for (Pack p : packs) {
                Map<String, Long> m = new HashMap<String, Long>();
                for (String b : p.banks) {
                    m.put(b, new File(p.banksDir(c), b).length());
                }
                packFiles.put(p.id, m);
            }

            // 目录里文件的大小（一次 shell 拿全，避免逐个 spawn）
            Map<String, Long> sizes = statSizes(c, modBanks);

            // 目录里的文件逐个和库里所有包比对（名字 + 大小）
            List<String> unknownNames = new ArrayList<String>();
            for (String name : modBanks) {
                boolean found = false;
                Long sz = sizes.get(name);
                for (Map<String, Long> m : packFiles.values()) {
                    Long expect = m.get(name);
                    if (expect == null) continue;
                    if (sz == null || sz < 0 || expect.equals(sz)) {
                        found = true;
                        break;
                    }
                }
                if (!found) unknownNames.add(name);
            }

            // 找和目录最贴的包：先看有没有「完全一样」的，再找增量/减量关系。
            // 注意：只有「文件全在 + 多/少几个」才算 near；某个小包的文件刚好是全集的子集时
            // 不能算 near（否则目录和另一个包完全一致也会被误报）。
            String bestId = null;
            int bestHit = -1;
            int bestMissing = 0;
            int bestExtra = 0;
            boolean exact = false;
            int partial = 0;
            List<String> partialIds = new ArrayList<String>();
            for (Pack p : packs) {
                Map<String, Long> m = packFiles.get(p.id);
                int hit = 0;
                for (String b : p.banks) {
                    if (!modBanks.contains(b)) continue;
                    Long sz = sizes.get(b);
                    Long expect = (m == null) ? null : m.get(b);
                    if (sz != null && sz >= 0 && expect != null && !expect.equals(sz)) continue;
                    hit++;
                }
                if (hit <= 0) continue;
                partial++;
                partialIds.add(p.id);
                int missing = p.banks.size() - hit;          // 包有、目录没有
                int extra = modBanks.size() - hit;           // 目录有、包没有
                if (missing == 0 && extra == 0) {
                    exact = true;
                    bestId = p.id;
                    bestHit = hit;
                    bestMissing = 0;
                    bestExtra = 0;
                    break;
                }
                if ((missing == 0 || extra == 0) && hit > bestHit) {
                    bestHit = hit;
                    bestId = p.id;
                    bestMissing = missing;
                    bestExtra = extra;
                }
            }

            // 完全一样：不打扰用户（这是最常见的正常状态）
            if (exact) {
                is.mixed = false;
                is.unknown = 0;
                is.unsaved = 0;
                is.duplicates = 0;
                is.mismatch = false;
                is.near = false;
                is.hasProblem = false;
                return is;
            }

            is.unknown = unknownNames.size();
            is.unsaved = unknownNames.size();
            is.mixed = partial > 1;
            if (bestId != null) {
                Pack bp = PackStore.findById(c, bestId);
                is.near = true;
                is.nearPackId = bestId;
                is.nearPackName = bp == null ? bestId : bp.name;
                is.nearMissing = bestMissing;
                is.nearExtra = bestExtra;
            }

            is.hasProblem = is.mixed || is.unknown > 0 || is.duplicates > 0 || is.mismatch
                    || is.near || is.unsaved > 0;
            if (is.mixed) {
                StringBuilder names = new StringBuilder();
                int n = 0;
                for (String id : partialIds) {
                    Pack p = PackStore.findById(c, id);
                    if (n++ > 0) names.append("、");
                    if (n > 3) {
                        names.append("…");
                        break;
                    }
                    names.append(p == null ? id : p.name);
                }
                is.detail.add("对上了多个包：" + names);
            }
            if (is.unknown > 0) {
                StringBuilder sb = new StringBuilder("不认识的文件：");
                int n = 0;
                for (String s : unknownNames) {
                    if (n++ >= 3) {
                        sb.append("…等 ").append(unknownNames.size()).append(" 个");
                        break;
                    }
                    if (n > 1) sb.append("、");
                    sb.append(s);
                }
                is.detail.add(sb.toString());
            }
            return is;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 一次 shell 拿所有文件大小。 */
    private static Map<String, Long> statSizes(Context c, List<String> names) {
        Map<String, Long> out = new HashMap<String, Long>();
        if (names.isEmpty()) return out;
        if (GameDir.isDirect()) {
            for (String n : names) {
                File f = new File(GameDir.modDir(c), n);
                out.put(n, f.length());
            }
            return out;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("M=").append(GameDir.q(GameDir.modDir(c))).append("; ");
        for (String n : names) {
            if (n == null || n.length() == 0) continue;
            String safe = n.replace(":", "_");
            sb.append("echo \"F:").append(safe).append(":$(wc -c < \"$M/")
                    .append(escapeDq(n)).append("\" 2>/dev/null)\"; ");
        }
        Access.Result r = Access.sh(sb.toString());
        if (r.out != null) {
            for (String line : r.out.split("\n")) {
                String s = line.trim();
                if (!s.startsWith("F:")) continue;
                int cut = s.lastIndexOf(':');
                if (cut <= 2) continue;
                String name = s.substring(2, cut);
                try {
                    out.put(name, Long.parseLong(s.substring(cut + 1).trim()));
                } catch (Throwable ignored) {
                }
            }
        }
        return out;
    }

    private static String escapeDq(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("$", "\\$").replace("`", "\\`");
    }

    /** 检查结果转成给用户看的说明。 */
    public static String report(Issue is) {
        StringBuilder sb = new StringBuilder();
        sb.append(is.summary());
        for (String d : is.detail) sb.append('\n').append("· ").append(d);
        return sb.toString();
    }
}
