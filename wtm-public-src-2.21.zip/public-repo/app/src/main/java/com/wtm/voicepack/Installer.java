package com.wtm.voicepack;

import android.app.Activity;
import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 换包执行器。
 *
 * 流程（尽量保证「失败不会把旧语音搞没」）：
 *   1. 确认权限 + 目录可写
 *   2. 把新包的 .bank 上传到 sound/.wtm_upload 并逐个校验大小
 *   3. 校验全通过后：删掉 mod 里不属于新包的旧 .bank，再把 upload 里的文件 mv 进去
 *   4. 复查 mod 目录，文件齐了才记「已应用」
 *
 * 库里永远只有一份内容，游戏目录里也只有当前这一套，所以换多少次都不会越换越多。
 */
public final class Installer {

    public interface Listener {
        void onProgress(String text);

        void onDone(boolean ok, String message);
    }

    public static final class Outcome {
        public final boolean ok;
        public final String msg;

        Outcome(boolean ok, String msg) {
            this.ok = ok;
            this.msg = msg == null ? "" : msg;
        }
    }

    private Installer() {
    }

    private static Outcome ok(String msg) {
        return new Outcome(true, msg);
    }

    private static Outcome fail(String msg) {
        return new Outcome(false, msg);
    }

    private static void post(Context c, Listener l, String s) {
        if (l == null) return;
        final Listener ll = l;
        final String msg = s;
        if (c instanceof Activity) {
            ((Activity) c).runOnUiThread(new Runnable() {
                public void run() {
                    ll.onProgress(msg);
                }
            });
        } else {
            ll.onProgress(msg);
        }
    }

    private static void done(Context c, final Listener l, final boolean ok, final String msg) {
        if (l == null) return;
        if (c instanceof Activity) {
            ((Activity) c).runOnUiThread(new Runnable() {
                public void run() {
                    l.onDone(ok, msg);
                }
            });
        } else {
            l.onDone(ok, msg);
        }
    }

    /** 目标目录里那些「不是本软件写的」.bank —— 换包前提醒用户会被清理掉。 */
    public static List<String> unknownBanks(Context c) {
        List<String> existing = GameDir.listBanks(c);
        List<String> mine = Prefs.writtenFiles(c);
        List<String> out = new ArrayList<String>();
        for (String s : existing) {
            if (!mine.contains(s)) out.add(s);
        }
        return out;
    }

    /** 同步换包（后台线程调用）。 */
    public static Outcome applySync(Context c, Pack p, Listener l) {
        if (p == null) return fail("语音包不存在");
        if (!Access.ready()) return fail("还没有权限通道，先回首页启用 Shizuku 或 root");

        File banks = p.banksDir(c);
        File[] files = banks.listFiles();
        if (files == null || files.length == 0) return fail("语音包文件丢了，建议删掉后重新导入");

        final List<File> srcs = new ArrayList<File>();
        final List<String> names = new ArrayList<String>();
        for (File f : files) {
            if (f.isFile() && f.getName().toLowerCase().endsWith(".bank")) {
                srcs.add(f);
                names.add(f.getName());
            }
        }
        if (srcs.isEmpty()) return fail("这个语音包里没有 .bank 文件");

        post(c, l, "检查目标目录…");
        if (!GameDir.ensureModDir(c)) {
            return fail("创建目标目录失败：\n" + GameDir.modDir(c) + "\n请确认已授权，且游戏包名配置正确");
        }
        if (!GameDir.probeWritable(c)) {
            return fail("目标目录不可写，请检查权限通道（Shizuku 是否还在运行）");
        }

        post(c, l, "上传 " + srcs.size() + " 个语音文件（" + Kit.fmtSize(p.size) + "）…");
        if (!GameDir.prepareStaging(c)) return fail("临时目录创建失败，请检查权限通道");
        int pushed = GameDir.pushToStaging(c, srcs);
        if (pushed < srcs.size()) {
            GameDir.cleanStaging(c);
            return fail("只成功写入 " + pushed + "/" + srcs.size()
                    + " 个文件，旧语音没有改动。\n多半是空间不足或权限被回收，清点空间后重试。");
        }

        post(c, l, "替换旧的语音文件…");
        if (!GameDir.commitStaging(c, names)) {
            GameDir.cleanStaging(c);
            return fail("替换失败，旧语音可能已被部分清理。\n可以重试一次，或点首页「恢复原版」。");
        }
        GameDir.cleanStaging(c);

        // 复查
        List<String> inGame = GameDir.listBanks(c);
        int missing = 0;
        for (String n : names) {
            if (!inGame.contains(n)) missing++;
        }
        if (missing > 0) {
            return fail("写入不完整：应有 " + names.size() + " 个，实际少 " + missing + " 个。\n建议重试一次。");
        }

        Prefs.setApplied(c, p.id, p.name, names.size());
        // 只记录「本次写入的文件」，不能把目录里别人的文件也算成自己的
        Prefs.setWrittenFiles(c, names);
        PackStore.markApplied(c, p);
        Prefs.bumpApplyCount(c);

        return ok("已应用到游戏：" + p.name + "\n"
                + names.size() + " 个文件 · " + Kit.fmtSize(p.size) + "\n"
                + "旧的 .bank 已清理，目录里只剩这一套语音");
    }

    /** 后台线程换包。 */
    public static void applyAsync(final Context appCtx, final Pack p, final Listener l) {
        new Thread(new Runnable() {
            public void run() {
                Outcome o;
                try {
                    o = applySync(appCtx, p, l);
                } catch (Throwable t) {
                    o = fail("换包异常：" + t);
                }
                done(appCtx, l, o.ok, o.msg);
            }
        }, "wtm-apply").start();
    }

    /** 恢复原版：删掉 mod 里的 .bank，游戏就会用回原版语音。 */
    public static void restoreAsync(final Context appCtx, final Listener l) {
        new Thread(new Runnable() {
            public void run() {
                String msg;
                boolean ok = false;
                try {
                    if (!Access.ready()) {
                        msg = "还没有权限通道，先回首页启用 Shizuku 或 root";
                    } else if (!GameDir.modDirExists(appCtx)) {
                        msg = "mod 目录本来就不存在，游戏现在用的就是原版语音";
                        ok = true;
                    } else {
                        int n = GameDir.clearBanks(appCtx);
                        if (n < 0) {
                            msg = "有文件删不掉，请检查权限通道后重试";
                        } else {
                            Prefs.clearApplied(appCtx);
                            Prefs.setWrittenFiles(appCtx, new ArrayList<String>());
                            msg = "已清空 mod 目录里的 " + n + " 个语音文件，游戏恢复原版语音";
                            ok = true;
                        }
                    }
                } catch (Throwable t) {
                    msg = "操作异常：" + t;
                }
                done(appCtx, l, ok, msg);
            }
        }, "wtm-restore").start();
    }
}
