package com.wtm.voicepack;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** 语音包库：检索、排序、收藏、应用、重命名、删除。 */
public final class LibraryActivity extends Activity {

    public static final String EXTRA_PICK = "pick_mode";

    private EditText etSearch;
    private TextView btnSort, btnFav, tvStat, btnRight, btnBack, tvTitle, btnImportHere, tvEmpty;
    private ListView listPacks;
    private View emptyBox;

    private final List<Pack> all = new ArrayList<Pack>();
    private final List<Pack> shown = new ArrayList<Pack>();
    private PackAdapter adapter;

    private int sort = 0;       // 0 名称 1 大小 2 时间
    private boolean favOnly = false;
    private boolean pickMode = false;
    private boolean selecting = false;
    private TextView btnBackup;
    private TextView btnMulti, tvBatchInfo, btnSelectAll, btnBatchFav, btnBatchExport,
            btnBatchDel, btnBatchDone;
    private View batchBar;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private static final String[] SORT_NAMES = {"名称", "大小", "最近"};
    private static final int REQ_RESTORE = 2401;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_library);

        pickMode = getIntent().getBooleanExtra(EXTRA_PICK, false);

        tvTitle = (TextView) findViewById(R.id.tvTitle);
        btnBack = (TextView) findViewById(R.id.btnBack);
        btnRight = (TextView) findViewById(R.id.btnRight);
        etSearch = (EditText) findViewById(R.id.etSearch);
        btnSort = (TextView) findViewById(R.id.btnSort);
        btnFav = (TextView) findViewById(R.id.btnFav);
        tvStat = (TextView) findViewById(R.id.tvStat);
        listPacks = (ListView) findViewById(R.id.listPacks);
        emptyBox = findViewById(R.id.emptyBox);
        tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        btnImportHere = (TextView) findViewById(R.id.btnImportHere);
        btnMulti = (TextView) findViewById(R.id.btnMulti);
        btnBackup = (TextView) findViewById(R.id.btnBackup);
        batchBar = findViewById(R.id.batchBar);
        tvBatchInfo = (TextView) findViewById(R.id.tvBatchInfo);
        btnSelectAll = (TextView) findViewById(R.id.btnSelectAll);
        btnBatchFav = (TextView) findViewById(R.id.btnBatchFav);
        btnBatchExport = (TextView) findViewById(R.id.btnBatchExport);
        btnBatchDel = (TextView) findViewById(R.id.btnBatchDel);
        btnBatchDone = (TextView) findViewById(R.id.btnBatchDone);

        if (pickMode) btnMulti.setVisibility(View.GONE);
        if (btnBackup != null) {
            btnBackup.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    showBackupDialog();
                }
            });
        }
        btnMulti.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (selecting) exitSelect();
                else enterSelect();
            }
        });
        btnSelectAll.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (adapter.selectedIds().size() >= shown.size()) adapter.clearSelection();
                else adapter.selectAll(shown);
                updateBatchUi();
            }
        });
        btnBatchFav.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                batchFavorite();
            }
        });
        btnBatchExport.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                batchExport();
            }
        });
        btnBatchDel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                batchDelete();
            }
        });
        btnBatchDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                exitSelect();
            }
        });

        tvTitle.setText(pickMode ? "选一个语音包" : "语音包库");
        if (pickMode) tvEmpty.setText("库里还没有语音包，先导入一个吧");

        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        btnRight.setText("导入");
        btnRight.setVisibility(View.VISIBLE);
        btnRight.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(LibraryActivity.this, ImportActivity.class));
            }
        });
        btnImportHere.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(LibraryActivity.this, ImportActivity.class));
            }
        });

        btnSort.setText(SORT_NAMES[sort]);
        btnSort.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sort = (sort + 1) % SORT_NAMES.length;
                btnSort.setText(SORT_NAMES[sort]);
                rebuild();
            }
        });

        styleChip(btnFav, favOnly);
        btnFav.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                favOnly = !favOnly;
                styleChip(btnFav, favOnly);
                rebuild();
            }
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b2, int c) {
            }

            public void afterTextChanged(Editable s) {
                rebuild();
            }
        });

        adapter = new PackAdapter(this);
        listPacks.setAdapter(adapter);
        listPacks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                if (pos < 0 || pos >= shown.size()) return;
                Pack p = shown.get(pos);
                if (selecting) {
                    adapter.toggle(p.id);
                    updateBatchUi();
                    return;
                }
                if (pickMode) {
                    confirmApply(p);
                } else {
                    showDetail(p);
                }
            }
        });
        listPacks.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> parent, View view, int pos, long id) {
                if (pos < 0 || pos >= shown.size()) return false;
                Pack p = shown.get(pos);
                if (selecting) {
                    adapter.toggle(p.id);
                    updateBatchUi();
                } else {
                    showQuickActions(p);
                }
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void styleChip(TextView tv, boolean on) {
        GradientDrawable g = Kit.round(this, on ? 0x33F5B324 : 0x00000000, 16, on ? 0xFFF5B324 : 0xFF2A3644);
        if (on) g.setColor(0x33F5B324);
        tv.setBackground(g);
        tv.setTextColor(on ? getResources().getColor(R.color.gold) : getResources().getColor(R.color.sub));
    }

    // ------------------------------------------------------------------ 备份 / 迁移

    /**
     * 整库备份与恢复。
     * 语音包在应用私有目录里，APK 不包含它们；想"把库发给对方/换手机带走"就走这里。
     */
    private void showBackupDialog() {
        final String[] items = new String[]{
                "📦 导出整库 + 安装包（一个文件带走）",
                "📦 导出整库（只含语音包）",
                "📂 从备份文件恢复整库"
        };
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle("备份 / 迁移");
        b.setMessage("把当前 " + all.size() + " 个语音包打包成一个 zip。"
                + "在另一台设备上用本软件「从备份文件恢复整库」就能全部还原（名称/备注/标签/收藏都在）。\n\n"
                + "⚠️ 转发前确认你有权传播这些包；付费或他人作品别随便发。");
        b.setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 2) {
                    pickRestoreFile();
                } else {
                    doExportLibrary(which == 0);
                }
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    private void doExportLibrary(final boolean includeApk) {
        if (all.isEmpty()) {
            Kit.toast(this, "库里还没有语音包");
            return;
        }
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("正在打包…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        new Thread(new Runnable() {
            public void run() {
                File zip = null;
                String err = null;
                android.net.Uri shareUri = null;
                String where = null;
                try {
                    zip = LibraryBackup.exportAll(LibraryActivity.this, includeApk,
                            new LibraryBackup.Progress() {
                                public void onStep(final String text) {
                                    ui.post(new Runnable() {
                                        public void run() {
                                            try {
                                                pd.setMessage(text);
                                            } catch (Throwable ignored) {
                                            }
                                        }
                                    });
                                }
                            });
                    shareUri = SaveToDownload.saveAndGetUri(LibraryActivity.this, zip,
                            LibraryBackup.suggestName());
                    if (shareUri == null) {
                        where = SaveToDownload.save(LibraryActivity.this, zip, LibraryBackup.suggestName());
                    } else {
                        where = "Download/" + LibraryBackup.suggestName();
                    }
                } catch (Throwable t) {
                    String m = t.getMessage();
                    err = (m == null || m.length() == 0) ? t.toString() : m;
                } finally {
                    if (zip != null) //noinspection ResultOfMethodCallIgnored
                        zip.delete();
                }
                final String fErr = err;
                final String fWhere = where;
                final android.net.Uri fUri = shareUri;
                final boolean fApk = includeApk;
                ui.post(new Runnable() {
                    public void run() {
                        try {
                            pd.dismiss();
                        } catch (Throwable ignored) {
                        }
                        if (!Kit.alive(LibraryActivity.this)) return;
                        if (fErr != null) {
                            Kit.msg(LibraryActivity.this, "打包失败", fErr);
                            return;
                        }
                        AlertDialog.Builder b = new AlertDialog.Builder(LibraryActivity.this, R.style.DialogTheme);
                        b.setTitle("打包完成");
                        b.setMessage("已保存到 " + fWhere + "\n"
                                + (fApk ? "里面带了安装包 app.apk，另一台设备装上它再恢复就行。\n" : "")
                                + "\n要直接分享出去吗？");
                        b.setPositiveButton("分享出去", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                if (fUri == null) {
                                    Kit.msg(LibraryActivity.this, "直接分享不可用",
                                            "这台设备不支持应用内分享，去下载目录里发送即可：\n" + fWhere);
                                    return;
                                }
                                try {
                                    android.content.Intent send = new android.content.Intent(android.content.Intent.ACTION_SEND);
                                    send.setType("application/zip");
                                    send.putExtra(android.content.Intent.EXTRA_STREAM, fUri);
                                    send.putExtra(android.content.Intent.EXTRA_SUBJECT, "战雷手游语音包库备份");
                                    send.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    startActivity(android.content.Intent.createChooser(send, "分享语音包库"));
                                } catch (Throwable t) {
                                    Kit.msg(LibraryActivity.this, "分享失败", t.toString());
                                }
                            }
                        });
                        b.setNegativeButton("完成", null);
                        b.show();
                    }
                });
            }
        }, "wtm-lib-export").start();
    }

    private void pickRestoreFile() {
        android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_RESTORE);
        } catch (Throwable t) {
            Kit.msg(this, "打不开文件选择器", t.toString());
        }
    }

    @Override
    protected void onActivityResult(int req, int res, android.content.Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_RESTORE || res != RESULT_OK || data == null || data.getData() == null) return;
        final android.net.Uri uri = data.getData();
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("正在恢复…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        new Thread(new Runnable() {
            public void run() {
                LibraryBackup.Result r = null;
                String err = null;
                try {
                    r = LibraryBackup.importAll(LibraryActivity.this, uri,
                            new LibraryBackup.Progress() {
                                public void onStep(final String text) {
                                    ui.post(new Runnable() {
                                        public void run() {
                                            try {
                                                pd.setMessage(text);
                                            } catch (Throwable ignored) {
                                            }
                                        }
                                    });
                                }
                            });
                } catch (Throwable t) {
                    String m = t.getMessage();
                    err = (m == null || m.length() == 0) ? t.toString() : m;
                }
                final LibraryBackup.Result fr = r;
                final String fErr = err;
                ui.post(new Runnable() {
                    public void run() {
                        try {
                            pd.dismiss();
                        } catch (Throwable ignored) {
                        }
                        if (!Kit.alive(LibraryActivity.this)) return;
                        if (fErr != null) {
                            Kit.msg(LibraryActivity.this, "恢复失败", fErr);
                            return;
                        }
                        StringBuilder sb = new StringBuilder();
                        sb.append("新导入：").append(fr.imported).append(" 个\n");
                        sb.append("跳过重复：").append(fr.duplicated).append(" 个（内容一样，不重复占空间）");
                        if (fr.failed > 0) sb.append("\n失败：").append(fr.failed).append(" 个");
                        Kit.msg(LibraryActivity.this, "恢复完成", sb.toString());
                        reload();
                    }
                });
            }
        }, "wtm-lib-import").start();
    }

    // ------------------------------------------------------------------ 多选

    private void enterSelect() {
        selecting = true;
        adapter.setSelecting(true);
        adapter.clearSelection();
        if (batchBar != null) batchBar.setVisibility(View.VISIBLE);
        updateBatchUi();
        Kit.toast(this, "点条目勾选，长按也能勾");
    }

    private void exitSelect() {
        selecting = false;
        adapter.setSelecting(false);
        adapter.clearSelection();
        if (batchBar != null) batchBar.setVisibility(View.GONE);
        updateBatchUi();
    }

    private void updateBatchUi() {
        int n = adapter.selectedIds().size();
        if (tvBatchInfo != null) tvBatchInfo.setText("已选 " + n + " 个");
        if (btnMulti != null) {
            btnMulti.setText(selecting ? "取消" : "多选");
            btnMulti.setTextColor(getResources().getColor(selecting ? R.color.gold : R.color.sub));
        }
        if (btnSelectAll != null) {
            btnSelectAll.setText(n >= shown.size() && shown.size() > 0 ? "全不选" : "全选");
        }
    }

    private List<Pack> selectedPacks() {
        List<Pack> out = new ArrayList<Pack>();
        for (Pack p : all) {
            if (adapter.selectedIds().contains(p.id)) out.add(p);
        }
        return out;
    }

    private void batchFavorite() {
        final List<Pack> targets = selectedPacks();
        if (targets.isEmpty()) {
            Kit.toast(this, "先勾选语音包");
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                for (Pack p : targets) PackStore.setFavorite(LibraryActivity.this, p, true);
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(LibraryActivity.this)) return;
                        Kit.toast(LibraryActivity.this, "已收藏 " + targets.size() + " 个");
                        exitSelect();
                        reload();
                    }
                });
            }
        }, "wtm-batch-fav").start();
    }

    private void batchExport() {
        final List<Pack> targets = selectedPacks();
        if (targets.isEmpty()) {
            Kit.toast(this, "先勾选语音包");
            return;
        }
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("导出中…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        new Thread(new Runnable() {
            public void run() {
                int ok = 0;
                String firstErr = null;
                for (int i = 0; i < targets.size(); i++) {
                    final String msg = "导出中 " + (i + 1) + "/" + targets.size();
                    ui.post(new Runnable() {
                        public void run() {
                            try {
                                pd.setMessage(msg);
                            } catch (Throwable ignored) {
                            }
                        }
                    });
                    Pack p = targets.get(i);
                    File zip = null;
                    try {
                        zip = ExportUtil.toZip(LibraryActivity.this, p);
                        SaveToDownload.save(LibraryActivity.this, zip, p.name + ".zip");
                        ok++;
                    } catch (Throwable t) {
                        if (firstErr == null) {
                            String m = t.getMessage();
                            firstErr = (m == null || m.length() == 0) ? t.toString() : m;
                        }
                    } finally {
                        if (zip != null) //noinspection ResultOfMethodCallIgnored
                            zip.delete();
                    }
                }
                final int fOk = ok;
                final String fErr = firstErr;
                ui.post(new Runnable() {
                    public void run() {
                        try {
                            pd.dismiss();
                        } catch (Throwable ignored) {
                        }
                        if (!Kit.alive(LibraryActivity.this)) return;
                        if (fErr != null) {
                            Kit.msg(LibraryActivity.this, "导出完成 " + fOk + " 个（有失败）",
                                    "第一个错误：" + fErr);
                        } else {
                            Kit.msg(LibraryActivity.this, "已导出 " + fOk + " 个到下载目录", "");
                        }
                        exitSelect();
                    }
                });
            }
        }, "wtm-batch-export").start();
    }

    private void batchDelete() {
        final List<Pack> targets = selectedPacks();
        if (targets.isEmpty()) {
            Kit.toast(this, "先勾选语音包");
            return;
        }
        Kit.confirm(this, "删除 " + targets.size() + " 个语音包",
                "只删库里的，游戏目录里的文件不动（想还原就用首页「恢复原版」）。", "删除", new Runnable() {
                    public void run() {
                        new Thread(new Runnable() {
                            public void run() {
                                String appliedId = Prefs.appliedId(LibraryActivity.this);
                                for (Pack p : targets) {
                                    PackStore.delete(LibraryActivity.this, p);
                                    if (p.id != null && p.id.equals(appliedId)) {
                                        Prefs.clearApplied(LibraryActivity.this);
                                    }
                                }
                                ui.post(new Runnable() {
                                    public void run() {
                                        if (!Kit.alive(LibraryActivity.this)) return;
                                        Kit.toast(LibraryActivity.this, "已删除 " + targets.size() + " 个");
                                        exitSelect();
                                        reload();
                                    }
                                });
                            }
                        }, "wtm-batch-del").start();
                    }
                });
    }

    // ------------------------------------------------------------------ 数据

    private void reload() {
        new Thread(new Runnable() {
            public void run() {
                final List<Pack> list = PackStore.list(getApplicationContext());
                ui.post(new Runnable() {
                    public void run() {
                        all.clear();
                        all.addAll(list);
                        rebuild();
                    }
                });
            }
        }, "wtm-lib-load").start();
    }

    private void rebuild() {
        String q = etSearch.getText().toString().trim().toLowerCase(Locale.CHINA);
        shown.clear();
        for (Pack p : all) {
            if (favOnly && !p.favorite) continue;
            if (q.length() > 0) {
                String hay = (p.name + " " + p.note + " " + p.source + " " + p.tagsLine())
                        .toLowerCase(Locale.CHINA);
                if (!hay.contains(q)) continue;
            }
            shown.add(p);
        }
        sortList();
        adapter.setData(shown, Prefs.appliedId(this));

        if (selecting) updateBatchUi();
        boolean empty = shown.isEmpty();
        emptyBox.setVisibility(empty ? View.VISIBLE : View.GONE);
        listPacks.setVisibility(empty ? View.GONE : View.VISIBLE);
        long total = 0;
        for (Pack p : shown) total += p.size;
        tvStat.setText(shown.size() + " 个 · " + Kit.fmtSize(total));
        if (empty && all.isEmpty()) {
            tvEmpty.setText(pickMode ? "库里还没有语音包，先导入一个吧" : "这里还没有语音包");
        } else if (empty) {
            tvEmpty.setText(favOnly ? "收藏夹还是空的" : "没有匹配的语音包");
        }
    }

    private void sortList() {
        final Collator coll = Collator.getInstance(Locale.CHINA);
        Comparator<Pack> cmp;
        if (sort == 0) {
            cmp = new Comparator<Pack>() {
                public int compare(Pack a, Pack b) {
                    return coll.compare(a.name, b.name);
                }
            };
        } else if (sort == 1) {
            cmp = new Comparator<Pack>() {
                public int compare(Pack a, Pack b) {
                    return a.size == b.size ? 0 : (a.size > b.size ? -1 : 1);
                }
            };
        } else {
            cmp = new Comparator<Pack>() {
                public int compare(Pack a, Pack b) {
                    return a.addedAt == b.addedAt ? 0 : (a.addedAt > b.addedAt ? -1 : 1);
                }
            };
        }
        Collections.sort(shown, cmp);
    }

    // ------------------------------------------------------------------ 详情

    /** 点按：详情预览（应用 / 编辑 / 收藏 / 导出 / 复制指纹 / 删除都放这儿，一眼能看到）。 */
    private void showDetail(final Pack p) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_pack, null);
        TextView tvName = (TextView) view.findViewById(R.id.tvDName);
        TextView tvMeta = (TextView) view.findViewById(R.id.tvDMeta);
        TextView tvNote = (TextView) view.findViewById(R.id.tvDNote);
        TextView tvTags = (TextView) view.findViewById(R.id.tvDTags);
        TextView tvFiles = (TextView) view.findViewById(R.id.tvDFiles);

        tvName.setText(p.name);
        StringBuilder meta = new StringBuilder();
        meta.append(p.count).append(" 个语音文件 · ").append(Kit.fmtSize(p.size));
        meta.append("\n导入 ").append(Kit.fmtTime(p.addedAt));
        meta.append(" · 使用 ").append(p.lastAppliedAt == 0 ? "从未" : Kit.fmtAgo(p.lastAppliedAt));
        if (p.id.equals(Prefs.appliedId(this))) meta.append("\n● 正在游戏里生效");
        meta.append("\n指纹 ").append(p.id);
        tvMeta.setText(meta.toString());

        if (p.note != null && p.note.length() > 0) {
            tvNote.setVisibility(View.VISIBLE);
            tvNote.setText(p.note);
        }
        if (!p.tags.isEmpty()) {
            tvTags.setVisibility(View.VISIBLE);
            tvTags.setText("标签：" + p.tagsLine());
        }
        StringBuilder files = new StringBuilder("文件：");
        int n = 0;
        for (String f : p.banks) {
            if (n++ > 0) files.append("、");
            if (n > 6) {
                files.append("…等 ").append(p.banks.size()).append(" 个");
                break;
            }
            files.append(f);
        }
        tvFiles.setText(files.toString());

        final AlertDialog dlg = new AlertDialog.Builder(this, R.style.DialogTheme)
                .setView(view).setNegativeButton("关闭", null).create();
        view.findViewById(R.id.btnDApply).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dlg.dismiss();
                confirmApply(p);
            }
        });
        view.findViewById(R.id.btnDEdit).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dlg.dismiss();
                showEdit(p);
            }
        });
        final TextView fav = (TextView) view.findViewById(R.id.btnDFav);
        fav.setText(p.favorite ? "☆ 取消收藏" : "★ 收藏");
        fav.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // 注意：setFavorite 会把 p.favorite 改成"操作后"的值，
                // 所以提示文案必须用操作前记录的 wasFav，不能直接用 p.favorite
                boolean wasFav = p.favorite;
                boolean nowFav = !wasFav;
                PackStore.setFavorite(LibraryActivity.this, p, nowFav);
                fav.setText(nowFav ? "☆ 取消收藏" : "★ 收藏");
                Kit.toast(LibraryActivity.this, nowFav ? "已收藏" : "已取消收藏");
                reload();
            }
        });
        view.findViewById(R.id.btnDExport).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dlg.dismiss();
                showExport(p);
            }
        });
        view.findViewById(R.id.btnDCopy).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Kit.copy(LibraryActivity.this, p.id + "\n" + p.hash, "内容指纹");
            }
        });
        view.findViewById(R.id.btnDDel).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dlg.dismiss();
                confirmDelete(p);
            }
        });
        dlg.show();
    }

    /** 长按：快捷操作菜单（直接对包做动作，不是再看一遍详情）。 */
    private void showQuickActions(final Pack p) {
        final String[] items = new String[]{
                p.id.equals(Prefs.appliedId(this)) ? "⚡ 重新应用一次" : "⚡ 应用到游戏",
                "✏️ 编辑名称 / 备注 / 标签",
                p.favorite ? "☆ 取消收藏" : "★ 收藏",
                "📤 导出 / 分享",
                "📄 查看文件清单",
                "🗑️ 删除语音包"
        };
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle(p.name);
        b.setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                switch (which) {
                    case 0:
                        confirmApply(p);
                        break;
                    case 1:
                        showEdit(p);
                        break;
                    case 2:
                        boolean wasFav = p.favorite;
                        boolean nowFav = !wasFav;
                        PackStore.setFavorite(LibraryActivity.this, p, nowFav);
                        reload();
                        Kit.toast(LibraryActivity.this, nowFav ? "已收藏" : "已取消收藏");
                        break;
                    case 3:
                        showExport(p);
                        break;
                    case 4:
                        showFiles(p);
                        break;
                    case 5:
                        confirmDelete(p);
                        break;
                    default:
                        break;
                }
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    /** 编辑：名称 / 备注 / 标签（标签会进检索）。 */
    private void showEdit(final Pack p) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Kit.dp(this, 20);
        box.setPadding(pad, Kit.dp(this, 8), pad, 0);

        final EditText etN = editField("语音包名称", p.name, box, 0);
        final EditText etNote = editField("备注（作者 / 风格 / 来源）", p.note, box, 10);
        final EditText etTags = editField("标签（空格或逗号分隔，如：空战 中文）", p.tagsLine().replace("#", ""), box, 10);

        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle("编辑：「" + p.name + "」");
        b.setView(box);
        b.setNegativeButton("取消", null);
        b.setPositiveButton("保存", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                String nn = etN.getText().toString().trim();
                if (nn.length() == 0) nn = p.name;
                nn = PackStore.uniqueName(LibraryActivity.this, nn, p.id);
                String note = etNote.getText().toString().trim();
                java.util.List<String> tags = parseTags(etTags.getText().toString());
                if (PackStore.edit(LibraryActivity.this, p, nn, note, tags)) {
                    reload();
                    Kit.toast(LibraryActivity.this, "已保存");
                } else {
                    Kit.toast(LibraryActivity.this, "保存失败（存储空间？）");
                }
            }
        });
        b.show();
    }

    private EditText editField(String hint, String value, LinearLayout parent, int topMarginDp) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setSingleLine(true);
        et.setText(value == null ? "" : value);
        et.setBackgroundResource(R.drawable.input_bg);
        et.setPadding(Kit.dp(this, 14), Kit.dp(this, 10), Kit.dp(this, 14), Kit.dp(this, 10));
        et.setTextColor(getResources().getColor(R.color.text));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Kit.dp(this, topMarginDp);
        parent.addView(et, lp);
        return et;
    }

    /** 标签解析：空格/逗号/顿号/分号分隔，去重、限长、最多 8 个。 */
    static java.util.List<String> parseTags(String raw) {
        java.util.List<String> out = new java.util.ArrayList<String>();
        if (raw == null) return out;
        String[] parts = raw.split("[\\s,，、;；]+");
        for (String t : parts) {
            String v = t.trim().replace("#", "");
            if (v.length() == 0) continue;
            if (v.length() > 12) v = v.substring(0, 12);
            if (!out.contains(v)) out.add(v);
            if (out.size() >= 8) break;
        }
        return out;
    }

    /** 导出/分享：给自己存档、发给对方，或者做成订阅源里的成品包。 */
    private void showExport(final Pack p) {
        final String[] items = new String[]{
                "📥 保存 zip 到下载目录（存档 / 拷电脑）",
                "📤 分享给其它应用（QQ / 微信 / 网盘）",
                "📋 复制订阅源条目（index.json 用）"
        };
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle("导出 / 分享：「" + p.name + "」");
        b.setMessage("导出的 zip 里是 banks/*.bank + meta.json + README，别人用本软件能直接导入；"
                + "也可以当一个成品包，放进你自己的订阅源发给大家。\n\n"
                + "⚠️ 分享或发布前请确认你有权传播这个包：付费/售卖包通常不含再分发授权，"
                + "别人作品未经许可不要转卖或大范围传播（详见设置里的使用条款）。");
        b.setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, final int which) {
                new Thread(new Runnable() {
                    public void run() {
                        File zip = null;
                        String err = null;
                        String msg = null;
                        android.net.Uri shareUri = null;
                        try {
                            zip = ExportUtil.toZip(LibraryActivity.this, p);
                            if (which == 0) {
                                msg = "已保存到 " + SaveToDownload.save(LibraryActivity.this, zip, p.name + ".zip");
                            } else if (which == 1) {
                                shareUri = SaveToDownload.saveAndGetUri(LibraryActivity.this, zip, p.name + ".zip");
                                if (shareUri == null) {
                                    msg = "已保存到 " + SaveToDownload.save(LibraryActivity.this, zip, p.name + ".zip")
                                            + "\n（这台设备不支持直接分享，去下载目录里发送即可）";
                                }
                            } else {
                                msg = ExportUtil.indexEntry(LibraryActivity.this, p, zip);
                            }
                        } catch (Throwable t) {
                            String m = t.getMessage();
                            err = (m == null || m.length() == 0) ? t.toString() : m;
                        } finally {
                            if (zip != null) zip.delete();
                        }
                        final String fErr = err;
                        final String fMsg = msg;
                        final android.net.Uri fUri = shareUri;
                        runOnUiThread(new Runnable() {
                            public void run() {
                                if (!Kit.alive(LibraryActivity.this)) return;
                                if (fErr != null) {
                                    Kit.msg(LibraryActivity.this, "导出失败", fErr);
                                    return;
                                }
                                if (which == 2) {
                                    Kit.copy(LibraryActivity.this, fMsg, " index.json 条目");
                                    Kit.msg(LibraryActivity.this, "已复制到剪贴板",
                                            "把它贴进订阅源的 packs 数组，再把 url 换成本包的直链就行。\n\n" + cut(fMsg));
                                    return;
                                }
                                if (fUri != null) {
                                    try {
                                        android.content.Intent send = new android.content.Intent(android.content.Intent.ACTION_SEND);
                                        send.setType("application/zip");
                                        send.putExtra(android.content.Intent.EXTRA_STREAM, fUri);
                                        send.putExtra(android.content.Intent.EXTRA_SUBJECT, p.name);
                                        send.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                        startActivity(android.content.Intent.createChooser(send, "分享语音包"));
                                        return;
                                    } catch (Throwable t) {
                                        Kit.msg(LibraryActivity.this, "分享失败", t.toString());
                                        return;
                                    }
                                }
                                Kit.msg(LibraryActivity.this, "完成", fMsg);
                            }
                        });
                    }
                }, "wtm-export").start();
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    private static String cut(String s) {
        if (s == null) return "";
        return s.length() <= 700 ? s : s.substring(0, 700) + "\n…";
    }

    /** 文件清单 + 包内编辑：勾掉不需要的 .bank，用剩下的生成一个新包。 */
    private void showFiles(final Pack p) {
        new Thread(new Runnable() {
            public void run() {
                final List<String> names = new ArrayList<String>(p.banks);
                final long[] sizes = new long[names.size()];
                final CharSequence[] labels = new CharSequence[names.size()];
                for (int i = 0; i < names.size(); i++) {
                    File f = new File(p.banksDir(LibraryActivity.this), names.get(i));
                    sizes[i] = f.length();
                    labels[i] = names.get(i) + "  (" + Kit.fmtSize(sizes[i]) + ")";
                }
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(LibraryActivity.this)) return;
                        final boolean[] sel = new boolean[names.size()];
                        AlertDialog.Builder b = new AlertDialog.Builder(LibraryActivity.this, R.style.DialogTheme);
                        b.setTitle(p.name + " · 文件（" + names.size() + "）");
                        b.setMessage("勾选要删掉的文件，确定后会去掉它们并生成一个新包；原包可以保留也可以删掉。");
                        b.setMultiChoiceItems(labels, sel, new DialogInterface.OnMultiChoiceClickListener() {
                            public void onClick(DialogInterface d, int which, boolean isChecked) {
                                sel[which] = isChecked;
                            }
                        });
                        b.setPositiveButton("删除选中并生成新包", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                doTrim(p, names, sel);
                            }
                        });
                        b.setNeutralButton("复制清单", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                StringBuilder sb = new StringBuilder();
                                for (int i = 0; i < names.size(); i++) {
                                    sb.append(names.get(i)).append("  ").append(Kit.fmtSize(sizes[i])).append('\n');
                                }
                                Kit.copy(LibraryActivity.this, sb.toString(), "文件清单");
                            }
                        });
                        b.setNegativeButton("关闭", null);
                        b.show();
                    }
                });
            }
        }, "wtm-files").start();
    }

    private void doTrim(final Pack p, final List<String> names, final boolean[] checked) {
        int sel = 0;
        for (boolean c : checked) if (c) sel++;
        if (sel == 0) {
            Kit.toast(this, "先勾选要删掉的文件");
            return;
        }
        if (sel >= names.size()) {
            Kit.msg(this, "不能全删", "至少要保留一个文件。");
            return;
        }
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("生成新包…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        new Thread(new Runnable() {
            public void run() {
                File temp = new File(PackStore.tmpDir(LibraryActivity.this),
                        "trim_" + System.currentTimeMillis());
                String err = null;
                Pack np = null;
                Pack dupPack = null;
                try {
                    if (!temp.mkdirs() && !temp.isDirectory()) throw new Exception("临时目录不可写");
                    for (int i = 0; i < names.size(); i++) {
                        if (checked[i]) continue;
                        File src = new File(p.banksDir(LibraryActivity.this), names.get(i));
                        if (!Kit.copyFile(src, new File(temp, names.get(i)))) {
                            throw new Exception("复制失败：" + names.get(i) + "（空间不足？）");
                        }
                    }
                    BankImporter.Result r = BankImporter.inspectDir(temp, p.name);
                    dupPack = PackStore.findByHash(LibraryActivity.this, r.hash);
                    if (dupPack == null) {
                        String nm = PackStore.uniqueName(LibraryActivity.this, p.name + " · 精简", null);
                        np = PackStore.save(LibraryActivity.this, r, nm, p.note, p.source);
                        np.tags = new ArrayList<String>(p.tags);
                        np.favorite = p.favorite;
                        PackStore.writeMeta(LibraryActivity.this, np);
                    }
                } catch (Throwable t) {
                    String m = t.getMessage();
                    err = (m == null || m.length() == 0) ? t.toString() : m;
                } finally {
                    Kit.deleteRec(temp);
                }
                final String fErr = err;
                final Pack fNp = np;
                final Pack fDup = dupPack;
                ui.post(new Runnable() {
                    public void run() {
                        try {
                            pd.dismiss();
                        } catch (Throwable ignored) {
                        }
                        if (!Kit.alive(LibraryActivity.this)) return;
                        if (fErr != null) {
                            Kit.msg(LibraryActivity.this, "生成失败", fErr);
                            return;
                        }
                        if (fNp == null) {
                            Kit.msg(LibraryActivity.this, "没有新建",
                                    "剩下的文件和库里「" + (fDup == null ? "某个包" : fDup.name)
                                            + "」内容完全相同，就没有再存一份。");
                            reload();
                            return;
                        }
                        Kit.confirm(LibraryActivity.this, "已生成新包",
                                "「" + fNp.name + "」" + fNp.count + " 个文件 · " + Kit.fmtSize(fNp.size)
                                        + "\n\n原包「" + p.name + "」要删掉吗？",
                                "删掉原包", new Runnable() {
                                    public void run() {
                                        PackStore.delete(LibraryActivity.this, p);
                                        if (p.id != null && p.id.equals(Prefs.appliedId(LibraryActivity.this))) {
                                            Prefs.clearApplied(LibraryActivity.this);
                                        }
                                        reload();
                                        Kit.toast(LibraryActivity.this, "已删除原包");
                                    }
                                });
                        reload();
                    }
                });
            }
        }, "wtm-trim").start();
    }

    private void confirmDelete(final Pack p) {
        Kit.confirm(this, "删除语音包",
                "会把这个语音包从库里删掉（" + Kit.fmtSize(p.size) + "）。\n"
                        + "如果它正在游戏里生效，游戏里的文件不会被自动清空，可以在首页点「恢复原版」。",
                "删除", new Runnable() {
                    public void run() {
                        PackStore.delete(LibraryActivity.this, p);
                        if (p.id != null && p.id.equals(Prefs.appliedId(LibraryActivity.this))) {
                            Prefs.clearApplied(LibraryActivity.this);
                        }
                        reload();
                        Kit.toast(LibraryActivity.this, "已删除");
                    }
                });
    }

    private void confirmApply(final Pack p) {
        if (!Access.ready()) {
            Kit.confirm(this, "还没有权限通道",
                    "换包需要写游戏目录，先回首页启用 Shizuku（或 root）。", "去首页", new Runnable() {
                        public void run() {
                            finish();
                        }
                    });
            return;
        }
        // 列目标目录要 spawn shell，放到后台线程，别在主线程卡住
        new Thread(new Runnable() {
            public void run() {
                final List<String> unknown = Installer.unknownBanks(LibraryActivity.this);
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (!unknown.isEmpty()) {
                            StringBuilder sb = new StringBuilder();
                            sb.append("目标目录里已有 ").append(unknown.size())
                                    .append(" 个不是本软件写入的语音文件，换包会把它们删掉：\n\n");
                            int i = 0;
                            for (String s : unknown) {
                                if (i++ >= 6) {
                                    sb.append("…等");
                                    break;
                                }
                                sb.append("· ").append(s).append('\n');
                            }
                            Kit.confirm(LibraryActivity.this, "会被覆盖的文件", sb.toString(),
                                    "继续覆盖", new Runnable() {
                                        public void run() {
                                            doApply(p);
                                        }
                                    });
                        } else {
                            doApply(p);
                        }
                    }
                });
            }
        }, "wtm-check-unknown").start();
    }

    private void doApply(final Pack p) {
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("正在写入游戏目录…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        Installer.applyAsync(this, p, new Installer.Listener() {
            public void onProgress(String text) {
                try {
                    pd.setMessage(text);
                } catch (Throwable ignored) {
                }
            }

            public void onDone(boolean ok, String message) {
                try {
                    pd.dismiss();
                } catch (Throwable ignored) {
                }
                if (!Kit.alive(LibraryActivity.this)) return;
                if (ok) {
                    Kit.done(LibraryActivity.this, "换好了", message, "启动游戏",
                            new Runnable() {
                                public void run() {
                                    if (!GameLauncher.launch(LibraryActivity.this)) {
                                        GameLauncher.explain(LibraryActivity.this);
                                    }
                                }
                            });
                } else {
                    Kit.failed(LibraryActivity.this, "换包没成功", message,
                            new Runnable() {
                                public void run() {
                                    doApply(p);
                                }
                            }, "启动游戏", new Runnable() {
                                public void run() {
                                    if (!GameLauncher.launch(LibraryActivity.this)) {
                                        GameLauncher.explain(LibraryActivity.this);
                                    }
                                }
                            });
                }
                reload();
            }
        });
    }
}
