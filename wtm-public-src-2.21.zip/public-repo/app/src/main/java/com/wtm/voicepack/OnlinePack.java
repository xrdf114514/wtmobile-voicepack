package com.wtm.voicepack;

import org.json.JSONObject;

/** 在线语音包（列表里的一条）。 */
public final class OnlinePack {

    public String source = "";      // 来源名，例如 "WT Live" / 自定义订阅源
    public String sourceType = "";  // wtlive / json
    public String id = "";
    public String title = "";
    public String note = "";        // 作者 / 标签
    public String desc = "";        // 纯文本简介
    public String url = "";         // zip 直链
    public String pageUrl = "";     // 详情页（可选）
    public String thumb = "";       // 缩略图（可选）
    public long size = 0;
    public long downloads = 0;
    public long updatedAt = 0;
    public int bankCount = 0;
    public String sha256 = "";

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("source", source);
            o.put("sourceType", sourceType);
            o.put("id", id);
            o.put("title", title);
            o.put("note", note);
            o.put("desc", desc);
            o.put("url", url);
            o.put("pageUrl", pageUrl);
            o.put("size", size);
            o.put("downloads", downloads);
            o.put("updatedAt", updatedAt);
            o.put("bankCount", bankCount);
            o.put("sha256", sha256);
        } catch (Throwable ignored) {
        }
        return o;
    }

    public static OnlinePack fromJson(JSONObject o) {
        OnlinePack p = new OnlinePack();
        p.source = o.optString("source", "");
        p.sourceType = o.optString("sourceType", "");
        p.id = o.optString("id", "");
        p.title = o.optString("title", "");
        p.note = o.optString("note", "");
        p.desc = o.optString("desc", "");
        p.url = o.optString("url", "");
        p.pageUrl = o.optString("pageUrl", "");
        p.size = o.optLong("size", 0);
        p.downloads = o.optLong("downloads", 0);
        p.updatedAt = o.optLong("updatedAt", 0);
        p.bankCount = o.optInt("bankCount", 0);
        p.sha256 = o.optString("sha256", "");
        return p;
    }

    public String metaLine() {
        StringBuilder sb = new StringBuilder();
        sb.append(source);
        if (size > 0) sb.append(" · ").append(Kit.fmtSize(size));
        if (note != null && note.length() > 0) sb.append(" · ").append(note);
        return sb.toString();
    }
}
