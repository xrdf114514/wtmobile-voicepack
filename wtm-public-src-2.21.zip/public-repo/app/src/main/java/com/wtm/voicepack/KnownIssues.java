package com.wtm.voicepack;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;

/**
 * 已知问题清单：把「App 无法自动修复」的那几类问题写清楚。
 *
 * 目的不是免责，而是让用户/后来的人一眼分清：
 *   · 哪些是 App 的 bug（会修）
 *   · 哪些是游戏改包、换机、系统拦截、Shizuku 本身的问题（App 管不了）
 * 文案改这里就行，设置页和 docs/已知问题.md 用同一份内容。
 */
public final class KnownIssues {

    public static final String TEXT =
            "以下是 App 无法自动修复的问题，遇到时按对应说明处理：\n\n"
                    + "1. 游戏更新后语音包可能整套没声音\n"
                    + "语音包是按某个游戏版本做的，游戏更新后 bank 格式/内容对不上，引擎会拒绝加载，"
                    + "表现为连原版语音都没了。App 无法识别「这个包对应哪个游戏版本」。\n"
                    + "处理：换用对应版本的包；或首页「恢复原版」先找回原版语音。\n\n"
                    + "2. 改包状态 App 看不到\n"
                    + "purify:no 与 enable_mod:yes 写在游戏 APK 的 assets 里，App 既读不到也改不了。"
                    + "语音包放进去没反应，先确认这两处是否仍然生效（游戏更新会覆盖回原版）。\n\n"
                    + "3. 换机后版本号相同，但可能不是同一个游戏包\n"
                    + "小米换机等工具常是「数据照搬 + 从商店补装 APK」，版本号一样但 build/渠道不同，"
                    + "同一份语音包在旧机上能用、新机上整套哑。App 无法区分。\n"
                    + "处理：从官网重下同一来源的包，重新改包再装。\n\n"
                    + "4. 系统会拦截安装\n"
                    + "小米/HyperOS 的纯净模式、安装校验会阻止 MT管理器 安装改包 APK。"
                    + "App 无法干预，需要在系统设置里放行，或改用 Shizuku 安装器。\n\n"
                    + "5. 某些 Shizuku 版本自身有问题\n"
                    + "Shizuku+ 旧版（r2xxx 以前）把 newProcess 放在裸事务号 7 上，标准客户端会拿到空 binder，"
                    + "表现为 asBinder() on null。App 已内置兼容（7 号和 8 号都会试），"
                    + "但旧版其它接口仍可能异常，建议更新到最新 Shizuku / Shizuku+。\n\n"
                    + "6. 被删掉的文件找不回来\n"
                    + "换包时会按你的确认删除 mod 里不属于新包的文件，删了不可恢复。"
                    + "原版语音可以靠「恢复原版」+ 游戏重新下载资源找回；"
                    + "自己手工放进 mod 的文件请先备份。\n\n"
                    + "7. 部分机型 Shizuku 会被系统杀掉\n"
                    + "后台保活由 Shizuku 自己负责（Shizuku+ 的自活也是一样）。"
                    + "被杀之后写文件会失败，App 只能提示「权限通道未就绪」，需要重新启动 Shizuku。";

    private KnownIssues() {
    }

    public static void show(final Activity a) {
        try {
            AlertDialog.Builder b = new AlertDialog.Builder(a, R.style.DialogTheme);
            b.setTitle("已知问题（无法自动修复）");
            b.setMessage(TEXT);
            b.setPositiveButton("复制全部", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    Kit.copy(a, TEXT, "已知问题");
                }
            });
            b.setNegativeButton("关闭", null);
            b.show();
        } catch (Throwable t) {
            Kit.toast(a, "打不开：" + t);
        }
    }
}
