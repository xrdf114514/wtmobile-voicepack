package com.wtm.voicepack;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/** 轻量偏好设置。 */
public final class Prefs {

    public static final String DEFAULT_PKG = "com.gaijingames.wtm";
    private static final String F = "wtm_voicepack";

    private Prefs() {
    }

    public static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(F, Context.MODE_PRIVATE);
    }

    public static String pkg(Context c) {
        String v = p(c).getString("pkg", DEFAULT_PKG);
        return v == null || v.length() == 0 ? DEFAULT_PKG : v;
    }

    public static void setPkg(Context c, String v) {
        p(c).edit().putString("pkg", v).apply();
    }

    // ---------- 当前生效的语音包 ----------
    public static String appliedId(Context c) {
        return p(c).getString("applied_id", "");
    }

    public static String appliedName(Context c) {
        return p(c).getString("applied_name", "");
    }

    public static long appliedAt(Context c) {
        return p(c).getLong("applied_at", 0);
    }

    public static int appliedCount(Context c) {
        return p(c).getInt("applied_count", 0);
    }

    public static void setApplied(Context c, String id, String name, int count) {
        p(c).edit()
                .putString("applied_id", id == null ? "" : id)
                .putString("applied_name", name == null ? "" : name)
                .putInt("applied_count", count)
                .putLong("applied_at", System.currentTimeMillis())
                .apply();
    }

    public static void clearApplied(Context c) {
        p(c).edit().putString("applied_id", "").putString("applied_name", "")
                .putInt("applied_count", 0).putLong("applied_at", 0).apply();
    }

    /** 记录上一次写入游戏的 .bank 文件名，用于判断目标目录里哪些文件是本软件写的。 */
    public static List<String> writtenFiles(Context c) {
        List<String> out = new ArrayList<String>();
        try {
            String s = p(c).getString("written", "[]");
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) out.add(a.optString(i));
        } catch (Throwable ignored) {
        }
        return out;
    }

    public static void setWrittenFiles(Context c, List<String> files) {
        JSONArray a = new JSONArray();
        if (files != null) for (String s : files) a.put(s);
        p(c).edit().putString("written", a.toString()).apply();
    }

    public static boolean lastGuessAuto(Context c) {
        return p(c).getBoolean("guess_auto", true);
    }

    public static void setLastGuessAuto(Context c, boolean v) {
        p(c).edit().putBoolean("guess_auto", v).apply();
    }

    /** 成功导入到语音包库的次数（用于「第一次导入给点起名提示」）。 */
    public static int importCount(Context c) {
        return p(c).getInt("import_count", 0);
    }

    public static void bumpImportCount(Context c) {
        p(c).edit().putInt("import_count", importCount(c) + 1).apply();
    }

    /** 成功换包的次数（和导入次数分开统计）。 */
    public static int applyCount(Context c) {
        return p(c).getInt("apply_count", 0);
    }

    public static void bumpApplyCount(Context c) {
        p(c).edit().putInt("apply_count", applyCount(c) + 1).apply();
    }
}
