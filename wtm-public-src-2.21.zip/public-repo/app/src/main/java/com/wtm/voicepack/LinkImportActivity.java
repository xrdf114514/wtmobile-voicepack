package com.wtm.voicepack;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 从链接 / 分享导入。
 *
 * 两类链接：
 *   · 直链（.zip/.bank、GitHub Release、对象存储、蓝奏云）→ 一键下载 + 自动入库
 *   · 网盘（百度/夸克/阿里/微云/115/天翼/123）→ 只做识别、复制分享信息、跳转 App；
 *     不碰登录态，也不做任何绕过风控的事。下载完再用本软件打开 zip。
 *
 * 另外它也接收系统分享（文本链接 / zip 文件）和「打开方式」，所以从网盘 App 里
 * 直接「分享到本软件」也能进导入流程。
 */
public final class LinkImportActivity extends Activity implements View.OnClickListener {

    private EditText etText;
    private TextView btnPaste, btnParse, tvTitle, btnBack, tvEmpty;
    private ListView listLinks;

    private final List<LinkIn.Link> links = new ArrayList<LinkIn.Link>();
    private LinkAdapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean downloading = false;
    private volatile boolean cancelFlag = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_link);

        tvTitle = (TextView) findViewById(R.id.tvTitle);
        btnBack = (TextView) findViewById(R.id.btnBack);
        etText = (EditText) findViewById(R.id.etText);
        btnPaste = (TextView) findViewById(R.id.btnPaste);
        btnParse = (TextView) findViewById(R.id.btnParse);
        listLinks = (ListView) findViewById(R.id.listLinks);
        tvEmpty = (TextView) findViewById(R.id.tvEmpty);

        tvTitle.setText("从链接 / 分享导入");
        btnBack.setOnClickListener(this);
        btnPaste.setOnClickListener(this);
        btnParse.setOnClickListener(this);

        adapter = new LinkAdapter();
        listLinks.setAdapter(adapter);
        listLinks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                if (pos < 0 || pos >= links.size()) return;
                onPick(links.get(pos));
            }
        });

        handleIncoming(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    // ------------------------------------------------------------------ 入口

    private void handleIncoming(Intent it) {
        if (it == null) return;
        String action = it.getAction();
        if (Intent.ACTION_SEND.equals(action) || Intent.ACTION_VIEW.equals(action)) {
            // 1) 直接分享/打开了一个 zip 文件
            Uri single = it.getParcelableExtra(Intent.EXTRA_STREAM);
            if (single == null && Intent.ACTION_VIEW.equals(action)) single = it.getData();
            if (single != null) {
                ArrayList<Uri> us = new ArrayList<Uri>();
                us.add(single);
                openImport(us);
                return;
            }
            ClipData clip = it.getClipData();
            if (clip != null && clip.getItemCount() > 0) {
                ArrayList<Uri> us = new ArrayList<Uri>();
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri u = clip.getItemAt(i).getUri();
                    if (u != null) us.add(u);
                }
                if (!us.isEmpty()) {
                    openImport(us);
                    return;
                }
            }
            // 2) 分享了一段文字（通常是链接+提取码；也可能是一个订阅源地址）
            String text = it.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null && text.length() > 0) {
                final String src = asSourceAddress(text);
                if (src != null) {
                    AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
                    b.setTitle("这是一个订阅源地址");
                    b.setMessage(src + "\n\n添加成订阅源之后，就能在「在线语音包」里看到它提供的包。");
                    b.setPositiveButton("添加订阅源", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            if (SourceStore.add(LinkImportActivity.this, "", src)) {
                                Kit.toast(LinkImportActivity.this, "已添加，去「在线语音包」看看");
                            } else {
                                Kit.toast(LinkImportActivity.this, "添加失败：地址无效或已存在");
                            }
                            finish();
                        }
                    });
                    b.setNegativeButton("当普通链接处理", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            etText.setText(src);
                            doParse();
                        }
                    });
                    b.show();
                    return;
                }
                etText.setText(text);
                doParse();
            }
        }
    }

    /** 分享文本看着像个订阅源地址时返回它。 */
    private static String asSourceAddress(String text) {
        String t = text == null ? "" : text.trim();
        if (t.length() == 0) return null;
        String first = t.split("\\s+")[0];
        if (first.startsWith("github:") && GitHubSource.normalizeRepo(first) != null) return first;
        String lower = first.toLowerCase(java.util.Locale.US);
        if ((lower.startsWith("http://") || lower.startsWith("https://"))
                && (lower.contains("index.json") || lower.endsWith(".json"))) {
            return first;
        }
        return null;
    }

    private void openImport(ArrayList<Uri> uris) {
        Intent i = new Intent(this, ImportActivity.class);
        i.putParcelableArrayListExtra(ImportActivity.EXTRA_URIS, uris);
        startActivity(i);
        finish();
    }

    // ------------------------------------------------------------------ 解析

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnBack) {
            finish();
        } else if (id == R.id.btnPaste) {
            pasteFromClipboard();
        } else if (id == R.id.btnParse) {
            doParse();
        }
    }

    private void pasteFromClipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm == null || cm.getPrimaryClip() == null || cm.getPrimaryClip().getItemCount() == 0) {
                Kit.toast(this, "剪贴板是空的");
                return;
            }
            CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (cs == null || cs.length() == 0) {
                Kit.toast(this, "剪贴板里没有文字");
                return;
            }
            etText.setText(cs.toString());
            doParse();
        } catch (Throwable t) {
            Kit.toast(this, "读剪贴板失败：" + t);
        }
    }

    private void doParse() {
        links.clear();
        links.addAll(LinkIn.parse(etText.getText().toString()));
        adapter.notifyDataSetChanged();
        boolean empty = links.isEmpty();
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        listLinks.setVisibility(empty ? View.GONE : View.VISIBLE);
        if (empty) {
            tvEmpty.setText("没找到链接。\n确认粘贴的是完整分享文本（http/https 开头）。");
        } else {
            Kit.toast(this, "找到 " + links.size() + " 个链接");
        }
    }

    // ------------------------------------------------------------------ 点链接

    private void onPick(final LinkIn.Link l) {
        if (l.isDirect() || LinkIn.looksLikeArchiveUrl(l.url)) {
            askDownload(l);
            return;
        }
        if (l.isNetdisk()) {
            showNetdisk(l);
            return;
        }
        // 普通链接：先探一下是不是文件
        Kit.toast(this, "检测这个链接…");
        new Thread(new Runnable() {
            public void run() {
                final Net.Probe p = Net.probe(l.url, null);
                final boolean file = p.ok && (isArchiveType(p.type) || (p.size > 32 * 1024 && p.type != null
                        && p.type.contains("octet-stream")));
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(LinkImportActivity.this)) return;
                        if (file) {
                            l.kind = "direct";
                            adapter.notifyDataSetChanged();
                            askDownload(l);
                        } else {
                            AlertDialog.Builder b = new AlertDialog.Builder(LinkImportActivity.this, R.style.DialogTheme);
                            b.setTitle("这个链接不是直链文件");
                            b.setMessage(LinkIn.hint(l) + (p.error.length() > 0 ? "\n（" + p.error + "）" : ""));
                            b.setPositiveButton("用浏览器打开", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface d, int w) {
                                    Kit.openUrl(LinkImportActivity.this, l.url);
                                }
                            });
                            b.setNeutralButton("复制链接", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface d, int w) {
                                    Kit.copy(LinkImportActivity.this, l.fullText(), "分享信息");
                                }
                            });
                            b.setNegativeButton("关闭", null);
                            b.show();
                        }
                    }
                });
            }
        }, "wtm-probe").start();
    }

    private boolean isArchiveType(String type) {
        if (type == null) return false;
        String t = type.toLowerCase(java.util.Locale.US);
        return t.contains("zip") || t.contains("rar") || t.contains("7z")
                || t.contains("x-zip") || t.contains("compressed");
    }

    private void showNetdisk(final LinkIn.Link l) {
        StringBuilder msg = new StringBuilder();
        msg.append(LinkIn.hint(l));
        if (l.pwd != null && l.pwd.length() > 0) msg.append("\n\n提取码：").append(l.pwd);
        msg.append("\n\n").append(l.url);

        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle(l.label());
        b.setMessage(msg.toString());
        b.setPositiveButton("打开网盘", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.openUrl(LinkImportActivity.this, l.url);
            }
        });
        b.setNeutralButton("复制分享信息", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.copy(LinkImportActivity.this, l.fullText(), "分享信息");
            }
        });
        b.setNegativeButton("关闭", null);
        b.show();
    }

    // ------------------------------------------------------------------ 下载

    private void askDownload(final LinkIn.Link l) {
        if (downloading) {
            Kit.toast(this, "正在下载另一个文件");
            return;
        }
        if (!Access.ready()) {
            Kit.toast(this, "提示：没有权限通道时也能下载入库，只是不能自动换包");
        }
        Kit.confirm(this, "下载并导入？", l.url
                + "\n\n下载完会自动抽 .bank 存进语音包库（相同内容不会重复占空间）。", "开始下载", new Runnable() {
            public void run() {
                downloadAndImport(l);
            }
        });
    }

    private void downloadAndImport(final LinkIn.Link l) {
        downloading = true;
        cancelFlag = false;
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("准备下载…");
        pd.setCancelable(true);
        pd.setButton(DialogInterface.BUTTON_NEGATIVE, "取消", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                cancelFlag = true;
                d.dismiss();
            }
        });
        try {
            pd.show();
        } catch (Throwable ignored) {
        }

        new Thread(new Runnable() {
            public void run() {
                File tmp = new File(getCacheDir(), "wtm_link_" + System.currentTimeMillis() + ".zip");
                File workDir = null;
                String err = null;
                String okMsg = null;
                Pack finalPack = null;
                boolean dup = false;
                Pack dupPack = null;
                try {
                    Net.download(l.url, tmp, null, 0, null, new Net.Progress() {
                        public boolean onProgress(final long done, final long total) {
                            ui.post(new Runnable() {
                                public void run() {
                                    try {
                                        pd.setMessage(total > 0
                                                ? "下载中 " + Kit.fmtSize(done) + " / " + Kit.fmtSize(total)
                                                : "下载中 " + Kit.fmtSize(done));
                                    } catch (Throwable ignored) {
                                    }
                                }
                            });
                            return cancelFlag;
                        }
                    });
                    ui.post(new Runnable() {
                        public void run() {
                            try {
                                pd.setMessage("正在解压导入…");
                            } catch (Throwable ignored) {
                            }
                        }
                    });

                    workDir = new File(PackStore.tmpDir(LinkImportActivity.this),
                            "link_" + System.currentTimeMillis());
                    String name = WtLive.prettyTitle(lastSegment(l.url));
                    BankImporter.Result r = BankImporter.importFromZipFile(LinkImportActivity.this, tmp,
                            name + ".zip", workDir, null);
                    dupPack = PackStore.findByHash(LinkImportActivity.this, r.hash);
                    if (dupPack != null) {
                        dup = true;
                        finalPack = dupPack;
                    } else {
                        String packName = PackStore.uniqueName(LinkImportActivity.this, name, null);
                        finalPack = PackStore.save(LinkImportActivity.this, r, packName, "", "链接导入");
                        Prefs.bumpImportCount(LinkImportActivity.this);
                        okMsg = "已导入：" + finalPack.name + "\n" + finalPack.count + " 个文件 · "
                                + Kit.fmtSize(finalPack.size);
                    }
                } catch (Throwable t) {
                    String m = t.getMessage();
                    err = (m == null || m.length() == 0) ? t.toString() : m;
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                    if (workDir != null) Kit.deleteRec(workDir);
                }

                final String fErr = err;
                final String fOk = okMsg;
                final Pack fp = finalPack;
                final boolean fDup = dup;
                final Pack fDupPack = dupPack;

                ui.post(new Runnable() {
                    public void run() {
                        downloading = false;
                        try {
                            pd.dismiss();
                        } catch (Throwable ignored) {
                        }
                        if (!Kit.alive(LinkImportActivity.this)) return;
                        if (fErr != null) {
                            Kit.msg(LinkImportActivity.this, "没成功", fErr
                                    + "\n\n如果这是个网盘页面而不是直链，请按提示先在网盘里下载。");
                            return;
                        }
                        if (fDup) {
                            Kit.confirm(LinkImportActivity.this, "这个包库里已经有了",
                                    "内容一样：「" + fDupPack.name + "」，不再重复占空间。\n\n直接用它换包吗？",
                                    "用它换包", new Runnable() {
                                        public void run() {
                                            apply(fDupPack);
                                        }
                                    });
                            return;
                        }
                        if (fp != null) {
                            Kit.confirm(LinkImportActivity.this, "导入成功", fOk + "\n\n现在换到游戏里吗？",
                                    "立即应用", new Runnable() {
                                        public void run() {
                                            apply(fp);
                                        }
                                    });
                        }
                    }
                });
            }
        }, "wtm-link-download").start();
    }

    private static String lastSegment(String url) {
        try {
            String p = Uri.parse(url).getLastPathSegment();
            if (p != null && p.length() > 0) return p;
        } catch (Throwable ignored) {
        }
        return "链接导入";
    }

    private void apply(final Pack p) {
        if (!Access.ready()) {
            Kit.msg(this, "还没有权限通道",
                    "语音包已经存进库里了。回首页启用 Shizuku（或 root）之后就能一键换包。");
            return;
        }
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("正在写入游戏目录…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        Installer.applyAsync(this, p, new Installer.Listener() {
            public void onProgress(String text) {
                try {
                    pd.setMessage(text);
                } catch (Throwable ignored) {
                }
            }

            public void onDone(boolean ok, String message) {
                try {
                    pd.dismiss();
                } catch (Throwable ignored) {
                }
                if (!Kit.alive(LinkImportActivity.this)) return;
                if (ok) {
                    Kit.done(LinkImportActivity.this, "换好了", message, "启动游戏",
                            new Runnable() {
                                public void run() {
                                    if (!GameLauncher.launch(LinkImportActivity.this)) {
                                        GameLauncher.explain(LinkImportActivity.this);
                                    }
                                }
                            });
                } else {
                    Kit.failed(LinkImportActivity.this, "换包没成功", message,
                            new Runnable() {
                                public void run() {
                                    apply(p);
                                }
                            }, "启动游戏", new Runnable() {
                                public void run() {
                                    if (!GameLauncher.launch(LinkImportActivity.this)) {
                                        GameLauncher.explain(LinkImportActivity.this);
                                    }
                                }
                            });
                }
            }
        });
    }

    // ------------------------------------------------------------------ 适配器

    private final class LinkAdapter extends BaseAdapter {
        public int getCount() {
            return links.size();
        }

        public Object getItem(int i) {
            return links.get(i);
        }

        public long getItemId(int i) {
            return i;
        }

        public View getView(int pos, View convert, ViewGroup parent) {
            View v = convert;
            if (v == null) {
                v = LayoutInflater.from(LinkImportActivity.this)
                        .inflate(R.layout.item_link, parent, false);
            }
            LinkIn.Link l = links.get(pos);
            TextView kind = (TextView) v.findViewById(R.id.tvKind);
            TextView url = (TextView) v.findViewById(R.id.tvUrl);
            TextView action = (TextView) v.findViewById(R.id.tvAction);

            StringBuilder t = new StringBuilder(l.label());
            if (l.pwd != null && l.pwd.length() > 0) t.append("  ·  提取码 ").append(l.pwd);
            kind.setText(t.toString());
            url.setText(l.url);
            action.setText(l.isDirect() ? "下载导入" : (l.isNetdisk() ? "打开" : "检测"));
            return v;
        }
    }
}
