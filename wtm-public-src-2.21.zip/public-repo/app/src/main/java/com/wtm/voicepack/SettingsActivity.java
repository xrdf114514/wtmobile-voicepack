package com.wtm.voicepack;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

/** 设置：游戏包名、存储占用、清理、关于。 */
public final class SettingsActivity extends Activity implements View.OnClickListener {

    private EditText etPkg;
    private TextView tvPath, tvStorage, tvAbout, tvTitle, btnBack;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);

        tvTitle = (TextView) findViewById(R.id.tvTitle);
        btnBack = (TextView) findViewById(R.id.btnBack);
        etPkg = (EditText) findViewById(R.id.etPkg);
        tvPath = (TextView) findViewById(R.id.tvPath);
        tvStorage = (TextView) findViewById(R.id.tvStorage);
        tvAbout = (TextView) findViewById(R.id.tvAbout);

        tvTitle.setText("设置与存储");
        btnBack.setOnClickListener(this);
        findViewById(R.id.btnSave).setOnClickListener(this);
        View detectBtn = findViewById(R.id.btnDetect);
        if (detectBtn != null) detectBtn.setOnClickListener(this);
        View soundBtn = findViewById(R.id.btnSoundList);
        if (soundBtn != null) soundBtn.setOnClickListener(this);
        View shHelp = findViewById(R.id.btnShizukuHelp);
        if (shHelp != null) shHelp.setOnClickListener(this);
        View ki = findViewById(R.id.btnKnownIssues);
        if (ki != null) ki.setOnClickListener(this);
        View pdg = findViewById(R.id.btnPathDiag);
        if (pdg != null) pdg.setOnClickListener(this);
        View sc = findViewById(R.id.btnSelfCheck);
        if (sc != null) sc.setOnClickListener(this);
        View el = findViewById(R.id.btnExportLog);
        if (el != null) el.setOnClickListener(this);
        View terms = findViewById(R.id.btnTerms);
        if (terms != null) terms.setOnClickListener(this);
        findViewById(R.id.btnClean).setOnClickListener(this);

        etPkg.setText(Prefs.pkg(this));
        tvPath.setText("当前目标目录：\n" + GameDir.modDir(this));

        tvAbout.setText("战雷手游语音包管理器 v2.10-private\n\n"
                + "· 只做「管理语音包 + 往 mod 目录放文件」这一件事，不改包、不动游戏本体。\n"
                + "· 权限走 Shizuku（推荐，不用 root）或 root；Android 10 及更早可直接读写。\n"
                + "· 语音包按内容指纹存进应用专属目录，同一内容只存一份；换包不会产生多余副本。\n"
                + "· 在线语音包：订阅源里的是手游成品包，下载即可用；WT Live 是内置的端游素材源（默认关闭），要移植后才能用。\n"
                + "· 订阅源在「在线语音包 → 订阅源」里管理：可以试读后再添加、启停、删除；支持 index.json 地址和 github:用户/仓库。\n"
                + "· 语音包库里的包可以「导出 / 分享」成 zip，发给对方或做成自己的订阅源。\n"
                + "· 支持「从链接 / 分享导入」：粘视频简介里的网盘链接或 zip 直链，也能从别的应用分享/打开 zip 过来。\n"
                + "· 本软件不提供/不托管任何语音包内容，与游戏官方无关；使用边界见「使用条款与免责声明」。\n"
                + "· 语音包库：点按看详情、长按出快捷操作；可编辑名称/备注/标签（标签参与检索）、多选批量删除/导出/收藏、包内删单个 bank。\n"
                + "· 设置页有「环境自检」和「导出诊断日志」，遇到闪退或换包失败先跑一次自检。\n"
                + "· 卸载应用会一并删掉语音包库，重要语音包建议保留原始 zip。\n\n"
                + "语音文件路径：" + GameDir.modDir(this) + "（是 mod，不是 mods）");

        refreshStorage();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStorage();
        refreshDiag();
    }

    /** 随时查看条款（已经同意过，这里只展示 + 可复制）。 */
    private void showTerms() {
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle(Disclaimer.title());
        b.setMessage(Disclaimer.text());
        b.setPositiveButton("复制全文", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.copy(SettingsActivity.this, Disclaimer.text(), "条款全文");
            }
        });
        b.setNegativeButton("关闭", null);
        b.show();
    }

    /** Android 13+ 发通知需要运行时权限，"点通知进游戏"依赖它。 */
    private void ensureNotifyPermission() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2002);
            }
        } catch (Throwable ignored) {
        }
    }

    private void refreshDiag() {
        int n = CrashLog.count(this);
        StringBuilder sb = new StringBuilder();
        sb.append("版本 ").append(CrashLog.appVersion(this))
                .append(" · Android ").append(android.os.Build.VERSION.RELEASE).append('\n');
        sb.append("崩溃记录：").append(n).append(" 条");
        if (n > 0) sb.append("（最近 ").append(Kit.fmtTime(CrashLog.lastAt(this))).append("）");
        sb.append('\n');
        sb.append("遇到闪退/换包失败，先跑「环境自检」，再把诊断日志发出来。");
        TextView tv = (TextView) findViewById(R.id.tvDiag);
        if (tv != null) tv.setText(sb.toString());
    }

    /** 环境自检：后台收集，弹窗展示 + 一键复制。 */
    private void showSelfCheck() {
        Kit.toast(this, "正在自检…");
        new Thread(new Runnable() {
            public void run() {
                final String text = SelfCheck.build(SettingsActivity.this);
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(SettingsActivity.this)) return;
                        AlertDialog.Builder b = new AlertDialog.Builder(SettingsActivity.this, R.style.DialogTheme);
                        b.setTitle("环境自检");
                        b.setMessage(text);
                        b.setPositiveButton("复制全部", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                Kit.copy(SettingsActivity.this, text, "自检信息");
                            }
                        });
                        b.setNeutralButton("导出到下载目录", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                exportDiagnostics();
                            }
                        });
                        b.setNegativeButton("关闭", null);
                        b.show();
                    }
                });
            }
        }, "wtm-selfcheck").start();
    }

    /**
     * 路径诊断：把游戏声音目录和 mod 目录的 ls -l 原样打出来（含属主/权限/大小）。
     * 用于排查「文件写进去了但游戏没声音」这类问题，结果可一键复制。
     */
    private void showPathDiag() {
        final String sound = GameDir.soundDir(this);
        final String mod = GameDir.modDir(this);
        new Thread(new Runnable() {
            public void run() {
                StringBuilder sb = new StringBuilder();
                sb.append("通道: ").append(Access.channelName()).append('\n');
                sb.append("sound: ").append(sound).append('\n');
                sb.append("mod:   ").append(mod).append('\n');
                if (!Access.ready()) {
                    sb.append("\n（还没有权限通道，回首页授权后再试）\n");
                } else {
                    Access.Result r1 = Access.sh("ls -l " + GameDir.q(sound) + " 2>&1 | head -40");
                    sb.append("\n== sound ==\n").append(r1.out.trim()).append('\n');
                    Access.Result r2 = Access.sh("ls -l " + GameDir.q(mod) + " 2>&1 | head -40");
                    sb.append("\n== mod ==\n").append(r2.out.trim()).append('\n');
                    Access.Result r3 = Access.sh("du -sk " + GameDir.q(sound) + " " + GameDir.q(mod)
                            + " 2>/dev/null; id");
                    sb.append("\n== 统计 / 身份 ==\n").append(r3.out.trim()).append('\n');
                }
                final String text = sb.toString();
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(SettingsActivity.this)) return;
                        AlertDialog.Builder b = new AlertDialog.Builder(SettingsActivity.this, R.style.DialogTheme);
                        b.setTitle("路径诊断");
                        b.setMessage(text);
                        b.setPositiveButton("复制全部", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                Kit.copy(SettingsActivity.this, text, "路径诊断");
                            }
                        });
                        b.setNegativeButton("关闭", null);
                        b.show();
                    }
                });
            }
        }, "wtm-pathdiag").start();
    }

    private void exportDiagnostics() {
        Kit.toast(this, "正在整理诊断…");
        new Thread(new Runnable() {
            public void run() {
                String where = null;
                String err = null;
                try {
                    where = CrashLog.exportReport(SettingsActivity.this);
                } catch (Throwable t) {
                    String m = t.getMessage();
                    err = (m == null || m.length() == 0) ? t.toString() : m;
                }
                final String fWhere = where;
                final String fErr = err;
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(SettingsActivity.this)) return;
                        if (fErr != null) {
                            Kit.msg(SettingsActivity.this, "导出失败", fErr);
                        } else {
                            Kit.msg(SettingsActivity.this, "已导出",
                                    "诊断报告（环境自检 + 崩溃记录）已保存到：\n" + fWhere
                                            + "\n\n对外反馈时附上这个文件就行（里面有路径和机型信息，自己留意脱敏）。");
                        }
                    }
                });
            }
        }, "wtm-export-log").start();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnBack) {
            finish();
        } else if (id == R.id.btnSave) {
            savePkg();
        } else if (id == R.id.btnClean) {
            clean();
        } else if (id == R.id.btnDetect) {
            detectPkg();
        } else if (id == R.id.btnSoundList) {
            showSoundList();
        } else if (id == R.id.btnShizukuHelp) {
            ShizukuGuide.helpDialog(this);
        } else if (id == R.id.btnSelfCheck) {
            showSelfCheck();
        } else if (id == R.id.btnKnownIssues) {
            KnownIssues.show(this);
        } else if (id == R.id.btnPathDiag) {
            showPathDiag();
        } else if (id == R.id.btnExportLog) {
            exportDiagnostics();
        } else if (id == R.id.btnTerms) {
            showTerms();
        }
    }

    private void savePkg() {
        String p = etPkg.getText().toString().trim();
        if (p.length() == 0) {
            Kit.toast(this, "包名不能为空");
            return;
        }
        // 必须是一段段合法的包名，不能是 ".."（否则目标路径会跑到别的目录去）
        if (!p.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")) {
            Kit.toast(this, "包名格式不对，应该像 com.gaijingames.wtm");
            return;
        }
        Prefs.setPkg(this, p);
        Access.reset();
        tvPath.setText("当前目标目录：\n" + GameDir.modDir(this));
        Kit.toast(this, "已保存，回首页会重新检测环境");
        new Thread(new Runnable() {
            public void run() {
                Access.detect(getApplicationContext());
            }
        }, "wtm-redetect").start();
        finish();
    }

    /**
     * 列出游戏原版 sound 目录里的 bank 清单。
     * 移植端游语音包时，产出的文件名要和这些对得上，所以这个清单很有用。
     */
    private void showSoundList() {
        if (!Access.ready()) {
            Kit.msg(this, "还没有权限通道",
                    "读游戏目录需要 Shizuku 或 root。\n回首页点「获取文件读写权限」。");
            return;
        }
        Kit.toast(this, "读取中…");
        new Thread(new Runnable() {
            public void run() {
                final java.util.List<String> banks = GameDir.listSoundBanks(SettingsActivity.this);
                final boolean ok = GameDir.existsDir(SettingsActivity.this, GameDir.soundDir(SettingsActivity.this));
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(SettingsActivity.this)) return;
                        if (!ok) {
                            Kit.msg(SettingsActivity.this, "没找到 sound 目录",
                                    "路径：" + GameDir.soundDir(SettingsActivity.this)
                                            + "\n游戏包名可能填错了，或者在设置里点「自动检测游戏包名」。");
                            return;
                        }
                        if (banks.isEmpty()) {
                            Kit.msg(SettingsActivity.this, "sound 目录里没有 .bank",
                                    "路径：" + GameDir.soundDir(SettingsActivity.this));
                            return;
                        }
                        StringBuilder sb = new StringBuilder();
                        sb.append("路径：").append(GameDir.soundDir(SettingsActivity.this)).append("\n\n");
                        sb.append("共 ").append(banks.size()).append(" 个 bank：\n");
                        int n = 0;
                        for (String b : banks) {
                            if (n++ >= 40) {
                                sb.append("…等 ").append(banks.size()).append(" 个\n");
                                break;
                            }
                            sb.append("· ").append(b).append('\n');
                        }
                        sb.append("\n移植时产出的文件要和这些名字对得上（含 .assets.bank 成对的情况）。");
                        final String text = sb.toString();
                        Kit.confirm(SettingsActivity.this, "原版语音清单", text, "复制清单", new Runnable() {
                            public void run() {
                                StringBuilder plain = new StringBuilder();
                                for (String b : banks) plain.append(b).append('\n');
                                Kit.copy(SettingsActivity.this, plain.toString(), " bank 清单");
                            }
                        });
                    }
                });
            }
        }, "wtm-soundlist").start();
    }

    /** 去 Android/data 里找一下游戏包名，省得用户手输。 */
    private void detectPkg() {
        Kit.toast(this, "正在检测…");
        new Thread(new Runnable() {
            public void run() {
                final String found = Access.ready() || Prefs.pkg(SettingsActivity.this) != null
                        ? GameDir.detectGamePackage(SettingsActivity.this) : null;
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(SettingsActivity.this)) return;
                        if (found == null || found.length() == 0) {
                            Kit.msg(SettingsActivity.this, "没检测到",
                                    "在 Android/data 里没找到战争雷霆手游的目录。\n"
                                            + "可能游戏没装/没启动过，或者当前还没有权限通道（回首页先授权）。");
                        } else {
                            etPkg.setText(found);
                            Kit.toast(SettingsActivity.this, "找到：" + found);
                        }
                    }
                });
            }
        }, "wtm-detect-pkg").start();
    }

    private void refreshStorage() {
        new Thread(new Runnable() {
            public void run() {
                final List<Pack> list = PackStore.list(getApplicationContext());
                final long libSize = PackStore.totalSize(getApplicationContext());
                final long tmpSize = Kit.dirSize(PackStore.tmpDir(getApplicationContext()));
                ui.post(new Runnable() {
                    public void run() {
                        StringBuilder sb = new StringBuilder();
                        sb.append("语音包库：").append(list.size()).append(" 个，")
                                .append(Kit.fmtSize(libSize)).append('\n');
                        sb.append("临时文件：").append(Kit.fmtSize(tmpSize)).append('\n');
                        int fav = 0;
                        long biggest = 0;
                        for (Pack p : list) {
                            if (p.favorite) fav++;
                            if (p.size > biggest) biggest = p.size;
                        }
                        sb.append("收藏：").append(fav).append(" 个 · 最大单包：")
                                .append(Kit.fmtSize(biggest)).append('\n');
                        sb.append("去重位置：").append(PackStore.libraryDir(SettingsActivity.this));
                        tvStorage.setText(sb.toString());
                    }
                });
            }
        }, "wtm-settings-stat").start();
    }

    private void clean() {
        new Thread(new Runnable() {
            public void run() {
                final long freed = PackStore.cleanup(getApplicationContext());
                ui.post(new Runnable() {
                    public void run() {
                        Kit.toast(SettingsActivity.this, freed > 0
                                ? "已清理 " + Kit.fmtSize(freed) + "：临时文件 + 没有元数据的残留目录"
                                : "没有可清理的内容");
                        refreshStorage();
                    }
                });
            }
        }, "wtm-settings-clean").start();
    }
}
