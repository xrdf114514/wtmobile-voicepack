package com.wtm.voicepack;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 崩溃兜底：把未捕获异常连同环境信息写到应用目录，设置页可以一键导出。
 * 手机上出问题最怕"闪了就没了"，有这个至少能看是哪一行崩的。
 */
public final class CrashLog {

    private static final int KEEP = 10;

    private CrashLog() {
    }

    public static void install(final Application app) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    write(app, t, e);
                } catch (Throwable ignored) {
                }
                if (prev != null) {
                    prev.uncaughtException(t, e);
                } else {
                    android.os.Process.killProcess(android.os.Process.myPid());
                    System.exit(10);
                }
            }
        });
    }

    public static File dir(Context c) {
        File d = new File(PackStore.baseDir(c), "crash");
        if (!d.exists()) //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        return d;
    }

    private static void write(Context c, Thread t, Throwable e) {
        File d = dir(c);
        String ts = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append("时间: ").append(new Date().toString()).append('\n');
        sb.append("应用: ").append(appVersion(c)).append('\n');
        sb.append("系统: Android ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("机型: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        sb.append("线程: ").append(t == null ? "?" : t.getName()).append('\n');
        try {
            sb.append("通道: ").append(Access.channelName()).append(" / ").append(Access.detail).append('\n');
        } catch (Throwable ignored) {
        }
        try {
            sb.append("包名: ").append(Prefs.pkg(c)).append('\n');
            sb.append("mod 目录: ").append(GameDir.modDir(c)).append('\n');
        } catch (Throwable ignored) {
        }
        sb.append("\n--- 堆栈 ---\n");
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        sb.append(sw.toString());

        File f = new File(d, "crash-" + ts + ".txt");
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            fos.write(sb.toString().getBytes("UTF-8"));
            fos.flush();
            fos.close();
        } catch (Throwable ignored) {
        }
        trim(d);
    }

    private static void trim(File d) {
        File[] fs = d.listFiles();
        if (fs == null || fs.length <= KEEP) return;
        List<File> list = new ArrayList<File>();
        for (File f : fs) if (f.isFile()) list.add(f);
        java.util.Collections.sort(list, new java.util.Comparator<File>() {
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        for (int i = KEEP; i < list.size(); i++) //noinspection ResultOfMethodCallIgnored
            list.get(i).delete();
    }

    public static List<File> recent(Context c) {
        List<File> out = new ArrayList<File>();
        File[] fs = dir(c).listFiles();
        if (fs == null) return out;
        for (File f : fs) if (f.isFile() && f.getName().endsWith(".txt")) out.add(f);
        java.util.Collections.sort(out, new java.util.Comparator<File>() {
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        return out;
    }

    public static int count(Context c) {
        return recent(c).size();
    }

    public static long lastAt(Context c) {
        List<File> l = recent(c);
        return l.isEmpty() ? 0 : l.get(0).lastModified();
    }

    /** 把最近的崩溃记录 + 环境自检打成一个 txt，存到下载目录，返回路径。 */
    public static String exportReport(Context c) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("==== 战雷手游语音包管理器 · 诊断报告 ====\n");
        sb.append("生成时间: ").append(new Date().toString()).append("\n\n");
        sb.append(SelfCheck.build(c));
        sb.append("\n\n==== 崩溃记录 ====\n");
        List<File> fs = recent(c);
        if (fs.isEmpty()) {
            sb.append("（没有崩溃记录）\n");
        } else {
            for (File f : fs) {
                sb.append("\n---- ").append(f.getName()).append(" ----\n");
                try {
                    sb.append(PackStore.readText(f));
                } catch (Throwable t) {
                    sb.append("（读取失败：").append(t).append("）\n");
                }
                sb.append('\n');
            }
        }
        File tmp = new File(c.getCacheDir(), "wtm_report.txt");
        java.io.FileOutputStream fos = new java.io.FileOutputStream(tmp);
        fos.write(sb.toString().getBytes("UTF-8"));
        fos.flush();
        fos.close();
        String name = "wtm-诊断-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date()) + ".txt";
        String where;
        try {
            where = SaveToDownload.save(c, tmp, name);
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        }
        return where;
    }

    public static String appVersion(Context c) {
        try {
            PackageManager pm = c.getPackageManager();
            String vn = pm.getPackageInfo(c.getPackageName(), 0).versionName;
            return "v" + vn;
        } catch (Throwable t) {
            return "?";
        }
    }
}
