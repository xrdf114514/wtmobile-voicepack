package com.wtm.voicepack;

import android.content.Context;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * 整库备份 / 迁移。
 *
 * 为什么需要：语音包存在应用私有目录里，APK 本身不包含任何语音包；
 * 想"把我的库发给对方"或"换手机带走"，只能把库单独打包。
 *
 * 备份格式（一个 zip）：
 *   manifest.json          应用版本、时间、每个包的元数据
 *   packs/<id>/meta.json   该包元数据
 *   packs/<id>/banks/*.bank
 *   app.apk                可选：把安装包一起带上，对方一个文件搞定
 *   README.txt             怎么还原
 */
public final class LibraryBackup {

    public interface Progress {
        void onStep(String text);
    }

    public static final class Result {
        public int imported = 0;
        public int duplicated = 0;
        public int failed = 0;
        public String error = "";
    }

    private LibraryBackup() {
    }

    // ------------------------------------------------------------------ 导出

    public static File exportAll(Context c, boolean includeApk, Progress p) throws Exception {
        List<Pack> packs = PackStore.list(c);
        long totalBytes = 0;
        for (Pack pk : packs) totalBytes += pk.size;

        File cache = c.getCacheDir();
        if (cache == null) cache = new File("/data/local/tmp");
        long need = totalBytes + (includeApk ? 40L * 1024 * 1024 : 0);
        if (cache.getFreeSpace() > 0 && cache.getFreeSpace() < need + 40L * 1024 * 1024) {
            throw new Exception("临时空间不够：这库约 " + Kit.fmtSize(totalBytes)
                    + "，先清理一些不用的包再导出");
        }

        String name = "wtm-语音包库-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmm",
                java.util.Locale.US).format(new java.util.Date()) + ".zip";
        File out = new File(cache, name);
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out));
        try {
            // manifest
            JSONObject manifest = new JSONObject();
            manifest.put("app", "战雷手游语音包管理器");
            manifest.put("version", CrashLog.appVersion(c));
            manifest.put("createdAt", System.currentTimeMillis());
            manifest.put("packCount", packs.size());
            JSONArray arr = new JSONArray();
            for (Pack pk : packs) arr.put(pk.toJson());
            manifest.put("packs", arr);
            writeEntry(zos, "manifest.json", manifest.toString(2).getBytes("UTF-8"));

            // 每个包
            int i = 0;
            for (Pack pk : packs) {
                i++;
                if (p != null) p.onStep("打包 " + i + "/" + packs.size() + "：" + pk.name);
                writeEntry(zos, "packs/" + pk.id + "/meta.json", pk.toJson().toString(2).getBytes("UTF-8"));
                File banks = pk.banksDir(c);
                File[] fs = banks.listFiles();
                if (fs == null) continue;
                for (File f : fs) {
                    if (!f.isFile()) continue;
                    zipFile(zos, "packs/" + pk.id + "/banks/" + f.getName(), f);
                }
            }

            // 安装包（可选）
            if (includeApk) {
                if (p != null) p.onStep("带上安装包…");
                try {
                    String apk = c.getApplicationInfo().sourceDir;
                    if (apk != null && new File(apk).isFile()) {
                        zipFile(zos, "app.apk", new File(apk));
                    }
                } catch (Throwable ignored) {
                }
            }

            StringBuilder readme = new StringBuilder();
            readme.append("战雷手游语音包库备份\n");
            readme.append("包含 ").append(packs.size()).append(" 个语音包，共 ")
                    .append(Kit.fmtSize(totalBytes)).append("\n\n");
            readme.append("怎么用：\n");
            readme.append("1. 装好「战雷手游语音包管理器」（本压缩包里带了 app.apk 就直接装它）\n");
            readme.append("2. 打开本软件 → 语音包库 → 顶部「备份/迁移」→「从备份文件恢复整库」\n");
            readme.append("3. 选中这个 zip，等它导入完即可（相同内容的包会自动跳过，不会重复占空间）\n\n");
            readme.append("注意：语音包是否有权传播由你负责；付费/他人作品别随便转发。\n");
            writeEntry(zos, "README.txt", readme.toString().getBytes("UTF-8"));
        } catch (Throwable t) {
            try {
                zos.close();
            } catch (Throwable ignored) {
            }
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            throw new Exception("打包失败：" + (t.getMessage() == null ? t.toString() : t.getMessage()));
        } finally {
            try {
                zos.close();
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    private static void writeEntry(ZipOutputStream zos, String name, byte[] data) throws Exception {
        ZipEntry e = new ZipEntry(name);
        zos.putNextEntry(e);
        zos.write(data);
        zos.closeEntry();
    }

    private static void zipFile(ZipOutputStream zos, String entryName, File src) throws Exception {
        ZipEntry e = new ZipEntry(entryName);
        e.setTime(src.lastModified());
        zos.putNextEntry(e);
        InputStream in = new java.io.FileInputStream(src);
        try {
            byte[] buf = new byte[128 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
        } finally {
            try {
                in.close();
            } catch (Throwable ignored) {
            }
        }
        zos.closeEntry();
    }

    // ------------------------------------------------------------------ 导入

    public static Result importAll(Context c, Uri zipUri, Progress p) throws Exception {
        Result res = new Result();
        File zip = new File(c.getCacheDir(), "wtm_restore_" + System.currentTimeMillis() + ".zip");
        File work = null;
        try {
            copyUri(c, zipUri, zip);
            ZipFile zf = new ZipFile(zip, java.nio.charset.Charset.forName("UTF-8"));
            try {
                // 先找 manifest 里的包列表（没有就用目录结构兜底）
                List<String> ids = new ArrayList<String>();
                JSONObject manifest = null;
                ZipEntry me = zf.getEntry("manifest.json");
                if (me != null) {
                    manifest = new JSONObject(readAll(zf.getInputStream(me)));
                    JSONArray packs = manifest.optJSONArray("packs");
                    if (packs != null) {
                        for (int i = 0; i < packs.length(); i++) {
                            JSONObject o = packs.optJSONObject(i);
                            if (o != null) {
                                String id = o.optString("id", "");
                                if (id.length() > 0) ids.add(id);
                            }
                        }
                    }
                }

                // 收集 zip 里的 banks（按 packs/<id>/banks/ 归组）
                java.util.Map<String, List<String>> bankEntries = new java.util.LinkedHashMap<String, List<String>>();
                for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                    ZipEntry e = en.nextElement();
                    String n = e.getName();
                    if (e.isDirectory()) continue;
                    if (!n.startsWith("packs/") || !n.toLowerCase().endsWith(".bank")) continue;
                    String[] parts = n.split("/");
                    if (parts.length < 3) continue;
                    String id = parts[1];
                    if (!ids.contains(id)) ids.add(id);
                    List<String> l = bankEntries.get(id);
                    if (l == null) {
                        l = new ArrayList<String>();
                        bankEntries.put(id, l);
                    }
                    l.add(n);
                }
                if (ids.isEmpty()) throw new Exception("这个 zip 里没找到语音包（不是本软件的整库备份？）");

                int idx = 0;
                for (String id : ids) {
                    idx++;
                    List<String> entries = bankEntries.get(id);
                    if (entries == null || entries.isEmpty()) continue;
                    // 读出这个包的 meta
                    JSONObject meta = null;
                    ZipEntry mentry = zf.getEntry("packs/" + id + "/meta.json");
                    if (mentry != null) {
                        try {
                            meta = new JSONObject(readAll(zf.getInputStream(mentry)));
                        } catch (Throwable ignored) {
                        }
                    }
                    String packName = meta == null ? id : meta.optString("name", id);
                    if (p != null) p.onStep("恢复 " + idx + "/" + ids.size() + "：" + packName);

                    work = new File(PackStore.tmpDir(c), "restore_" + id);
                    Kit.clearDir(work);
                    if (!work.mkdirs() && !work.isDirectory()) throw new Exception("临时目录不可写");
                    for (String entryName : entries) {
                        String base = entryName.substring(entryName.lastIndexOf('/') + 1);
                        ZipEntry e = zf.getEntry(entryName);
                        if (e == null) continue;
                        writeTo(zf.getInputStream(e), new File(work, Kit.safeName(base)));
                    }

                    try {
                        BankImporter.Result r = BankImporter.inspectDir(work, packName);
                        Pack dup = PackStore.findByHash(c, r.hash);
                        if (dup != null) {
                            res.duplicated++;
                            continue;
                        }
                        String nm = PackStore.uniqueName(c, packName, null);
                        String note = meta == null ? "" : meta.optString("note", "");
                        Pack saved = PackStore.save(c, r, nm, note, "整库恢复");
                        if (meta != null) {
                            List<String> tags = new ArrayList<String>();
                            JSONArray ta = meta.optJSONArray("tags");
                            if (ta != null) for (int i = 0; i < ta.length(); i++) {
                                String t = ta.optString(i);
                                if (t != null && t.length() > 0) tags.add(t);
                            }
                            saved.tags = tags;
                            saved.favorite = meta.optBoolean("favorite", false);
                            PackStore.writeMeta(c, saved);
                        }
                        res.imported++;
                    } catch (Throwable t) {
                        res.failed++;
                    } finally {
                        Kit.deleteRec(work);
                        work = null;
                    }
                }
            } finally {
                try {
                    zf.close();
                } catch (Throwable ignored) {
                }
            }
        } finally {
            //noinspection ResultOfMethodCallIgnored
            zip.delete();
            if (work != null) Kit.deleteRec(work);
        }
        return res;
    }

    private static String readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        try {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        } finally {
            try {
                in.close();
            } catch (Throwable ignored) {
            }
        }
        return new String(bos.toByteArray(), "UTF-8");
    }

    private static void writeTo(InputStream in, File dst) throws Exception {
        FileOutputStream out = new FileOutputStream(dst);
        try {
            byte[] buf = new byte[128 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.getFD().sync();
        } finally {
            try {
                in.close();
            } catch (Throwable ignored) {
            }
            try {
                out.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static void copyUri(Context c, Uri uri, File dst) throws Exception {
        InputStream in = c.getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("读不到这个文件");
        writeTo(in, dst);
    }

    /** 备份文件名建议（供 UI 展示）。 */
    public static String suggestName() {
        return "wtm-语音包库-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US)
                .format(new java.util.Date()) + ".zip";
    }

    public static String platform() {
        return "Android " + Build.VERSION.RELEASE;
    }
}
