package com.wtm.voicepack;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 订阅源管理。
 *
 * 引导思路（解决「不知道源从哪来」）：
 *   · 先把「源是什么、两种填法、内容不归本软件」讲清楚；
 *   · 加之前可以「先试读」，看到源名和包数再决定；
 *   · 支持读剪贴板（别人发你地址，复制过来一贴）；
 *   · 内置 WT Live 默认停用，避免一进来全是端游大包；
 *   · 自己建源的做法放在右上「帮助」里，含可复制模板。
 */
public final class SourceActivity extends Activity implements View.OnClickListener {

    private EditText etUrl;
    private TextView btnPaste, btnPreview, btnAdd, tvPreview, tvCount, tvTitle, btnBack, btnRight;
    private ListView listSources;

    private final List<SourceStore.Source> data = new ArrayList<SourceStore.Source>();
    private SourceAdapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_sources);

        tvTitle = (TextView) findViewById(R.id.tvTitle);
        btnBack = (TextView) findViewById(R.id.btnBack);
        btnRight = (TextView) findViewById(R.id.btnRight);
        etUrl = (EditText) findViewById(R.id.etUrl);
        btnPaste = (TextView) findViewById(R.id.btnPaste);
        btnPreview = (TextView) findViewById(R.id.btnPreview);
        btnAdd = (TextView) findViewById(R.id.btnAdd);
        tvPreview = (TextView) findViewById(R.id.tvPreview);
        tvCount = (TextView) findViewById(R.id.tvCount);
        listSources = (ListView) findViewById(R.id.listSources);

        tvTitle.setText("订阅源");
        btnBack.setOnClickListener(this);
        btnRight.setText("帮助");
        btnRight.setVisibility(View.VISIBLE);
        btnRight.setOnClickListener(this);
        btnPaste.setOnClickListener(this);
        btnPreview.setOnClickListener(this);
        btnAdd.setOnClickListener(this);

        adapter = new SourceAdapter();
        listSources.setAdapter(adapter);
        listSources.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> parent, View view, int pos, long id) {
                if (pos < 0 || pos >= data.size()) return false;
                manage(data.get(pos));
                return true;
            }
        });

        refresh();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnBack) {
            finish();
        } else if (id == R.id.btnRight) {
            showHelp();
        } else if (id == R.id.btnPaste) {
            pasteClipboard();
        } else if (id == R.id.btnPreview) {
            doPreview();
        } else if (id == R.id.btnAdd) {
            doAdd();
        }
    }

    private void refresh() {
        data.clear();
        data.addAll(SourceStore.list(this));
        adapter.notifyDataSetChanged();
        int on = 0;
        for (SourceStore.Source s : data) if (s.enabled) on++;
        tvCount.setText("已有 " + data.size() + " 个源，启用中 " + on + " 个");
    }

    private void pasteClipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm == null || cm.getPrimaryClip() == null || cm.getPrimaryClip().getItemCount() == 0) {
                Kit.toast(this, "剪贴板是空的");
                return;
            }
            CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (cs == null || cs.length() == 0) {
                Kit.toast(this, "剪贴板里没有文字");
                return;
            }
            String text = cs.toString().trim();
            // 分享文本里可能夹着说明文字，抽第一个像地址的片段
            String cand = pickAddress(text);
            etUrl.setText(cand);
            Kit.toast(this, "已粘贴，点「先试读」看看里面有什么");
        } catch (Throwable t) {
            Kit.toast(this, "读剪贴板失败：" + t);
        }
    }

    private static String pickAddress(String text) {
        if (text == null) return "";
        String t = text.trim();
        if (t.startsWith("github:")) return t.split("\\s+")[0];
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?:https?://|github:)\\S+").matcher(t);
        if (m.find()) return m.group();
        return t;
    }

    private void doPreview() {
        final String input = etUrl.getText().toString().trim();
        if (input.length() == 0) {
            Kit.toast(this, "先填地址，或者点「读剪贴板」");
            return;
        }
        tvPreview.setVisibility(View.VISIBLE);
        tvPreview.setText("正在试读…");
        new Thread(new Runnable() {
            public void run() {
                final SourceStore.Preview pv = SourceStore.preview(SourceActivity.this, input);
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(SourceActivity.this)) return;
                        StringBuilder sb = new StringBuilder();
                        if (pv.ok && pv.count > 0) {
                            sb.append("✓ 源名：").append(pv.name).append('\n');
                            sb.append("✓ 包含 ").append(pv.count).append(" 个包，示例：\n");
                            int n = 0;
                            for (OnlinePack p : pv.packs) {
                                if (n++ >= 3) break;
                                sb.append("· ").append(p.title);
                                if (p.size > 0) sb.append("（").append(Kit.fmtSize(p.size)).append("）");
                                sb.append('\n');
                            }
                            sb.append("确认没问题就点「添加」。");
                        } else {
                            sb.append("✗ 试读失败：").append(pv.error);
                            if (pv.count == 0 && pv.ok) sb.append('\n').append("（能连上，但清单里没有包）");
                        }
                        tvPreview.setText(sb.toString());
                    }
                });
            }
        }, "wtm-src-preview").start();
    }

    private void doAdd() {
        final String input = etUrl.getText().toString().trim();
        if (input.length() == 0) {
            Kit.toast(this, "先填地址，或者点「读剪贴板」");
            return;
        }
        if (SourceStore.add(this, "", input)) {
            etUrl.setText("");
            tvPreview.setVisibility(View.GONE);
            refresh();
            Kit.toast(this, "已添加，回到「在线语音包」就能看到");
        } else {
            Kit.toast(this, "添加失败：地址无效，或者这个源已经有了");
        }
    }

    private void manage(final SourceStore.Source s) {
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle(s.name);
        b.setMessage((s.builtin() ? "内置源（Gaijin 官方二创站，端游素材，需要移植）\n\n"
                : "地址：" + s.url + "\n\n")
                + (s.enabled ? "当前：已启用" : "当前：已停用"));
        b.setPositiveButton(s.enabled ? "停用" : "启用", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                SourceStore.setEnabled(SourceActivity.this, s, !s.enabled);
                refresh();
            }
        });
        if (!s.builtin()) {
            b.setNeutralButton("删除", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    SourceStore.remove(SourceActivity.this, s);
                    refresh();
                    Kit.toast(SourceActivity.this, "已删除");
                }
            });
        }
        b.setNegativeButton("取消", null);
        b.show();
    }

    private void showHelp() {
        StringBuilder sb = new StringBuilder();
        sb.append("想自己做一个源？三步：\n\n");
        sb.append("1. 把移植好的成品 zip 传到 GitHub 仓库的 Release（或者任意能直链下载的地方）\n");
        sb.append("2. 写一个 index.json（点下面「复制模板」拿到），把 url 换成 zip 的直链\n");
        sb.append("3. 把 index.json 放到能公开访问的地方（GitHub Pages / raw），")
                .append("把地址发给别人，对方在「订阅源」里添加即可\n\n");
        sb.append("或者更省事：只用 GitHub Release，不用写 index.json，")
                .append("直接填 github:你的用户名/仓库 就行。\n\n");
        sb.append("⚠️ 只发自己确认手游能用的成品包；注意版权：付费/售卖包一般不能未经作者许可转载，"
                + "别人作品也别冒充成自己的。发布内容的责任由发布者承担。");

        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle("怎么自己建一个源");
        b.setMessage(sb.toString());
        b.setPositiveButton("复制模板 index.json", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.copy(SourceActivity.this, TEMPLATE, " index.json 模板");
            }
        });
        b.setNeutralButton("复制 GitHub 做法", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.copy(SourceActivity.this,
                        "1) 新建一个公开 GitHub 仓库\n"
                                + "2) 在 Releases 里新建 release，把语音包 zip 作为附件上传\n"
                                + "3) 复制附件下载链接\n"
                                + "4) 在「订阅源」里填：github:你的用户名/仓库\n"
                                + "（其他人这样填也能看到你的包；不用写 index.json、不用建服务器）",
                        "GitHub 做法");
            }
        });
        b.setNegativeButton("关闭", null);
        b.show();
    }

    private static final String TEMPLATE =
            "{\n"
                    + "  \"schema\": 1,\n"
                    + "  \"name\": \"我的语音包源\",\n"
                    + "  \"updatedAt\": \"2026-01-01\",\n"
                    + "  \"packs\": [\n"
                    + "    {\n"
                    + "      \"id\": \"p1\",\n"
                    + "      \"name\": \"空战台词替换\",\n"
                    + "      \"note\": \"作者 / 风格\",\n"
                    + "      \"size\": 12345678,\n"
                    + "      \"bankCount\": 12,\n"
                    + "      \"sha256\": \"可选的整包 sha256\",\n"
                    + "      \"url\": \"https://example.com/p1.zip\"\n"
                    + "    }\n"
                    + "  ]\n"
                    + "}\n";

    // ------------------------------------------------------------------ 适配器

    private final class SourceAdapter extends BaseAdapter {
        public int getCount() {
            return data.size();
        }

        public Object getItem(int i) {
            return data.get(i);
        }

        public long getItemId(int i) {
            return i;
        }

        public View getView(int pos, View convert, ViewGroup parent) {
            View v = convert;
            if (v == null) {
                v = LayoutInflater.from(SourceActivity.this).inflate(R.layout.item_source, parent, false);
            }
            final SourceStore.Source s = data.get(pos);
            TextView name = (TextView) v.findViewById(R.id.tvName);
            TextView type = (TextView) v.findViewById(R.id.tvType);
            TextView addr = (TextView) v.findViewById(R.id.tvAddr);
            Switch sw = (Switch) v.findViewById(R.id.swEnabled);

            name.setText(s.name);
            String t;
            if (s.builtin()) t = "内置 · WT Live（端游素材，需移植）";
            else if ("github".equals(s.type)) t = "GitHub Release · 手游成品";
            else t = "自定义清单 · 手游成品";
            type.setText(t);
            addr.setText(s.builtin() ? "builtin:wtlive" : s.url);

            sw.setOnCheckedChangeListener(null);
            sw.setChecked(s.enabled);
            sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton btn, boolean checked) {
                    SourceStore.setEnabled(SourceActivity.this, s, checked);
                    int on = 0;
                    for (SourceStore.Source x : SourceStore.list(SourceActivity.this)) if (x.enabled) on++;
                    tvCount.setText("已有 " + data.size() + " 个源，启用中 " + on + " 个");
                }
            });
            return v;
        }
    }
}
