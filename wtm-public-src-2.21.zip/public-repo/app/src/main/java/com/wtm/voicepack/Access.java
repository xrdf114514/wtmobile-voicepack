package com.wtm.voicepack;

import android.content.Context;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 权限通道：决定用什么身份去读写 Android/data 里的游戏目录。
 *
 * 安卓 11 起，普通应用（哪怕申请了「所有文件访问权限」）也读不到
 * /storage/emulated/0/Android/data/<别的包名>/ 里的东西；系统文件管理器同样不行。
 * 所以按优先级选通道：
 *   1. Shizuku（用 adb shell 身份 uid=2000 执行命令，无需 root，可随时撤销）
 *   2. root（su）
 *   3. 直连（只在 Android 9/10 及更早、或特定机型上可行）
 */
public final class Access {

    public static final int NONE = 0;
    public static final int SHIZUKU = 1;
    public static final int ROOT = 2;
    public static final int DIRECT = 3;

    public static volatile int channel = NONE;
    public static volatile String detail = "未检测";

    // root 探测结果缓存：su 可能弹窗，不能每次 onResume 都去问一遍
    private static volatile long rootCheckedAt = 0;
    private static volatile boolean rootOk = false;
    private static final long ROOT_CACHE_MS = 60_000L;

    private Access() {
    }

    public static boolean ready() {
        return channel != NONE;
    }

    public static String channelName() {
        switch (channel) {
            case SHIZUKU:
                return "Shizuku";
            case ROOT:
                return "Root";
            case DIRECT:
                return "直连路径";
            default:
                return "未就绪";
        }
    }

    public static void reset() {
        channel = NONE;
        detail = "未检测";
        rootCheckedAt = 0;
    }

    /** 后台线程调用。返回最终通道。 */
    public static synchronized int detect(Context c) {
        String pending = "";

        // 1) Shizuku
        if (Shizu.available() && Shizu.ping()) {
            if (!Shizu.hasPermission()) {
                pending = "Shizuku 已运行，但本应用还没被授权：回首页点「获取文件读写权限」";
            } else if (!Shizu.canNewProcess()) {
                pending = Shizu.loadError();
            } else {
                Result r = execShizuku(new String[]{"/system/bin/sh", "-c", "id"}, null, 8000);
                if (!r.ok() && Shizu.ping()) {
                    // 刚重启/刚授权时第一次事务偶尔失败，等一下再试一次
                    try {
                        Thread.sleep(250);
                    } catch (InterruptedException ignored) {
                    }
                    r = execShizuku(new String[]{"/system/bin/sh", "-c", "id"}, null, 8000);
                }
                if (r.ok()) {
                    channel = SHIZUKU;
                    detail = "Shizuku（shell 身份，临时授权）";
                    return channel;
                }
                pending = "Shizuku 已授权但执行失败（v" + Shizu.version() + "）：" + r.trim();
            }
        } else if (Shizu.available() && !Shizu.ping()) {
            pending = "没检测到正在运行的 Shizuku（装了就先去 Shizuku 里启动它）";
        }

        // 2) root（结果缓存 60 秒，避免反复弹 su 授权框）
        boolean needProbe = System.currentTimeMillis() - rootCheckedAt > ROOT_CACHE_MS;
        if (needProbe) {
            Result r = execRoot("id", 6000);
            rootOk = r.ok() && r.out.contains("uid=0");
            rootCheckedAt = System.currentTimeMillis();
        }
        if (rootOk) {
            channel = ROOT;
            detail = "Root（su）";
            return channel;
        }

        // 3) 直连（Android 9/10 及更早）
        File mod = new File(GameDir.modDir(c));
        File sound = new File(GameDir.soundDir(c));
        if ((mod.isDirectory() && mod.canRead()) || (sound.isDirectory() && sound.canWrite())) {
            channel = DIRECT;
            detail = "直连路径（旧系统）";
            return channel;
        }

        channel = NONE;
        detail = pending.length() > 0 ? pending : "需要 Shizuku 或 root 才能读写 Android/data";
        return channel;
    }

    // ------------------------------------------------------------------ 执行

    public static final class Result {
        public int code;
        public String out;

        Result(int code, String out) {
            this.code = code;
            this.out = out == null ? "" : out;
        }

        public boolean ok() {
            return code == 0;
        }

        public String trim() {
            return out.trim();
        }
    }

    private static final Result NONE_RESULT = new Result(-1, "");

    /** 用当前通道执行 shell 脚本（DIRECT / NONE 返回 -1）。 */
    public static Result sh(String script) {
        if (channel == SHIZUKU) {
            return execShizuku(new String[]{"/system/bin/sh", "-c", script}, null, 30000);
        } else if (channel == ROOT) {
            return execRoot(script, 30000);
        }
        return NONE_RESULT;
    }

    /** 用当前通道执行 shell 脚本，把 file 的字节流式喂给它的 stdin（不整读进内存，防 OOM）。 */
    public static Result shWithStdin(String script, File file) {
        FileInputStream in = null;
        try {
            in = new FileInputStream(file);
            if (channel == SHIZUKU) {
                Process p = Shizu.newProcess(new String[]{"/system/bin/sh", "-c", script});
                return pump(p, in, 120000);
            } else if (channel == ROOT) {
                ProcessBuilder pb = new ProcessBuilder("su", "-c", script);
                pb.redirectErrorStream(true);
                return pump(pb.start(), in, 120000);
            }
        } catch (Throwable t) {
            return new Result(-1, t.toString());
        } finally {
            try {
                if (in != null) in.close();
            } catch (Throwable ignored) {
            }
        }
        return NONE_RESULT;
    }

    private static Result execShizuku(String[] cmd, byte[] stdin, long timeout) {
        try {
            Process p = Shizu.newProcess(cmd);
            return pump(p, stdin, timeout);
        } catch (Throwable t) {
            return new Result(-1, Shizu.describe(t));
        }
    }

    private static Result execRoot(String script, long timeout) {
        try {
            ProcessBuilder pb = new ProcessBuilder("su", "-c", script);
            pb.redirectErrorStream(true);
            return pump(pb.start(), (InputStream) null, timeout);
        } catch (Throwable t) {
            return new Result(-1, t.toString());
        }
    }

    private static Result pump(Process p, byte[] stdin, long timeout) {
        if (stdin != null && stdin.length > 0) {
            try {
                OutputStream os = p.getOutputStream();
                os.write(stdin);
                os.flush();
                os.close();
            } catch (Throwable ignored) {
            }
        }
        return pump(p, (InputStream) null, timeout);
    }

    /**
     * 读进程输出 + 超时看门狗；如果给了 stdin 数据源，就开个线程边读边写，
     * 避免大文件（几十 MB 的 bank）被整个读进内存。
     */
    private static Result pump(final Process p, final InputStream stdinSrc, final long timeout) {
        final StringBuilder sb = new StringBuilder();
        Thread drain = new Thread(new Runnable() {
            public void run() {
                try {
                    InputStream err = p.getErrorStream();
                    if (err == null) return;
                    byte[] b = new byte[4096];
                    int n;
                    while ((n = err.read(b)) > 0) {
                        synchronized (sb) {
                            sb.append(new String(b, 0, n, "UTF-8"));
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
        });
        drain.setDaemon(true);
        drain.start();

        Thread feeder = null;
        if (stdinSrc != null) {
            feeder = new Thread(new Runnable() {
                public void run() {
                    try {
                        OutputStream os = p.getOutputStream();
                        byte[] buf = new byte[64 * 1024];
                        int n;
                        while ((n = stdinSrc.read(buf)) > 0) os.write(buf, 0, n);
                        os.flush();
                        os.close();
                    } catch (Throwable ignored) {
                    }
                }
            });
            feeder.setDaemon(true);
            feeder.start();
        }

        try {
            InputStream in = p.getInputStream();
            long end = System.currentTimeMillis() + timeout;
            byte[] buf = new byte[8192];
            boolean killed = false;
            while (true) {
                while (in.available() > 0) {
                    int n = in.read(buf);
                    if (n <= 0) break;
                    synchronized (sb) {
                        sb.append(new String(buf, 0, n, "UTF-8"));
                    }
                }
                try {
                    int code = p.exitValue();
                    // 进程刚退出时管道里可能还有尾巴，再收一轮（不阻塞）
                    long grace = System.currentTimeMillis() + 400;
                    while (System.currentTimeMillis() < grace) {
                        if (in.available() <= 0) break;
                        int n = in.read(buf);
                        if (n <= 0) break;
                        synchronized (sb) {
                            sb.append(new String(buf, 0, n, "UTF-8"));
                        }
                    }
                    return new Result(code, snapshot(sb));
                } catch (IllegalArgumentException notExited) {
                    // 注意：Shizuku 的远端进程会把「还没退出」的 IllegalThreadStateException
                    // 通过 Binder 折成 IllegalArgumentException（"process hasn't exited"），
                    // 所以这里必须catch父类，否则第一次轮询就直接失败了。
                    if (System.currentTimeMillis() > end) {
                        try {
                            p.destroy();
                        } catch (Throwable ignored) {
                        }
                        killed = true;
                        break;
                    }
                    try {
                        Thread.sleep(40);
                    } catch (InterruptedException ignored) {
                    }
                }
            }
            return new Result(-1, killed ? ("执行超时：" + snapshot(sb)) : snapshot(sb));
        } catch (Throwable t) {
            return new Result(-1, t.toString());
        } finally {
            try {
                drain.join(300);
            } catch (Throwable ignored) {
            }
            if (feeder != null) {
                try {
                    feeder.join(300);
                } catch (Throwable ignored) {
                }
            }
            try {
                if (stdinSrc != null) stdinSrc.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static String snapshot(StringBuilder sb) {
        synchronized (sb) {
            return sb.toString();
        }
    }
}
