package com.wtm.voicepack;

import android.content.Context;

/**
 * 使用条款与免责声明。
 *
 * 定位：本软件只是本地文件管理工具，不提供/不托管/不销售任何语音包内容；
 * 在线列表全部来自用户自行添加的第三方源；改包有违反游戏条款的风险。
 * 首次启动要求确认一次，之后可以在设置里随时查看。
 */
public final class Disclaimer {

    /** 条款版本：改条款内容时 +1，会重新让用户确认。 */
    public static final int VERSION = 1;

    private static final String KEY_ACCEPTED = "disclaimer_accepted_v";

    private Disclaimer() {
    }

    public static boolean accepted(Context c) {
        return Prefs.p(c).getInt(KEY_ACCEPTED, 0) >= VERSION;
    }

    public static void accept(Context c) {
        Prefs.p(c).edit().putInt(KEY_ACCEPTED, VERSION).apply();
    }

    public static void revoke(Context c) {
        Prefs.p(c).edit().remove(KEY_ACCEPTED).apply();
    }

    public static String title() {
        return "使用条款与免责声明";
    }

    /** 显示条款；不可取消，必须选同意或退出。 */
    public static void show(final android.app.Activity a, final Runnable onAccept, final Runnable onDecline) {
        try {
            android.view.View v = android.view.LayoutInflater.from(a).inflate(R.layout.dialog_terms, null);
            android.widget.TextView tv = (android.widget.TextView) v.findViewById(R.id.tvTerms);
            if (tv != null) tv.setText(text());
            android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a, R.style.DialogTheme);
            b.setTitle(title());
            b.setView(v);
            b.setCancelable(false);
            b.setPositiveButton("同意并继续", new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface d, int w) {
                    accept(a);
                    if (onAccept != null) onAccept.run();
                }
            });
            b.setNegativeButton("不同意，退出", new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface d, int w) {
                    if (onDecline != null) onDecline.run();
                }
            });
            b.show();
        } catch (Throwable t) {
            // 弹窗失败也不能把用户挡在外面
            accept(a);
            if (onAccept != null) onAccept.run();
        }
    }

    public static String text() {
        return "《战雷手游语音包管理器》使用条款与免责声明\n"
                + "条款版本 v" + VERSION + "（对应应用 " + "v1.9" + "）\n\n"
                + "一、这个软件是什么\n"
                + "1. 本软件是一个本地文件管理工具：把你自己提供的 .zip/.bank 语音文件整理到游戏目录，"
                + "并支持切换、导出、分享。\n"
                + "2. 本软件不提供、不托管、不内置、不销售任何语音包、音效或游戏资源。"
                + "「在线语音包」里的内容全部来自你自行添加的第三方地址，本软件不抓取、不审核、不背书。\n"
                + "3. 本软件与 Gaijin Entertainment、《战争雷霆》及其关联方没有任何关系，未获其授权或背书；"
                + "相关游戏名称、商标归各自权利人所有。\n\n"
                + "二、内容与版权\n"
                + "4. 语音包内容的版权归原作者或相应权利人所有。请从作者的正规渠道获取，并遵守作者的授权范围。\n"
                + "5. 购买或付费获取某个语音包，不等于获得再分发授权。未经权利人许可，请不要转售、"
                + "公开发布或大范围传播他人作品。\n"
                + "6. 制作和分享二创语音（含 AI 克隆声音、配音、动漫/游戏台词）可能涉及著作权、"
                + "声音权益、肖像权等风险，请自行确认合法性并自负责任。\n"
                + "7. 语音包的内容指纹（包 ID 是内容哈希）只用于本地去重和识别，不含任何个人信息；"
                + "但公开分享指纹等同于公开该内容的身份，请谨慎。\n\n"
                + "三、改包与账号风险\n"
                + "8. 自制语音依赖「改包让游戏优先加载 mod」。修改游戏文件可能违反游戏的用户协议，"
                + "可能导致账号被限制或封禁。是否改包、怎么改包由你自行决定并承担后果，本软件不提供改包功能。\n\n"
                + "四、使用与责任\n"
                + "9. 本软件按「现状」提供，不承诺任何功能可用性、兼容性或数据绝对安全。"
                + "因使用本软件导致的文件丢失、设备损坏、账号封禁、时间或经济损失等，开发者不承担责任。\n"
                + "10. 请勿使用本软件传播违法违规、侵权、恶意或有害内容，相关法律责任由使用者承担。\n"
                + "11. 本软件只处理你主动选择的文件和你主动添加的地址，不代替你做任何网络下载以外的自动化操作；"
                + "对第三方源的内容、可用性、安全性不做任何保证。\n\n"
                + "五、隐私\n"
                + "12. 本软件没有账号系统，不做使用统计，不上传你的语音包。仅在你主动添加订阅源、"
                + "下载在线包、使用「从链接导入」或「启动游戏」时，才访问对应的地址或应用。\n"
                + "13. 「导出诊断日志」生成的文本包含机型、路径和崩溃堆栈，只保存在你本机；"
                + "对外发送前请自行检查并脱敏。\n\n"
                + "六、其他\n"
                + "14. 本声明用于说明使用边界，不构成法律意见。如果你不同意以上条款，"
                + "请卸载并停止使用本软件。继续使用即视为你已阅读并同意本声明。\n";
    }
}
