package com.wtm.voicepack;

import android.content.Context;
import android.content.Intent;

/**
 * 启动游戏。
 * 注意 targetSdk 30+ 的包可见性：manifest 里声明了 MAIN/LAUNCHER 的 &lt;queries&gt;，
 * 否则 getLaunchIntentForPackage 对没被“看见”的包会返回 null。
 * 换包后启动游戏是必要的——语音包不是热加载的，得重进游戏才生效。
 */
public final class GameLauncher {

    private GameLauncher() {
    }

    public static boolean installed(Context c) {
        try {
            android.content.pm.PackageManager pm = c.getPackageManager();
            if (pm.getLaunchIntentForPackage(Prefs.pkg(c)) != null) return true;
            Intent i = new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setPackage(Prefs.pkg(c));
            return pm.resolveActivity(i, 0) != null;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean launch(Context c) {
        try {
            android.content.pm.PackageManager pm = c.getPackageManager();
            Intent i = pm.getLaunchIntentForPackage(Prefs.pkg(c));
            if (i == null) {
                i = new Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setPackage(Prefs.pkg(c));
                if (pm.resolveActivity(i, 0) == null) return false;
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 启动失败时给用户看的说明。 */
    public static void explain(Context c) {
        Kit.confirm(c, "没找到游戏",
                "按当前包名「" + Prefs.pkg(c) + "」没找到可启动的战争雷霆手游。\n\n"
                        + "· 没装游戏：先去应用商店装\n"
                        + "· 包名不对：到「设置与存储」里改，或点「自动检测游戏包名」\n"
                        + "· 游戏装了但玩家号（多开/分身）不是同一个：本软件只认这个包名",
                "去设置", new Runnable() {
                    public void run() {
                        try {
                            c.startActivity(new Intent(c, SettingsActivity.class)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        } catch (Throwable ignored) {
                        }
                    }
                });
    }
}
