package com.wtm.voicepack;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 一坨小工具：尺寸格式化、对话框、剪贴板、圆角背景、文件递归操作。 */
public final class Kit {

    private Kit() {
    }

    public static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics()));
    }

    public static void toast(Context c, String s) {
        if (c != null && !TextUtils.isEmpty(s)) {
            Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
        }
    }

    public static String fmtSize(long bytes) {
        if (bytes < 0) return "—";
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb);
        return String.format(Locale.US, "%.2f GB", mb / 1024.0);
    }

    public static String fmtTime(long ms) {
        if (ms <= 0) return "—";
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(new Date(ms));
    }

    public static String fmtAgo(long ms) {
        if (ms <= 0) return "从未";
        long d = System.currentTimeMillis() - ms;
        if (d < 60 * 1000L) return "刚刚";
        if (d < 3600 * 1000L) return (d / 60000L) + " 分钟前";
        if (d < 24 * 3600 * 1000L) return (d / 3600000L) + " 小时前";
        if (d < 30 * 24 * 3600 * 1000L) return (d / 86400000L) + " 天前";
        return fmtTime(ms);
    }

    public static void copy(Context c, String text, String label) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, text));
            toast(c, "已复制" + (label == null ? "" : label));
        } catch (Throwable t) {
            toast(c, "复制失败");
        }
    }

    public static void openUrl(Context c, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            toast(c, "没有可用的浏览器");
        }
    }

    public static void openApp(Context c, String pkg) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            toast(c, "没找到这个应用");
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
        } catch (Throwable t) {
            toast(c, "打开失败");
        }
    }

    public static AlertDialog msg(Context c, String title, String message) {
        AlertDialog.Builder b = new AlertDialog.Builder(c, R.style.DialogTheme);
        b.setTitle(title);
        b.setMessage(message);
        b.setPositiveButton("知道了", null);
        AlertDialog d = b.create();
        d.show();
        return d;
    }

    public static AlertDialog confirm(Context c, String title, String message, String ok,
                                      final Runnable onOk) {
        AlertDialog.Builder b = new AlertDialog.Builder(c, R.style.DialogTheme);
        b.setTitle(title);
        b.setMessage(message);
        b.setNegativeButton("取消", null);
        b.setPositiveButton(ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                if (onOk != null) onOk.run();
            }
        });
        AlertDialog d = b.create();
        d.show();
        return d;
    }

    /**
     * 成功提示：「确定」+ 可选动作（如「启动游戏」）。
     * 以前这里用 confirm()，会多出一个「取消」，看起来像是操作没成功，容易误解。
     */
    public static AlertDialog done(Context c, String title, String message,
                                   String actionLabel, final Runnable onAction) {
        AlertDialog.Builder b = new AlertDialog.Builder(c, R.style.DialogTheme);
        b.setTitle(title);
        b.setMessage(message);
        b.setNegativeButton("确定", null);
        if (actionLabel != null && actionLabel.length() > 0 && onAction != null) {
            b.setPositiveButton(actionLabel, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    onAction.run();
                }
            });
        }
        AlertDialog d = b.create();
        d.show();
        return d;
    }

    /** 失败提示：重试 / 取消 / 可选动作（如「启动游戏」）。 */
    public static AlertDialog failed(Context c, String title, String message,
                                     final Runnable onRetry, String actionLabel,
                                     final Runnable onAction) {
        AlertDialog.Builder b = new AlertDialog.Builder(c, R.style.DialogTheme);
        b.setTitle(title);
        b.setMessage(message);
        b.setNegativeButton("重试", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                if (onRetry != null) onRetry.run();
            }
        });
        b.setNeutralButton("取消", null);
        if (actionLabel != null && actionLabel.length() > 0 && onAction != null) {
            b.setPositiveButton(actionLabel, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    onAction.run();
                }
            });
        }
        AlertDialog d = b.create();
        d.show();
        return d;
    }

    public static void tint(TextView tv, int color) {
        if (tv != null) tv.setTextColor(color);
    }

    public static GradientDrawable round(Context c, int fill, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, radiusDp,
                c.getResources().getDisplayMetrics()));
        if (strokeColor != 0) {
            g.setStroke(dp(c, 1), strokeColor);
        }
        return g;
    }

    public static long dirSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long sum = 0;
        File[] cs = f.listFiles();
        if (cs == null) return 0;
        for (File c : cs) sum += dirSize(c);
        return sum;
    }

    public static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] cs = f.listFiles();
            if (cs != null) for (File c : cs) deleteRec(c);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    /** 清空目录内容但保留目录本身。 */
    public static void clearDir(File dir) {
        if (dir == null || !dir.isDirectory()) return;
        File[] cs = dir.listFiles();
        if (cs != null) for (File c : cs) deleteRec(c);
    }

    /** 复制文件（保留源文件）。 */
    public static boolean copyFile(File src, File dst) {
        java.io.FileInputStream in = null;
        java.io.FileOutputStream out = null;
        try {
            if (dst.getParentFile() != null) dst.getParentFile().mkdirs();
            in = new java.io.FileInputStream(src);
            out = new java.io.FileOutputStream(dst);
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.getFD().sync();
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            try {
                if (out != null) out.close();
            } catch (Throwable ignored) {
            }
            try {
                if (in != null) in.close();
            } catch (Throwable ignored) {
            }
        }
    }

    public static boolean moveFile(File src, File dst) {
        try {
            if (dst.getParentFile() != null) dst.getParentFile().mkdirs();
            if (src.renameTo(dst)) return true;
        } catch (Throwable ignored) {
        }
        // 跨文件系统时退回复制
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(src);
            java.io.FileOutputStream out = new java.io.FileOutputStream(dst);
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.getFD().sync();
            out.close();
            in.close();
            //noinspection ResultOfMethodCallIgnored
            src.delete();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 文件名安全化：去掉路径分隔符、控制字符和会破坏 shell 命令的符号，截断时保留扩展名。 */
    public static String safeName(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch < 0x20 || ch == 0x7f) continue;               // 控制字符（含换行）会让 shell 脚本断掉
            if (ch == '/' || ch == '\\' || ch == ':' || ch == '*' || ch == '?' || ch == '"'
                    || ch == '<' || ch == '>' || ch == '|' || ch == '\'' || ch == '`' || ch == '$') {
                sb.append('_');
            } else {
                sb.append(ch);
            }
        }
        String r = sb.toString().trim();
        if (r.length() > 80) {
            String ext = "";
            int dot = r.lastIndexOf('.');
            if (dot > 0 && r.length() - dot <= 8) ext = r.substring(dot);
            r = r.substring(0, 80 - ext.length()) + ext;
        }
        return r;
    }

    /** Activity 还活着才允许弹窗，避免 "Unable to add window" 崩溃。 */
    public static boolean alive(android.app.Activity a) {
        return a != null && !a.isFinishing() && !a.isDestroyed();
    }
}
