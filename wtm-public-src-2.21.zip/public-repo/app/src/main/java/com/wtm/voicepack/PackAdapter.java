package com.wtm.voicepack;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** 语音包列表适配器（支持多选模式）。 */
public final class PackAdapter extends BaseAdapter {

    private final Activity act;
    private final List<Pack> data = new ArrayList<Pack>();
    private String appliedId = "";
    private boolean selecting = false;
    private final Set<String> selected = new HashSet<String>();

    private static final int[] ACCENTS = new int[]{
            0xFFF5B324, 0xFF4DA3FF, 0xFF3ED598, 0xFFFF8A5B, 0xFFB98BFF, 0xFFFF6B9A
    };

    public PackAdapter(Activity a) {
        this.act = a;
    }

    public void setData(List<Pack> list, String appliedId) {
        data.clear();
        if (list != null) data.addAll(list);
        this.appliedId = appliedId == null ? "" : appliedId;
        notifyDataSetChanged();
    }

    public void setSelecting(boolean on) {
        selecting = on;
        if (!on) selected.clear();
        notifyDataSetChanged();
    }

    public boolean isSelecting() {
        return selecting;
    }

    public boolean toggle(String id) {
        if (id == null) return false;
        if (selected.contains(id)) {
            selected.remove(id);
            notifyDataSetChanged();
            return false;
        }
        selected.add(id);
        notifyDataSetChanged();
        return true;
    }

    public void selectAll(List<Pack> visible) {
        selected.clear();
        if (visible != null) for (Pack p : visible) selected.add(p.id);
        notifyDataSetChanged();
    }

    public void clearSelection() {
        selected.clear();
        notifyDataSetChanged();
    }

    public Set<String> selectedIds() {
        return selected;
    }

    public Pack getItem(int i) {
        return data.get(i);
    }

    public int getCount() {
        return data.size();
    }

    public long getItemId(int i) {
        return i;
    }

    public View getView(int pos, View convert, ViewGroup parent) {
        View v = convert;
        if (v == null) {
            v = LayoutInflater.from(act).inflate(R.layout.item_pack, parent, false);
        }
        Pack p = data.get(pos);

        TextView name = (TextView) v.findViewById(R.id.tvName);
        TextView meta = (TextView) v.findViewById(R.id.tvMeta);
        TextView size = (TextView) v.findViewById(R.id.tvSize);
        TextView badge = (TextView) v.findViewById(R.id.tvBadge);
        TextView check = (TextView) v.findViewById(R.id.tvCheck);
        View accent = v.findViewById(R.id.vAccent);

        name.setText(p.name);

        StringBuilder m = new StringBuilder();
        m.append(p.count).append(" 个 bank");
        if (p.note != null && p.note.length() > 0) m.append(" · ").append(p.note);
        if (!p.tags.isEmpty()) m.append(" · ").append(p.tagsLine());
        meta.setText(m.toString());
        size.setText(Kit.fmtSize(p.size));

        if (selecting) {
            check.setVisibility(View.VISIBLE);
            check.setText(selected.contains(p.id) ? "☑" : "☐");
        } else {
            check.setVisibility(View.GONE);
        }

        boolean applied = appliedId != null && appliedId.equals(p.id);
        StringBuilder b = new StringBuilder();
        if (applied) b.append("● 使用中");
        if (p.favorite) {
            if (b.length() > 0) b.append("  ");
            b.append("★");
        }
        if (b.length() > 0) {
            badge.setText(b.toString());
            badge.setVisibility(View.VISIBLE);
            badge.setTextColor(act.getResources().getColor(
                    applied ? R.color.green : R.color.gold));
        } else {
            badge.setVisibility(View.GONE);
        }

        String key = p.id == null ? (p.name == null ? "" : p.name) : p.id;
        int color = ACCENTS[(key.hashCode() & 0x7fffffff) % ACCENTS.length];
        accent.setBackground(Kit.round(act, color, 3, 0));

        return v;
    }
}
