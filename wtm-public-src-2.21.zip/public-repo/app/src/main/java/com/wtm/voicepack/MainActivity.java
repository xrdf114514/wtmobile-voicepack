package com.wtm.voicepack;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class MainActivity extends Activity implements View.OnClickListener {

    private TextView tvSubtitle, tvApplied, tvAppliedSub, tvAndroid, tvPerm, tvDirState, tvGame, tvPath,
            btnPerm, tvStorage, tvStorageSub;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean detecting = false;
    private boolean legacyChecked = false;
    private boolean termsShown = false;
    private boolean modChecked = false;
    private volatile ModCheck.Issue lastIssue = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        tvSubtitle = (TextView) findViewById(R.id.tvSubtitle);
        tvApplied = (TextView) findViewById(R.id.tvApplied);
        tvAppliedSub = (TextView) findViewById(R.id.tvAppliedSub);
        tvAndroid = (TextView) findViewById(R.id.tvAndroid);
        tvPerm = (TextView) findViewById(R.id.tvPerm);
        tvDirState = (TextView) findViewById(R.id.tvDirState);
        tvGame = (TextView) findViewById(R.id.tvGame);
        tvPath = (TextView) findViewById(R.id.tvPath);
        btnPerm = (TextView) findViewById(R.id.btnPerm);
        tvStorage = (TextView) findViewById(R.id.tvStorage);
        tvStorageSub = (TextView) findViewById(R.id.tvStorageSub);

        int[] clickable = new int[]{
                R.id.btnImport, R.id.btnLibrary, R.id.btnQuick, R.id.btnGuide,
                R.id.btnSettings, R.id.btnClean, R.id.btnRestore, R.id.btnPerm, R.id.btnStore,
                R.id.btnLaunch, R.id.btnGameStatus
        };
        View shizukuInfo = findViewById(R.id.tvShizuku);
        if (shizukuInfo != null) {
            shizukuInfo.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    ShizukuGuide.helpDialog(MainActivity.this);
                }
            });
        }
        for (int id : clickable) {
            View v = findViewById(id);
            if (v != null) v.setOnClickListener(this);
        }
        ensureLegacyPermission();

        // 首次启动：确认使用条款与免责声明（不可取消，要么同意要么退出）
        if (!Disclaimer.accepted(this) && !termsShown) {
            termsShown = true;
            Disclaimer.show(this, null, new Runnable() {
                public void run() {
                    finishAffinity();
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshLibrary();
        refreshApplied();
        detect();
    }

    /** Android 9 及更早走直连路径时需要存储权限（新系统上这两条权限本身已经没用了）。 */
    private void ensureLegacyPermission() {
        if (Build.VERSION.SDK_INT > 28) return;
        try {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                }, 2001);
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        detect();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnImport) {
            startActivity(new Intent(this, ImportActivity.class));
        } else if (id == R.id.btnLibrary) {
            startActivity(new Intent(this, LibraryActivity.class));
        } else if (id == R.id.btnQuick) {
            Intent i = new Intent(this, LibraryActivity.class);
            i.putExtra(LibraryActivity.EXTRA_PICK, true);
            startActivity(i);
        } else if (id == R.id.btnGuide) {
            startActivity(new Intent(this, GuideActivity.class));
        } else if (id == R.id.btnSettings) {
            startActivity(new Intent(this, SettingsActivity.class));
        } else if (id == R.id.btnClean) {
            doClean();
        } else if (id == R.id.btnRestore) {
            doRestore();
        } else if (id == R.id.btnPerm) {
            permissionFlow();
        } else if (id == R.id.btnStore) {
            startActivity(new Intent(this, StoreActivity.class));
        } else if (id == R.id.btnLaunch) {
            launchGame();
        } else if (id == R.id.btnGameStatus) {
            launchGame();
        }
    }

    /** 每次启动静默检查一次：mod 目录里是不是同一套、有没有重复/残留。 */
    private void checkModDirOnce() {
        if (modChecked) return;
        modChecked = true;
        if (!Access.ready()) return;
        new Thread(new Runnable() {
            public void run() {
                final ModCheck.Issue is = ModCheck.check(MainActivity.this);
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(MainActivity.this) || is == null) return;
                        lastIssue = is;
                        if (is.hasProblem) showModIssue(is, false);
                    }
                });
            }
        }, "wtm-mod-check").start();
    }

    /**
     * 目录和库不一致时的处理。
     * 三类情况用同一个入口：
     *   · 目录里的文件不在任何库里   → 可「保存为新语音包」
     *   · 目录是某个库包的减量版     → 可「保存为新语音包」或「用库里的包覆盖（补齐）」
     *   · 目录是某个库包的增量版     → 可「保存为新语音包」或「用库里的包覆盖（去掉多的）」
     * fromLaunch=true 表示是点「启动游戏」前拦下来的，最后一项多"并启动"。
     */
    private void showModIssue(final ModCheck.Issue is, final boolean fromLaunch) {
        final Pack nearPack = is.near ? PackStore.findById(this, is.nearPackId) : null;
        final Pack appliedPack = PackStore.findById(this, Prefs.appliedId(this));

        final java.util.List<String> labels = new ArrayList<String>();
        final java.util.List<Integer> actions = new ArrayList<Integer>();
        final int ACT_SAVE = 1, ACT_USE_NEAR = 2, ACT_REAPPLY = 3, ACT_CLEAR = 4, ACT_IGNORE = 5;

        labels.add("📥 把当前目录的文件保存为语音包");
        actions.add(ACT_SAVE);
        if (nearPack != null) {
            labels.add(is.nearMissing > 0
                    ? "🧩 用库里的「" + nearPack.name + "」补齐（目录少 " + is.nearMissing + " 个）"
                    : "🧩 用库里的「" + nearPack.name + "」覆盖（去掉目录多的 " + is.nearExtra + " 个）");
            actions.add(ACT_USE_NEAR);
        }
        if (appliedPack != null && (nearPack == null || !appliedPack.id.equals(nearPack.id))) {
            labels.add("⚡ 重新应用「" + appliedPack.name + "」");
            actions.add(ACT_REAPPLY);
        }
        labels.add("🧹 清空目录，恢复原版语音");
        actions.add(ACT_CLEAR);
        labels.add(fromLaunch ? "▶ 不管了，仍然启动游戏" : "👌 我不关心，继续使用");
        actions.add(ACT_IGNORE);

        StringBuilder msg = new StringBuilder();
        msg.append(ModCheck.report(is));
        if (nearPack != null) {
            msg.append("\n\n判断依据：只按文件名+大小比对，且是「完全相同文件 + 一方缺少若干文件」的增量/减量关系。");
        }
        msg.append("\n\n要怎么做？");

        // 坑：AlertDialog.Builder 同时 setMessage() + setItems() 时，message 会把列表顶掉，
        // 结果就只剩一个「关闭」按钮（用户反馈过）。这里改成自定义内容视图：
        // 上面是报告正文，下面是可点的选项行，两样都在。
        final AlertDialog[] holder = new AlertDialog[1];
        int pad = Kit.dp(this, 18);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView body = new TextView(this);
        body.setText(msg.toString());
        body.setTextSize(14);
        body.setTextColor(getColorCompat(R.color.text));
        body.setPadding(pad, pad, pad, Kit.dp(this, 8));
        box.addView(body);
        for (int i = 0; i < labels.size(); i++) {
            final int idx = i;
            TextView row = new TextView(this);
            row.setText(labels.get(i));
            row.setTextSize(15);
            row.setTextColor(getColorCompat(R.color.gold));
            row.setPadding(pad, Kit.dp(this, 13), pad, Kit.dp(this, 13));
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (holder[0] != null) holder[0].dismiss();
                    handleModAction(actions.get(idx), is, nearPack, appliedPack, fromLaunch);
                }
            });
            box.addView(row);
        }
        ScrollView scroller = new ScrollView(this);
        scroller.addView(box);

        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle("语音目录和语音包库不一致");
        b.setView(scroller);
        b.setNegativeButton("关闭", null);
        holder[0] = b.create();
        holder[0].show();
    }

    /** 目录自检弹窗里选了某一项之后要做的事。 */
    private void handleModAction(int act, final ModCheck.Issue is, final Pack nearPack,
                                 final Pack appliedPack, final boolean fromLaunch) {
        final int ACT_SAVE = 1, ACT_USE_NEAR = 2, ACT_REAPPLY = 3, ACT_CLEAR = 4, ACT_IGNORE = 5;
        if (act == ACT_SAVE) {
            saveDirToLibrary(is, nearPack);
        } else if (act == ACT_USE_NEAR && nearPack != null) {
            doApplyPack(nearPack, fromLaunch);
        } else if (act == ACT_REAPPLY && appliedPack != null) {
            doApplyPack(appliedPack, fromLaunch);
        } else if (act == ACT_CLEAR) {
            Installer.restoreAsync(MainActivity.this, new Installer.Listener() {
                public void onProgress(String text) {
                }

                public void onDone(boolean ok, String message) {
                    if (!Kit.alive(MainActivity.this)) return;
                    Kit.msg(MainActivity.this, ok ? "完成" : "没成功", message);
                    modChecked = false;
                    detect();
                }
            });
        } else if (act == ACT_IGNORE && fromLaunch) {
            launchGameNow();
        }
    }

    /**
     * 换包前先兜一层：目标目录里如果有「不是本软件写进去的」.bank（比如游戏原版声音、
     * 或者别的工具放的包），换包会把它们删掉，必须让用户确认一次。
     * 以前只有语音包库那条路径会问，从首页「快捷更换」进来是直接覆盖的，容易把原版语音误删。
     */
    private void doApplyPack(final Pack p, final boolean thenLaunch) {
        final java.util.List<String> unknown = Installer.unknownBanks(this);
        if (!unknown.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            sb.append("目标目录里现在有 ").append(unknown.size())
                    .append(" 个不是本软件写入的语音文件，换包会把它们删掉：\n\n");
            int i = 0;
            for (String s : unknown) {
                if (i++ >= 6) {
                    sb.append("…等 ").append(unknown.size()).append(" 个");
                    break;
                }
                sb.append("· ").append(s).append('\n');
            }
            sb.append("\n如果这些是你想留的（比如游戏原版语音），先点「取消」，");
            sb.append("再在首页弹出的「语音目录和语音包库不一致」里选「把当前目录的文件保存为语音包」。");
            Kit.confirm(this, "会被覆盖的文件", sb.toString(), "继续覆盖", new Runnable() {
                public void run() {
                    doApplyPackForce(p, thenLaunch);
                }
            });
            return;
        }
        doApplyPackForce(p, thenLaunch);
    }

    private void doApplyPackForce(final Pack p, final boolean thenLaunch) {
        final android.app.ProgressDialog pd = new android.app.ProgressDialog(this);
        pd.setMessage("正在写入游戏目录…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        Installer.applyAsync(this, p, new Installer.Listener() {
            public void onProgress(String text) {
                try {
                    pd.setMessage(text);
                } catch (Throwable ignored) {
                }
            }

            public void onDone(boolean ok, String message) {
                try {
                    pd.dismiss();
                } catch (Throwable ignored) {
                }
                if (!Kit.alive(MainActivity.this)) return;
                modChecked = false;
                if (ok) {
                    Kit.done(MainActivity.this, "换好了", message,
                            thenLaunch ? "启动游戏" : null,
                            thenLaunch ? new Runnable() {
                                public void run() {
                                    launchGameNow();
                                }
                            } : null);
                } else {
                    Kit.failed(MainActivity.this, "换包没成功", message,
                            new Runnable() {
                                public void run() {
                                    doApplyPack(p, thenLaunch);
                                }
                            },
                            thenLaunch ? "启动游戏" : null,
                            thenLaunch ? new Runnable() {
                                public void run() {
                                    launchGameNow();
                                }
                            } : null);
                }
                detect();
            }
        });
    }

    /** 把游戏目录里当前实际生效的文件拷回来，存成一个语音包（并把"当前生效"指向它）。 */
    private void saveDirToLibrary(final ModCheck.Issue is, final Pack nearPack) {
        final android.app.ProgressDialog pd = new android.app.ProgressDialog(this);
        pd.setMessage("正在把目录文件存进语音包库…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        new Thread(new Runnable() {
            public void run() {
                File work = new File(PackStore.tmpDir(MainActivity.this),
                        "pull_" + System.currentTimeMillis());
                String err = null;
                Pack saved = null;
                String dupName = null;
                try {
                    List<String> names = GameDir.listBanks(MainActivity.this);
                    if (names.isEmpty()) throw new Exception("目录里没有 .bank 文件（刚被清空了？）");
                    Kit.clearDir(work);
                    int pulled = GameDir.pullBanks(MainActivity.this, names, work);
                    if (pulled == 0) throw new Exception("拷不回来（权限被回收或空间不足）");
                    String base = nearPack != null ? nearPack.name + "（目录版）"
                            : "目录快照 " + Kit.fmtTime(System.currentTimeMillis());
                    BankImporter.Result r = BankImporter.inspectDir(work, base);
                    Pack dup = PackStore.findByHash(MainActivity.this, r.hash);
                    if (dup != null) {
                        dupName = dup.name;
                        // 内容已经在库里：直接把"当前生效"指向它
                        Prefs.setApplied(MainActivity.this, dup.id, dup.name, dup.banks.size());
                        Prefs.setWrittenFiles(MainActivity.this, dup.banks);
                    } else {
                        String nm = PackStore.uniqueName(MainActivity.this, base, null);
                        String note = nearPack != null ? nearPack.note : "从游戏目录保存";
                        saved = PackStore.save(MainActivity.this, r, nm, note, "目录保存");
                        if (nearPack != null) {
                            saved.tags = new ArrayList<String>(nearPack.tags);
                            PackStore.writeMeta(MainActivity.this, saved);
                        }
                        Prefs.setApplied(MainActivity.this, saved.id, saved.name, saved.count);
                        Prefs.setWrittenFiles(MainActivity.this, names);
                    }
                    Prefs.bumpImportCount(MainActivity.this);
                } catch (Throwable t) {
                    String m = t.getMessage();
                    err = (m == null || m.length() == 0) ? t.toString() : m;
                } finally {
                    Kit.deleteRec(work);
                }
                final String fErr = err;
                final Pack fSaved = saved;
                final String fDup = dupName;
                ui.post(new Runnable() {
                    public void run() {
                        try {
                            pd.dismiss();
                        } catch (Throwable ignored) {
                        }
                        if (!Kit.alive(MainActivity.this)) return;
                        if (fErr != null) {
                            Kit.msg(MainActivity.this, "保存失败", fErr);
                            return;
                        }
                        if (fSaved != null) {
                            Kit.msg(MainActivity.this, "已存入语音包库",
                                    "新语音包：「" + fSaved.name + "」" + fSaved.count + " 个文件 · "
                                            + Kit.fmtSize(fSaved.size) + "\n\n已把它标记为当前生效。");
                        } else {
                            Kit.msg(MainActivity.this, "库里已有同样的内容",
                                    "目录文件和库里「" + fDup + "」完全一致，没有重复保存，"
                                            + "已把「当前生效」指向它。");
                        }
                        modChecked = false;
                        detect();
                    }
                });
            }
        }, "wtm-pull-mod").start();
    }

    /** v1.7 之前路径写错，旧位置可能有残留的 bank（游戏不会读，纯占空间）。 */
    private void askCleanLegacy(final int count) {
        Kit.confirm(this, "发现旧位置的残留文件",
                "之前的版本把语音包写到了 " + GameDir.legacyModDir(this) + "（少了 files，游戏不会读）。\n\n"
                        + "里面有 " + count + " 个 .bank，可以帮你删掉腾空间；要保留就点取消。",
                "删除旧残留", new Runnable() {
                    public void run() {
                        new Thread(new Runnable() {
                            public void run() {
                                final int n = GameDir.clearLegacyBanks(MainActivity.this);
                                ui.post(new Runnable() {
                                    public void run() {
                                        Kit.toast(MainActivity.this, "已清理 " + n + " 个旧文件");
                                    }
                                });
                            }
                        }, "wtm-legacy-clean").start();
                    }
                });
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    // ------------------------------------------------------------------ 启动游戏

    private void launchGame() {
        if (!Access.ready()) {
            launchGameNow();
            return;
        }
        Kit.toast(this, "启动前检查一下语音目录…");
        new Thread(new Runnable() {
            public void run() {
                final ModCheck.Issue is = ModCheck.check(MainActivity.this);
                ui.post(new Runnable() {
                    public void run() {
                        if (!Kit.alive(MainActivity.this)) return;
                        lastIssue = is;
                        if (is != null && is.hasProblem) {
                            showModIssue(is, true);
                        } else {
                            launchGameNow();
                        }
                    }
                });
            }
        }, "wtm-precheck").start();
    }

    private void launchGameNow() {
        launchGameInternal(false);
    }

    /** skipBoost=true 时不再重复拉起加速器（延迟回调进来用）。 */
    private void launchGameInternal(boolean skipBoost) {
        if (!skipBoost) {
        }
        if (GameLauncher.launch(this)) {
            Kit.toast(this, "已启动游戏（语音包要重进游戏才生效）");
        } else {
            GameLauncher.explain(this);
        }
    }

    // ------------------------------------------------------------------ 环境

    private void detect() {
        if (detecting) return;
        detecting = true;
        tvPerm.setText("检测中…");
        Kit.tint(tvPerm, getColorCompat(R.color.sub));
        new Thread(new Runnable() {
            public void run() {
                int ch = Access.NONE;
                boolean writable = false;
                boolean game = false;
                boolean modExists = false;
                int bankCount = 0;
                try {
                    ch = Access.detect(getApplicationContext());
                    if (ch != Access.NONE) {
                        writable = GameDir.probeWritable(getApplicationContext());
                        game = GameDir.gameDirExists(getApplicationContext());
                        modExists = GameDir.modDirExists(getApplicationContext());
                        bankCount = GameDir.listBanks(getApplicationContext()).size();
                    }
                } catch (Throwable t) {
                    Access.detail = "检测异常：" + t;
                }
                final int fch = ch;
                int legacy = 0;
                try {
                    if (ch != Access.NONE) legacy = GameDir.legacyBanks(getApplicationContext()).size();
                } catch (Throwable ignored) {
                }
                final int fLegacy = legacy;
                final boolean fw = writable;
                final boolean fg = game;
                final boolean fm = modExists;
                final int fn = bankCount;
                ui.post(new Runnable() {
                    public void run() {
                        detecting = false;   // 无论如何都要复位，否则以后不再检测
                        applyEnv(fch, fw, fg, fm, fn);
                        if (!legacyChecked && fLegacy > 0) {
                            legacyChecked = true;
                            askCleanLegacy(fLegacy);
                        }
                        checkModDirOnce();
                    }
                });
            }
        }, "wtm-detect").start();
    }

    private void applyEnv(int ch, boolean writable, boolean game, boolean modExists, int bankCount) {
        tvAndroid.setText("Android " + Build.VERSION.RELEASE + " · API " + Build.VERSION.SDK_INT);

        boolean ready = ch != Access.NONE;
        tvPerm.setText(ready ? Access.channelName() : "未就绪");
        Kit.tint(tvPerm, getColorCompat(ready ? R.color.green : R.color.red));

        tvDirState.setText(writable ? "可读写" : (modExists ? "不可写" : "尚未创建"));
        Kit.tint(tvDirState, getColorCompat(writable ? R.color.green : R.color.gold));

        tvGame.setText(game ? "已找到游戏数据目录" : "未检测到（没装或没启动过）");
        TextView gs = (TextView) findViewById(R.id.btnGameStatus);
        if (gs != null) {
            boolean inst = GameLauncher.installed(this);
            gs.setText(inst ? "▶ 启动" : "未安装");
            gs.setTextColor(getColorCompat(inst ? R.color.green : R.color.sub));
        }
        Kit.tint(tvGame, getColorCompat(game ? R.color.green : R.color.sub));

        tvPath.setText(GameDir.modDir(this));
        TextView footer = (TextView) findViewById(R.id.tvFooter);
        if (footer != null) {
            footer.setText("语音文件写入 " + GameDir.modDir(this)
                    + "\n（注意是 mod，不是 mods；需要先改包开启 mod 优先加载）"
                    + "\n非官方第三方工具，与 Gaijin Entertainment 无关联；不提供任何语音包内容");
        }

        String applied = Prefs.appliedName(this);
        boolean hasApplied = applied != null && applied.length() > 0 && bankCount > 0;
        if (hasApplied) {
            tvSubtitle.setText("通道：" + Access.channelName() + " · mod 目录里有 " + bankCount + " 个语音文件");
        } else if (ready) {
            tvSubtitle.setText("通道：" + Access.channelName() + " · 游戏当前使用原版语音");
        } else {
            tvSubtitle.setText(Access.detail);
        }

        TextView shStatus = (TextView) findViewById(R.id.tvShizuku);
        if (shStatus != null) {
            shStatus.setText(ShizukuGuide.statusText(this));
            Kit.tint(shStatus, getColorCompat(Shizu.ping() && Shizu.hasPermission()
                    ? R.color.green : R.color.gold));
        }
        if (!ready) {
            btnPerm.setText("获取文件读写权限");
        } else if (!writable) {
            btnPerm.setText("目录不可写，点这里排查");
        } else {
            btnPerm.setText("重新检测环境");
        }
    }

    private void permissionFlow() {
        if (Access.ready()) {
            Kit.toast(this, "权限通道已就绪：" + Access.channelName());
            detect();
            return;
        }
        // 没装/没运行/没授权 三种情况分别给不同引导；已 root 的走下面兜底
        ShizukuGuide.guide(this, new Runnable() {
            public void run() {
                detect();
                pollShizuku(0);
            }
        });
    }

    private void pollShizuku(final int n) {
        ui.postDelayed(new Runnable() {
            public void run() {
                if (Shizu.hasPermission() || n > 28) {
                    detect();
                    return;
                }
                pollShizuku(n + 1);
            }
        }, 500);
    }

    // ------------------------------------------------------------------ 状态

    private void refreshLibrary() {
        new Thread(new Runnable() {
            public void run() {
                final int n = PackStore.count(getApplicationContext());
                final long size = PackStore.totalSize(getApplicationContext());
                ui.post(new Runnable() {
                    public void run() {
                        tvStorage.setText("语音包库：" + n + " 个 · " + Kit.fmtSize(size));
                        tvStorageSub.setText(n == 0
                                ? "还没有语音包，点上面「导入语音包」开始"
                                : "相同内容的语音包只存一份，换包也不会多一份");
                    }
                });
            }
        }, "wtm-lib-stat").start();
    }

    private void refreshApplied() {
        String name = Prefs.appliedName(this);
        long at = Prefs.appliedAt(this);
        int count = Prefs.appliedCount(this);
        if (name == null || name.length() == 0) {
            tvApplied.setText("未应用（游戏使用原版语音）");
            Kit.tint(tvApplied, getColorCompat(R.color.gold2));
            tvAppliedSub.setText("从语音包库选一个包即可一键替换");
        } else {
            tvApplied.setText(name);
            Kit.tint(tvApplied, getColorCompat(R.color.gold2));
            tvAppliedSub.setText("上次更换 " + Kit.fmtAgo(at) + " · " + count + " 个语音文件");
        }
    }

    // ------------------------------------------------------------------ 动作

    private void doRestore() {
        Kit.confirm(this, "恢复原版语音", "会清空 mod 目录里所有 .bank 文件，游戏就会用回原版语音。\n"
                + "语音包库里的包不会被删除，随时可以再换回来。", "清空并恢复", new Runnable() {
            public void run() {
                Installer.restoreAsync(MainActivity.this, new Installer.Listener() {
                    public void onProgress(String text) {
                    }

                    public void onDone(boolean ok, String message) {
                        if (!Kit.alive(MainActivity.this)) return;
                        Kit.msg(MainActivity.this, ok ? "完成" : "没成功", message);
                        detect();
                        refreshApplied();
                    }
                });
            }
        });
    }

    private void doClean() {
        new Thread(new Runnable() {
            public void run() {
                final long freed = PackStore.cleanup(getApplicationContext());
                ui.post(new Runnable() {
                    public void run() {
                        Kit.toast(MainActivity.this, freed > 0
                                ? "已清理 " + Kit.fmtSize(freed) + " 无用文件"
                                : "没有需要清理的东西");
                        refreshLibrary();
                    }
                });
            }
        }, "wtm-clean").start();
    }

    @SuppressWarnings("deprecation")
    private int getColorCompat(int res) {
        if (Build.VERSION.SDK_INT >= 23) return getResources().getColor(res, getTheme());
        return getResources().getColor(res);
    }
}
