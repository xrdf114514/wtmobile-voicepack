package com.wtm.voicepack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Shizuku 客户端桥（反射实现）。
 *
 * 为什么用反射：Shizuku API 在 v11/v12/v13 之间签名变化很大，而且我们从 AAR 里取的是
 * 固定的 13.1.5 classes.jar。反射能同时兼容，且打包时即使缺少 jar 也不会 NoClassDefFoundError。
 *
 * 关键点（javap 实测 13.1.5）：
 *   · public static boolean pingBinder()
 *   · public static int checkSelfPermission()
 *   · public static void requestPermission(int)
 *   · private static ShizukuRemoteProcess newProcess(String[], String[], String)
 *     —— v13 里 newProcess 变成了 private！所以必须用 getDeclaredMethod + setAccessible，
 *        用它去起 `sh -c` 子进程（拿到 shell/uid2000 身份）。
 *
 * manifest 里仍然必须注册 rikka.shizuku.ShizukuProvider，dex 里要有 ShizukuProvider 类，
 * 否则 Shizuku 无法把 binder 送进来，而且应用启动时会因为 provider 类缺失直接闪退。
 */
public final class Shizu {

    public static final String PKG = "moe.shizuku.privileged.api";
    public static final String DOWNLOAD_URL = "https://shizuku.rikka.app/download/";

    private static boolean init = false;
    private static Class<?> cls;
    private static Method mPing;
    private static Method mCheck;
    private static Method mRequestInt;
    private static Method mNewProcess3;
    private static Method mNewProcess1;
    private static String loadError = "";

    private Shizu() {
    }

    private static synchronized void load() {
        if (init) return;
        init = true;
        try {
            cls = Class.forName("rikka.shizuku.Shizuku");
        } catch (Throwable t) {
            // 常见原因：打包时漏了 shizuku-aidl / shared 的类，导致 Shizuku 静态初始化失败
            Throwable cause = t.getCause() == null ? t : t.getCause();
            loadError = "Shizuku 库加载失败：" + cause.getClass().getSimpleName()
                    + (cause.getMessage() == null ? "" : "：" + cause.getMessage());
            return;
        }
        mPing = find(cls, "pingBinder");
        mCheck = find(cls, "checkSelfPermission");
        mRequestInt = find(cls, "requestPermission", int.class);
        if (mRequestInt == null) find(cls, "requestPermission");
        // v13 的 newProcess 是 private，所以要用 findAny（public 也认）
        mNewProcess3 = findAny(cls, "newProcess", String[].class, String[].class, String.class);
        mNewProcess1 = findAny(cls, "newProcess", String[].class);
        if (mNewProcess3 == null && mNewProcess1 == null) {
            loadError = "当前 Shizuku 库没有 newProcess，无法创建 shell 进程";
        }
    }

    private static Method find(Class<?> c, String name, Class<?>... params) {
        try {
            return c.getMethod(name, params);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Method findAny(Class<?> c, String name, Class<?>... params) {
        Method m = find(c, name, params);
        if (m != null) return m;
        try {
            m = c.getDeclaredMethod(name, params);
            m.setAccessible(true);
            return m;
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean available() {
        load();
        return cls != null;
    }

    public static String loadError() {
        load();
        return loadError;
    }

    /** Shizuku 服务是否在线（应用已安装并已启动）。 */
    public static boolean ping() {
        load();
        if (mPing == null) return false;
        try {
            Object r = mPing.invoke(null);
            return r instanceof Boolean && (Boolean) r;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 是否已经拿到 Shizuku 授权。 */
    public static boolean hasPermission() {
        load();
        if (mCheck == null) return false;
        try {
            Object r = mCheck.invoke(null);
            return r instanceof Integer && (Integer) r == 0; // PERMISSION_GRANTED
        } catch (Throwable t) {
            return false;
        }
    }

    public static void requestPermission(int code) {
        load();
        try {
            if (mRequestInt != null) mRequestInt.invoke(null, code);
        } catch (Throwable ignored) {
        }
    }

    /** Shizuku 服务版本号（自检页用）。 */
    public static int version() {
        load();
        try {
            Method m = find(cls, "getVersion");
            if (m == null) m = find(cls, "getLatestServiceVersion");
            if (m == null) return -1;
            Object r = m.invoke(null);
            return r instanceof Integer ? (Integer) r : -1;
        } catch (Throwable t) {
            return -1;
        }
    }

    public static boolean canNewProcess() {
        load();
        return mNewProcess3 != null || mNewProcess1 != null;
    }

    /** 以 shell 身份（uid 2000）起一个进程。失败时抛出带真实原因的异常。 */
    public static Process newProcess(String... cmd) throws Exception {
        load();
        StringBuilder errs = new StringBuilder();
        if (mNewProcess3 != null) {
            // 1) 官方示例写法：env / dir 都传 null
            Object o = tryInvoke(mNewProcess3, new Object[]{cmd, null, null}, errs);
            if (o instanceof Process) return (Process) o;
            // 2) 个别服务端版本对 null 的 env/dir 会 NPE，换成空 env + "/" 再试
            o = tryInvoke(mNewProcess3, new Object[]{cmd, new String[0], "/"}, errs);
            if (o instanceof Process) return (Process) o;
        }
        if (mNewProcess1 != null) {
            Object o = tryInvoke(mNewProcess1, new Object[]{cmd}, errs);
            if (o instanceof Process) return (Process) o;
        }
        // 3) 高版本服务端把 newProcess 的事务号挪了位置，高级 API 会拿到空 binder
        //    （表现为 asBinder() on null）。这里直接按 binder 事务号去要进程。
        try {
            return rawNewProcess(cmd);
        } catch (Throwable t) {
            if (errs.length() > 0) errs.append(" / ");
            errs.append(describe(t));
        }
        throw new IllegalStateException(errs.length() > 0 ? errs.toString()
                : (loadError.length() > 0 ? loadError : "这个 Shizuku 版本不支持创建进程"));
    }

    // ---------------------------------------------------------------- 原始事务兜底

    private static Method mGetBinder;
    private static volatile int rawCode = 0;
    private static volatile boolean rawUseToken = false;

    public static int rawCode() {
        return rawCode;
    }

    /** Shizuku 服务端的 binder（rikka.shizuku.Shizuku.getBinder()）。 */
    public static android.os.IBinder binder() {
        load();
        try {
            if (mGetBinder == null) mGetBinder = find(cls, "getBinder");
            if (mGetBinder == null) return null;
            Object o = mGetBinder.invoke(null);
            return o instanceof android.os.IBinder ? (android.os.IBinder) o : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * 直接按事务号调用 IShizukuService.newProcess。
     *
     * Shizuku+ 的服务端用「裸 AIDL 号」写了一个手写 switch（case 7 = newProcess、case 8 =
     * getSELinuxContext），而标准 AIDL 客户端发的是 FIRST_CALL_TRANSACTION + N（也就是 8），
     * 于是 r2304 这类版本会把 newProcess 当成 getSELinuxContext 处理 —— 回一个字符串，
     * 客户端读成 null binder，就成了「asBinder() on null」。他们 2026-09 才修。
     *
     * 所以这里两种协议都试：裸号（不写 interface token，服务端直接 createStringArray）
     * 和标准号（写 token）。哪个成功记住哪个。
     */
    private static Process rawNewProcess(String[] cmd) throws Throwable {
        android.os.IBinder b = binder();
        if (b == null) throw new IllegalStateException("拿不到 Shizuku binder");
        int[] codes = rawCode > 0 ? new int[]{rawCode} : new int[]{7, 8};
        boolean[] tokens = rawCode > 0 ? new boolean[]{rawUseToken} : new boolean[]{false, true};
        StringBuilder err = new StringBuilder();
        for (int code : codes) {
            for (boolean withToken : tokens) {
                android.os.Parcel data = android.os.Parcel.obtain();
                android.os.Parcel reply = android.os.Parcel.obtain();
                String tag = "事务" + code + (withToken ? "(带token)" : "(裸)");
                try {
                    if (withToken) data.writeInterfaceToken("moe.shizuku.server.IShizukuService");
                    data.writeStringArray(cmd);
                    data.writeStringArray(null);
                    data.writeString(null);
                    if (!b.transact(code, data, reply, 0)) {
                        err.append(tag).append("未实现；");
                        continue;
                    }
                    reply.readException();
                    android.os.IBinder proc = reply.readStrongBinder();
                    if (proc == null) {
                        err.append(tag).append("返回空；");
                        continue;
                    }
                    rawCode = code;
                    rawUseToken = withToken;
                    return wrapRemote(proc);
                } catch (Throwable t) {
                    err.append(tag).append("→").append(describe(t)).append("；");
                } finally {
                    data.recycle();
                    reply.recycle();
                }
            }
        }
        throw new IllegalStateException("原生事务也不行：" + err);
    }

    private static Process wrapRemote(android.os.IBinder proc) throws Exception {
        Class<?> stubCls = Class.forName("moe.shizuku.server.IRemoteProcess$Stub");
        Object remote = stubCls.getMethod("asInterface", android.os.IBinder.class).invoke(null, proc);
        Class<?> iface = Class.forName("moe.shizuku.server.IRemoteProcess");
        Class<?> rp = Class.forName("rikka.shizuku.ShizukuRemoteProcess");
        java.lang.reflect.Constructor<?> ctor = rp.getDeclaredConstructor(iface);
        ctor.setAccessible(true);
        return (Process) ctor.newInstance(remote);
    }

    private static Object tryInvoke(Method m, Object[] args, StringBuilder errs) {
        try {
            return m.invoke(null, args);
        } catch (InvocationTargetException e) {
            if (errs.length() > 0) errs.append(" / ");
            errs.append(describe(e.getCause() != null ? e.getCause() : e));
            return null;
        } catch (Throwable t) {
            if (errs.length() > 0) errs.append(" / ");
            errs.append(describe(t));
            return null;
        }
    }

    /** 把反射包装异常拆成人能看的一句：类名: 消息 ← cause: 消息（最多三层）。 */
    public static String describe(Throwable t) {
        if (t == null) return "未知错误";
        StringBuilder sb = new StringBuilder();
        Throwable cur = t;
        int depth = 0;
        while (cur != null && depth < 3) {
            if (depth > 0) sb.append(" ← ");
            sb.append(cur.getClass().getName());
            String msg = cur.getMessage();
            if (msg != null && msg.length() > 0) sb.append(": ").append(msg);
            Throwable next = cur.getCause();
            cur = (next == cur) ? null : next;
            depth++;
        }
        return sb.toString();
    }
}
