package com.wtm.voicepack;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.MessageDigest;

/** 极简 HTTP 客户端：只用 java.net，不引第三方库（应用里没有 okhttp）。 */
public final class Net {

    private static final String UA = "Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

    public interface Progress {
        /** 返回 true 表示取消下载。 */
        boolean onProgress(long done, long total);
    }

    private Net() {
    }

    public static String postForm(String url, String form, String referer) throws IOException {
        return request(url, "POST", form, referer);
    }

    public static String get(String url, String referer) throws IOException {
        return request(url, "GET", null, referer);
    }

    private static String request(String url, String method, String body, String referer) throws IOException {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestMethod(method);
            conn.setRequestProperty("User-Agent", UA);
            conn.setRequestProperty("Accept", "*/*");
            if (referer != null) conn.setRequestProperty("Referer", referer);
            if (body != null) {
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                conn.setRequestProperty("X-Requested-With", "XMLHttpRequest");
                OutputStream os = conn.getOutputStream();
                os.write(body.getBytes("UTF-8"));
                os.flush();
                os.close();
            }
            int code = conn.getResponseCode();
            InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String text = readAll(in);
            if (code >= 400) {
                String t = text == null ? "" : text.trim();
                boolean html = t.toLowerCase(java.util.Locale.US).startsWith("<!doctype")
                        || t.toLowerCase(java.util.Locale.US).startsWith("<html");
                throw new IOException("HTTP " + code + (!html && t.length() > 0 ? "：" + cut(t, 100) : ""));
            }
            return text;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        try {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), Charset.forName("UTF-8"));
        } finally {
            try {
                in.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static String cut(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n) + "…";
    }

    /**
     * 下载到文件。会边下边算 SHA-256、校验总大小；取消或失败都会删掉半截文件。
     * expectSize<=0 表示未知大小；expectSha256 为空表示不校验。
     */
    public static void download(String url, File dst, String referer, long expectSize,
                                String expectSha256, Progress progress) throws IOException {
        HttpURLConnection conn = null;
        FileOutputStream out = null;
        boolean ok = false;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(60000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", UA);
            if (referer != null) conn.setRequestProperty("Referer", referer);
            int code = conn.getResponseCode();
            if (code >= 400) throw new IOException("HTTP " + code);
            long total = conn.getContentLengthLong();
            if (total <= 0) total = expectSize;

            MessageDigest md = null;
            if (expectSha256 != null && expectSha256.length() > 0) {
                try {
                    md = MessageDigest.getInstance("SHA-256");
                } catch (Throwable ignored) {
                }
            }

            InputStream in = conn.getInputStream();
            out = new FileOutputStream(dst);
            byte[] buf = new byte[128 * 1024];
            long done = 0;
            long lastReport = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (md != null) md.update(buf, 0, n);
                done += n;
                if (progress != null && (done - lastReport > 512 * 1024 || done == total)) {
                    lastReport = done;
                    if (progress.onProgress(done, total)) {
                        throw new IOException("已取消");
                    }
                }
            }
            out.getFD().sync();
            out.close();
            out = null;
            in.close();

            if (expectSize > 0 && done != expectSize) {
                throw new IOException("下载不完整（应有 " + expectSize + " 字节，实际 " + done + "）");
            }
            if (md != null) {
                String got = hex(md.digest());
                if (!got.equalsIgnoreCase(expectSha256)) {
                    throw new IOException("文件校验失败（sha256 不匹配）");
                }
            }
            ok = true;
        } finally {
            try {
                if (out != null) out.close();
            } catch (Throwable ignored) {
            }
            if (conn != null) conn.disconnect();
            if (!ok && dst != null && dst.exists()) //noinspection ResultOfMethodCallIgnored
                dst.delete();
        }
    }

    /** 探测一个链接：是不是文件、多大、什么类型。用于判断「普通链接」要不要当直链下载。 */
    public static final class Probe {
        public boolean ok;
        public long size = -1;
        public String type = "";
        public String error = "";
    }

    public static Probe probe(String url, String referer) {
        Probe p = new Probe();
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(20000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", UA);
            conn.setRequestProperty("Range", "bytes=0-1");
            if (referer != null) conn.setRequestProperty("Referer", referer);
            int code = conn.getResponseCode();
            p.type = String.valueOf(conn.getContentType());
            String cr = conn.getHeaderField("Content-Range");
            if (cr != null && cr.contains("/")) {
                try {
                    p.size = Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim());
                } catch (Throwable ignored) {
                }
            }
            if (p.size < 0) p.size = conn.getContentLengthLong();
            p.ok = code >= 200 && code < 400;
            if (!p.ok) p.error = "HTTP " + code;
        } catch (Throwable t) {
            p.error = t.toString();
        } finally {
            if (conn != null) conn.disconnect();
        }
        return p;
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) {
            int v = x & 0xff;
            if (v < 16) sb.append('0');
            sb.append(Integer.toHexString(v));
        }
        return sb.toString();
    }

    /** 表单编码。 */
    public static String form(String... kv) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            if (sb.length() > 0) sb.append('&');
            sb.append(enc(kv[i])).append('=').append(enc(kv[i + 1]));
        }
        return sb.toString();
    }

    public static String enc(String s) {
        try {
            return java.net.URLEncoder.encode(s == null ? "" : s, "UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }
}
