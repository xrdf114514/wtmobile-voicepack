package com.wtm.voicepack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * WT Live（Gaijin 官方二创站）数据源。
 *
 * 公开接口：POST https://live.warthunder.com/api/feed/get_regular/
 *   content=sound  只取声音类
 *   sort=downloads | date
 *   page=0,1,2...
 *   searchString=#标签（必须是 # 开头的标签；直接搜中文关键词返回 0 条）
 *   subtype=audio, featured=false
 *
 * 返回 data.list[]，其中 file.link 是免登录直链（https://live.warthunder.com/dl/<hex>/），
 * 实测支持 Range、返回 zip。
 *
 * 注意：这里的内容是 **PC 版**音效/语音 mod，手游能不能用取决于 bank 文件名是否匹配，
 * 属于「可以试，但不保证」，UI 上必须提示。
 */
public final class WtLive {

    public static final String NAME = "WT Live";
    public static final String API = "https://live.warthunder.com/api/feed/get_regular/";
    public static final String REFERER = "https://live.warthunder.com/feed/sounds/";
    public static final String PAGE_URL = "https://live.warthunder.com/post/";

    private WtLive() {
    }

    /** sort 用 "downloads" 或 "date"；search 可为空，传了会自动补 #。 */
    public static List<OnlinePack> fetch(int page, String sort, String search) throws Exception {
        String body = Net.form(
                "content", "sound",
                "sort", sort == null || sort.length() == 0 ? "downloads" : sort,
                "page", String.valueOf(page),
                "subtype", "audio",
                "featured", "false",
                "searchString", normalizeSearch(search)
        );
        String text = Net.postForm(API, body, REFERER);
        return parse(text);
    }

    /** 搜索必须是 #标签 形式，否则站点会当成普通词而返回 0 条。 */
    public static String normalizeSearch(String s) {
        if (s == null) return "";
        String t = s.trim();
        if (t.length() == 0) return "";
        if (t.startsWith("#")) return t;
        return "#" + t.replace(" ", "");
    }

    public static List<OnlinePack> parse(String json) throws Exception {
        List<OnlinePack> out = new ArrayList<OnlinePack>();
        JSONObject root = new JSONObject(json);
        String status = root.optString("status", "");
        if (!"OK".equals(status)) {
            throw new Exception("接口返回异常：" + root.optString("msg", status));
        }
        JSONObject data = root.optJSONObject("data");
        if (data == null) return out;
        JSONArray list = data.optJSONArray("list");
        if (list == null) return out;

        for (int i = 0; i < list.length(); i++) {
            JSONObject p = list.optJSONObject(i);
            if (p == null) continue;
            JSONObject file = p.optJSONObject("file");
            if (file == null) continue;
            String link = file.optString("link", "");
            if (link == null || !link.startsWith("http")) continue;

            OnlinePack op = new OnlinePack();
            op.source = NAME;
            op.sourceType = "wtlive";
            op.id = "w" + p.optLong("id", 0);
            op.url = link;
            op.size = file.optLong("size", 0);
            op.sha256 = "";
            op.downloads = p.optLong("downloads", 0);
            op.updatedAt = p.optLong("created", 0) * 1000L;
            op.pageUrl = PAGE_URL + p.optLong("id", 0) + "/en/";

            String fname = file.optString("name", "");
            String title = prettyTitle(fname);
            String descText = stripHtml(p.optString("description", ""));
            String bold = firstBold(p.optString("description", ""));
            if (bold.length() > 0) title = bold;
            if (title.length() == 0) title = "未命名音效包";
            if (title.length() > 60) title = title.substring(0, 60) + "…";
            op.title = title;
            op.desc = descText;

            JSONObject author = p.optJSONObject("author");
            String nickname = author == null ? "" : author.optString("nickname", "");
            StringBuilder note = new StringBuilder();
            if (nickname.length() > 0) note.append("@").append(nickname);
            if (op.downloads > 0) {
                if (note.length() > 0) note.append(" · ");
                note.append("下载 ").append(human(op.downloads));
            }
            op.note = note.toString();

            JSONArray images = p.optJSONArray("images");
            if (images != null && images.length() > 0) {
                JSONObject img = images.optJSONObject(0);
                if (img != null) op.thumb = img.optString("src", "");
            }
            out.add(op);
        }
        return out;
    }

    private static String normalize(String s) {
        return s.toLowerCase(Locale.US).replace("\uFF0E", ".").trim();
    }

    static String prettyTitle(String fileName) {
        if (fileName == null) return "";
        String n = fileName.trim();
        String lower = normalize(n);
        String[] exts = {".zip", ".rar", ".7z", ".bank", ".fsb"};
        for (String e : exts) {
            if (lower.endsWith(e)) {
                n = n.substring(0, n.length() - e.length());
                break;
            }
        }
        n = n.replace('_', ' ').replace('-', ' ').trim();
        if (n.length() > 60) n = n.substring(0, 60) + "…";
        return n;
    }

    static String stripHtml(String html) {
        if (html == null) return "";
        String s = html.replaceAll("(?i)<br\\s*/?>", " ")
                .replaceAll("(?i)</p>", " ")
                .replaceAll("<[^>]+>", "")
                .replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"");
        s = s.replaceAll("\\s+", " ").trim();
        if (s.length() > 300) s = s.substring(0, 300) + "…";
        return s;
    }

    private static String firstBold(String html) {
        if (html == null) return "";
        try {
            int i = html.toLowerCase(Locale.US).indexOf("<b>");
            int j = i < 0 ? -1 : html.toLowerCase(Locale.US).indexOf("</b>", i);
            if (i < 0 || j < 0 || j - i > 120) return "";
            String s = stripHtml(html.substring(i + 3, j));
            if (s.length() > 60) s = s.substring(0, 60) + "…";
            return s;
        } catch (Throwable t) {
            return "";
        }
    }

    static String human(long n) {
        if (n >= 1000000) return String.format(Locale.US, "%.1fM", n / 1000000.0);
        if (n >= 1000) return String.format(Locale.US, "%.1fk", n / 1000.0);
        return String.valueOf(n);
    }
}
