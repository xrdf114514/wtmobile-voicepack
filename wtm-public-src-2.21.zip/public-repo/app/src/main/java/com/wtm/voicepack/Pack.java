package com.wtm.voicepack;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** 一个语音包（= 一组 .bank 文件 + 元数据）。id 由内容哈希决定，天然去重。 */
public final class Pack {

    public String id = "";
    public String hash = "";
    public String name = "";
    public String note = "";
    public String source = "";
    public long size = 0;
    public int count = 0;
    public long addedAt = 0;
    public long lastAppliedAt = 0;
    public boolean favorite = false;
    public List<String> tags = new ArrayList<String>();
    public List<String> banks = new ArrayList<String>();

    public File dir(Context c) {
        return new File(PackStore.libraryDir(c), id);
    }

    public File banksDir(Context c) {
        return new File(dir(c), "banks");
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("hash", hash);
            o.put("name", name);
            o.put("note", note);
            o.put("source", source);
            o.put("size", size);
            o.put("count", count);
            o.put("addedAt", addedAt);
            o.put("lastAppliedAt", lastAppliedAt);
            o.put("favorite", favorite);
            JSONArray tg = new JSONArray();
            for (String t : tags) tg.put(t);
            o.put("tags", tg);
            JSONArray a = new JSONArray();
            for (String s : banks) a.put(s);
            o.put("banks", a);
        } catch (Throwable ignored) {
        }
        return o;
    }

    public static Pack fromJson(JSONObject o) {
        Pack p = new Pack();
        p.id = o.optString("id");
        p.hash = o.optString("hash", p.id);
        p.name = o.optString("name");
        p.note = o.optString("note", "");
        p.source = o.optString("source", "");
        p.size = o.optLong("size", 0);
        p.count = o.optInt("count", 0);
        p.addedAt = o.optLong("addedAt", 0);
        p.lastAppliedAt = o.optLong("lastAppliedAt", 0);
        p.favorite = o.optBoolean("favorite", false);
        JSONArray tg = o.optJSONArray("tags");
        if (tg != null) for (int i = 0; i < tg.length(); i++) {
            String t = tg.optString(i);
            if (t != null && t.length() > 0) p.tags.add(t);
        }
        JSONArray a = o.optJSONArray("banks");
        if (a != null) {
            for (int i = 0; i < a.length(); i++) p.banks.add(a.optString(i));
        }
        if (p.count == 0) p.count = p.banks.size();
        return p;
    }

    public String tagsLine() {
        StringBuilder sb = new StringBuilder();
        for (String t : tags) {
            if (sb.length() > 0) sb.append(' ');
            sb.append('#').append(t);
        }
        return sb.toString();
    }

    public String displayMeta() {
        StringBuilder sb = new StringBuilder();
        sb.append(count).append(" 个 bank");
        if (note != null && note.length() > 0) sb.append(" · ").append(note);
        if (!tags.isEmpty()) sb.append(" · ").append(tagsLine());
        return sb.toString();
    }
}
