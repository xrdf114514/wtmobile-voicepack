package com.wtm.voicepack;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 导入器：把用户选的 .zip（或一堆 .bank）读出来，抽出 .bank 放到临时目录，
 * 再算一个「内容哈希」——这个哈希就是语音包的身份，用来做去重。
 */
public final class BankImporter {

    public interface Progress {
        void onStep(String text);
    }

    public static final class Result {
        public File banksDir;
        public String hash = "";
        public List<String> names = new ArrayList<String>();
        public long size = 0;
        public String sourceName = "";

        public int count() {
            return names.size();
        }
    }

    private BankImporter() {
    }

    public static Result importAll(Context c, List<Uri> uris, File workDir, Progress prog) throws Exception {
        Kit.clearDir(workDir);
        if (!workDir.isDirectory() && !workDir.mkdirs()) throw new IOException("临时目录不可写");
        File banks = new File(workDir, "banks");
        if (!banks.mkdirs() && !banks.isDirectory()) throw new IOException("临时目录不可写");

        Set<String> seenExts = new TreeSet<String>();
        String source = "";
        int idx = 0;

        for (Uri u : uris) {
            String dn = displayName(c, u);
            if (dn == null || dn.length() == 0) dn = "file_" + (idx + 1);
            if (source.length() == 0) source = dn;
            File tmp = new File(workDir, "wtm_src_" + (idx++) + ".tmp");
            copyUri(c, u, tmp);
            step(prog, "读取 " + dn + "（" + Kit.fmtSize(tmp.length()) + "）");

            boolean zipOk = isZip(tmp);
            if (zipOk) {
                try {
                    int n = extractZipBanks(tmp, banks, seenExts, prog);
                    step(prog, dn + " → 提取到 " + n + " 个 .bank 文件");
                } catch (Throwable t) {
                    zipOk = false;
                    step(prog, dn + " 解压失败，按普通文件处理");
                }
            }
            if (!zipOk && dn.toLowerCase(Locale.US).endsWith(".bank")) {
                File dst = uniqueFile(banks, Kit.safeName(dn));
                if (!Kit.moveFile(tmp, dst)) {
                    throw new IOException("读到的临时文件写不进去（空间不足？）：" + dn);
                }
                seenExts.add("bank");
                step(prog, "直接收录 " + dn);
            } else {
                seenExts.add(extOf(dn.length() > 0 ? dn : "?"));
                step(prog, dn + " 不是压缩包，也不是 .bank，已跳过");
            }
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        }

        return buildResult(banks, source, seenExts, prog);
    }

    /** 从已经下到本地磁盘的 zip 导入（在线语音包下载完之后走这条）。 */
    public static Result importFromZipFile(Context c, File zip, String displayName,
                                           File workDir, Progress prog) throws Exception {
        Kit.clearDir(workDir);
        if (!workDir.isDirectory() && !workDir.mkdirs()) throw new IOException("临时目录不可写");
        File banks = new File(workDir, "banks");
        if (!banks.mkdirs() && !banks.isDirectory()) throw new IOException("临时目录不可写");

        Set<String> seenExts = new TreeSet<String>();
        String dn = displayName == null || displayName.length() == 0 ? zip.getName() : displayName;
        if (isZip(zip)) {
            int n = extractZipBanks(zip, banks, seenExts, prog);
            step(prog, dn + " → 提取到 " + n + " 个 .bank 文件");
            if (n == 0) {
                // 有些下载来的包其实是单文件 bank
                if (dn.toLowerCase(Locale.US).endsWith(".bank")) {
                    File dst = uniqueFile(banks, Kit.safeName(dn));
                    if (!Kit.copyFile(zip, dst)) throw new IOException("写入临时文件失败");
                }
            }
        } else if (dn.toLowerCase(Locale.US).endsWith(".bank")) {
            File dst = uniqueFile(banks, Kit.safeName(dn));
            if (!Kit.copyFile(zip, dst)) throw new IOException("写入临时文件失败");
        } else {
            throw new IOException("下载下来的不是 zip：" + dn);
        }
        return buildResult(banks, dn, seenExts, prog);
    }

    /** 给「包内编辑」用：对一个现成的 banks 目录重新算名字/大小/内容指纹。 */
    public static Result inspectDir(File banks, String source) throws IOException {
        return buildResult(banks, source, new TreeSet<String>(), null);
    }

    private static Result buildResult(File banks, String source, Set<String> seenExts, Progress prog)
            throws IOException {
        File[] fs = banks.listFiles();
        if (fs == null || fs.length == 0) throw new IOException(noBankMessage(seenExts));

        Result r = new Result();
        r.banksDir = banks;
        r.sourceName = source;
        for (File f : fs) {
            if (!f.isFile()) continue;
            r.names.add(f.getName());
            r.size += f.length();
        }
        Collections.sort(r.names);
        if (r.names.isEmpty()) throw new IOException(noBankMessage(seenExts));
        r.hash = hashBanks(banks, r.names);
        step(prog, "识别到 " + r.names.size() + " 个语音文件，共 " + Kit.fmtSize(r.size)
                + "，指纹 " + (r.hash.length() > 12 ? r.hash.substring(0, 12) : r.hash));
        return r;
    }

    private static void step(Progress p, String s) {
        if (p != null) p.onStep(s);
    }

    // ------------------------------------------------------------------ zip

    private static int extractZipBanks(File zip, File out, Set<String> seenExts, Progress prog)
            throws IOException {
        Charset cs = guessCharset(zip);
        int n = 0;
        ZipFile zf = null;
        try {
            zf = new ZipFile(zip, cs);
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String raw = e.getName();
                if (raw == null) continue;
                String base = raw.substring(raw.lastIndexOf('/') + 1);
                String lower = base.toLowerCase(Locale.US);
                if (!lower.endsWith(".bank")) {
                    seenExts.add(extOf(base));
                    continue;
                }
                File dst = uniqueFile(out, Kit.safeName(base));
                InputStream in = null;
                boolean good = false;
                try {
                    in = zf.getInputStream(e);
                    writeTo(in, dst);
                    long expect = e.getSize();
                    good = expect < 0 || dst.length() == expect;
                } catch (Throwable t) {
                    good = false;
                } finally {
                    try {
                        if (in != null) in.close();
                    } catch (Throwable ignored) {
                    }
                    if (!good) {
                        // 半截文件绝对不能进库、更不能进游戏
                        dst.delete();
                    }
                }
                if (good) n++;
            }
        } finally {
            try {
                if (zf != null) zf.close();
            } catch (Throwable ignored) {
            }
        }
        if (n == 0) {
            // 可能是编码猜错了，或者压缩包里是别的东西
            seenExts.add("zip");
        }
        return n;
    }

    /** 中文 zip 常见 GBK 文件名，先按 UTF-8 读，发现乱码再换 GBK。 */
    private static Charset guessCharset(File zip) {
        Charset utf8 = Charset.forName("UTF-8");
        Charset gbk;
        try {
            gbk = Charset.forName("GBK");
        } catch (Throwable t) {
            gbk = utf8;
        }
        ZipFile zf = null;
        try {
            zf = new ZipFile(zip, utf8);
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName();
                if (n == null) continue;
                if (n.indexOf('\uFFFD') >= 0 || !isWellFormed(n)) return gbk;
                // GBK 字节被当 UTF-8 解时有时会解出控制字符而不是替换符
                for (int i = 0; i < n.length(); i++) {
                    char ch = n.charAt(i);
                    if (ch < 0x20 && ch != '\t') return gbk;
                }
            }
            return utf8;
        } catch (Throwable t) {
            return gbk;
        } finally {
            try {
                if (zf != null) zf.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static boolean isWellFormed(String s) {
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '\uFFFD') return false;
        }
        return true;
    }

    private static boolean isZip(File f) {
        if (f == null || f.length() < 4) return false;
        InputStream in = null;
        try {
            in = new FileInputStream(f);
            byte[] b = new byte[4];
            int n = in.read(b);
            return n == 4 && b[0] == 'P' && b[1] == 'K';
        } catch (Throwable t) {
            return false;
        } finally {
            try {
                if (in != null) in.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static String noBankMessage(Set<String> seenExts) {
        StringBuilder sb = new StringBuilder();
        sb.append("没找到 .bank 语音文件。\n\n");
        sb.append("自制语音包一般是 zip，里面装着 .bank；请确认选的是语音包本体，");
        sb.append("而不是作者附带的说明图片或网盘链接文件。");
        if (!seenExts.isEmpty()) {
            sb.append("\n\n压缩包里看到的文件类型：");
            int i = 0;
            for (String s : seenExts) {
                if (i++ > 8) break;
                sb.append('.').append(s).append("  ");
            }
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ 哈希

    /** 哈希 = 排序后的「文件名 + 文件内容哈希」，也就是内容身份。 */
    private static String hashBanks(File banks, List<String> names) throws IOException {
        List<String> lines = new ArrayList<String>();
        for (String name : names) {
            File f = new File(banks, name);
            lines.add(name.toLowerCase(Locale.US) + "\u0000" + sha256(f));
        }
        Collections.sort(lines);
        StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append('\n');
        return sha256(sb.toString().getBytes("UTF-8"));
    }

    private static String sha256(File f) throws IOException {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (Throwable t) {
            throw new IOException("设备缺少 SHA-256 支持");
        }
        InputStream in = new FileInputStream(f);
        try {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        } finally {
            in.close();
        }
        return hex(md.digest());
    }

    private static String sha256(byte[] data) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return hex(md.digest(data));
        } catch (Throwable t) {
            throw new IOException("设备缺少 SHA-256 支持");
        }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) {
            int v = x & 0xff;
            if (v < 16) sb.append('0');
            sb.append(Integer.toHexString(v));
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ io

    public static String displayName(Context c, Uri uri) {
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(uri,
                    new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cur != null && cur.moveToFirst()) {
                int i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) {
                    String s = cur.getString(i);
                    if (s != null && s.length() > 0) return s;
                }
            }
        } catch (Throwable ignored) {
        } finally {
            try {
                if (cur != null) cur.close();
            } catch (Throwable ignored) {
            }
        }
        String last = uri.getLastPathSegment();
        return last == null ? "" : last;
    }

    private static void copyUri(Context c, Uri uri, File dst) throws IOException {
        InputStream in = null;
        FileOutputStream out = null;
        try {
            in = c.getContentResolver().openInputStream(uri);
            if (in == null) throw new IOException("无法读取这个文件");
            out = new FileOutputStream(dst);
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.getFD().sync();
        } finally {
            try {
                if (out != null) out.close();
            } catch (Throwable ignored) {
            }
            try {
                if (in != null) in.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static void writeTo(InputStream in, File dst) throws IOException {
        FileOutputStream out = new FileOutputStream(dst);
        try {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.getFD().sync();
        } finally {
            try {
                out.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static File uniqueFile(File dir, String name) {
        if (name == null || name.length() == 0) name = "voice.bank";
        File f = new File(dir, name);
        if (!f.exists()) return f;
        String base = name;
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            base = name.substring(0, dot);
            ext = name.substring(dot);
        }
        int i = 2;
        while (true) {
            f = new File(dir, base + "_" + i + ext);
            if (!f.exists()) return f;
            i++;
        }
    }

    private static String extOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length() - 1) return "?";
        String e = name.substring(dot + 1).toLowerCase(Locale.US);
        return e.length() > 6 ? "?" : e;
    }
}
