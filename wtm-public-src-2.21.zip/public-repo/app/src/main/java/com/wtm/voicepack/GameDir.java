package com.wtm.voicepack;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 游戏目录操作：
 *   /storage/emulated/0/Android/data/<包名>/files/sound/mod   ← 游戏读自制语音的地方（是 mod 不是 mods）
 *   /storage/emulated/0/Android/data/<包名>/files/sound/      ← 游戏原版语音
 *
 * 注意 v1.7 及更早版本少了中间的 files，写到了 .../sound/mod，游戏根本不会读，
 * 所以这里用 legacy* 系列方法把旧位置的残留找出来提醒清理。
 *
 * 换包采用「先全部上传到 staging，校验通过后再替换」的方式：
 *   .../sound/.wtm_upload  →  校验大小  →  清掉旧 .bank，把 staging 里的 mv 进 mod
 * 这样磁盘满 / 权限被回收时旧语音不会被清空。
 */
public final class GameDir {

    private GameDir() {
    }

    /** 用系统给的存储根，兼容工作资料 / 多用户（不要硬编码 /storage/emulated/0）。 */
    public static String dataRoot() {
        try {
            File base = Environment.getExternalStorageDirectory();
            if (base != null) {
                String p = base.getAbsolutePath();
                if (p != null && p.length() > 0) return p + "/Android/data";
            }
        } catch (Throwable ignored) {
        }
        return "/storage/emulated/0/Android/data";
    }

    public static String pkg(Context c) {
        return Prefs.pkg(c);
    }

    public static String soundDir(Context c) {
        return dataRoot() + "/" + pkg(c) + "/files/sound";
    }

    /** v1.7 及更早写错的位置（少了 files），只能用来找残留。 */
    public static String legacySoundDir(Context c) {
        return dataRoot() + "/" + pkg(c) + "/sound";
    }

    public static String legacyModDir(Context c) {
        return legacySoundDir(c) + "/mod";
    }

    public static String modDir(Context c) {
        return soundDir(c) + "/mod";
    }

    public static String stagingDir(Context c) {
        return soundDir(c) + "/.wtm_upload";
    }

    public static boolean isDirect() {
        return Access.channel == Access.DIRECT;
    }

    /** shell 单引号转义，防止路径里的空格/引号把命令搞坏。 */
    public static String q(String s) {
        if (s == null) return "''";
        // 控制字符直接去掉：它们会截断拼出来的 shell 脚本
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 0x20) sb.append(ch);
        }
        String v = sb.toString();
        return "'" + v.replace("'", "'\\''") + "'";
    }

    // ------------------------------------------------------------------ 目录

    public static boolean ensureModDir(Context c) {
        if (isDirect()) {
            File f = new File(modDir(c));
            return f.isDirectory() || f.mkdirs();
        }
        String cmd = "mkdir -p " + q(modDir(c)) + " 2>/dev/null && test -d " + q(modDir(c)) + " && echo OK_MKDIR";
        Access.Result r = Access.sh(cmd);
        return r.ok() && r.out.contains("OK_MKDIR");
    }

    public static boolean probeWritable(Context c) {
        if (isDirect()) {
            File f = new File(modDir(c));
            return (f.isDirectory() || f.mkdirs()) && f.canWrite();
        }
        String cmd = "mkdir -p " + q(modDir(c)) + " 2>/dev/null && test -w " + q(modDir(c)) + " && echo OK_W";
        Access.Result r = Access.sh(cmd);
        return r.ok() && r.out.contains("OK_W");
    }

    // ------------------------------------------------------------------ 文件

    /** 目标目录里的 .bank 文件名列表。 */
    public static List<String> listBanks(Context c) {
        return filterBanks(listAll(c));
    }

    public static List<String> filterBanks(List<String> all) {
        List<String> out = new ArrayList<String>();
        for (String s : all) {
            if (s != null && s.toLowerCase().endsWith(".bank")) out.add(s);
        }
        return out;
    }

    /** 目标目录里的全部文件名。 */
    public static List<String> listAll(Context c) {
        List<String> out = new ArrayList<String>();
        if (isDirect()) {
            File[] fs = new File(modDir(c)).listFiles();
            if (fs != null) for (File f : fs) if (f.isFile()) out.add(f.getName());
            return out;
        }
        Access.Result r = Access.sh("ls -1 " + q(modDir(c)) + " 2>/dev/null");
        if (!r.ok()) return out;
        for (String line : r.out.split("\n")) {
            String s = line.trim();
            if (s.length() > 0) out.add(s);
        }
        return out;
    }

    public static long modSize(Context c) {
        if (isDirect()) return Kit.dirSize(new File(modDir(c)));
        Access.Result r = Access.sh("du -sk " + q(modDir(c)) + " 2>/dev/null | awk '{print $1}'");
        if (!r.ok()) return -1;
        try {
            return Long.parseLong(r.out.trim()) * 1024L;
        } catch (Throwable t) {
            return -1;
        }
    }

    /** 删除 mod 目录下所有 .bank；返回删除数量，-1 表示还有残留。 */
    public static int clearBanks(Context c) {
        if (isDirect()) {
            int n = 0;
            File[] fs = new File(modDir(c)).listFiles();
            if (fs != null) {
                for (File f : fs) {
                    if (f.isFile() && f.getName().toLowerCase().endsWith(".bank")) {
                        if (f.delete()) n++;
                    }
                }
            }
            return listBanks(c).isEmpty() ? n : -1;
        }
        String script = "MOD=" + q(modDir(c)) + "; n=0; "
                + "for f in \"$MOD\"/*; do [ -e \"$f\" ] || continue; "
                + "case \"$f\" in *.[bB][aA][nN][kK]) rm -f \"$f\" && n=$((n+1));; esac; done; "
                + "echo \"CLEARED:$n\"";
        Access.Result r = Access.sh(script);
        int n = parseTag(r.out, "CLEARED:");
        // 校验是不是真的清干净了
        if (!listBanks(c).isEmpty()) return -1;
        return n;
    }

    /** 删掉 mod 里不在 keep 列表中的 .bank（换包清理旧文件用）。 */
    public static int deleteBanksNotIn(Context c, List<String> keep) {
        List<String> existing = listBanks(c);
        int n = 0;
        for (String name : existing) {
            if (keep != null && keep.contains(name)) continue;
            if (isDirect()) {
                if (new File(modDir(c), name).delete()) n++;
            } else {
                Access.sh("rm -f " + q(modDir(c) + "/" + name));
                n++;
            }
        }
        return n;
    }

    // ------------------------------------------------------------------ staging

    public static boolean prepareStaging(Context c) {
        if (isDirect()) {
            File s = new File(stagingDir(c));
            Kit.deleteRec(s);
            return s.mkdirs();
        }
        String cmd = "S=" + q(stagingDir(c)) + "; rm -rf \"$S\"; mkdir -p \"$S\" 2>/dev/null && test -d \"$S\" && echo OK_S";
        Access.Result r = Access.sh(cmd);
        return r.ok() && r.out.contains("OK_S");
    }

    public static void cleanStaging(Context c) {
        if (isDirect()) {
            Kit.deleteRec(new File(stagingDir(c)));
            return;
        }
        Access.sh("rm -rf " + q(stagingDir(c)) + " 2>/dev/null");
    }

    /**
     * 把本地文件上传到 staging，逐个校验大小。
     * 先 cp（快），大小不对的再走 stdin 流式写入（应付 shell 读不到应用目录的机型）。
     * 返回 staging 里大小正确的文件数。
     */
    public static int pushToStaging(Context c, List<File> sources) {
        if (sources == null || sources.isEmpty()) return 0;
        if (isDirect()) {
            int n = 0;
            File s = new File(stagingDir(c));
            if (!s.isDirectory()) s.mkdirs();
            for (File src : sources) {
                if (!src.isFile()) continue;
                File dst = new File(s, src.getName());
                if (Kit.copyFile(src, dst) && dst.length() == src.length()) n++;
            }
            return n;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("S=").append(q(stagingDir(c))).append("; ok=0; ");
        for (File f : sources) {
            sb.append("if cp -f ").append(q(f.getAbsolutePath())).append(" \"$S/\" 2>/dev/null; then ok=$((ok+1)); fi; ");
        }
        sb.append("echo \"CP:$ok\"");
        Access.sh(sb.toString());

        // 校验：一次性问所有文件在 staging 里的大小
        StringBuilder chk = new StringBuilder("S=").append(q(stagingDir(c))).append("; ");
        for (File f : sources) {
            chk.append("if [ -f \"$S/").append(escapeDq(f.getName())).append("\" ]; then echo \"N:")
                    .append(f.getName().replace(":", "_")).append(":$(wc -c < \"$S/")
                    .append(escapeDq(f.getName())).append("\")\"; else echo \"N:")
                    .append(f.getName().replace(":", "_")).append(":-1\"; fi; ");
        }
        chk.append("echo DONE_ALL");
        Access.Result r = Access.sh(chk.toString());
        List<String> sizes = new ArrayList<String>();
        if (r.out != null) {
            for (String line : r.out.split("\n")) {
                String s = line.trim();
                if (s.startsWith("N:")) sizes.add(s.substring(2));
            }
        }

        int good = 0;
        for (File f : sources) {
            String key = f.getName().replace(":", "_");
            long remote = -1;
            for (String rec : sizes) {
                int cut = rec.lastIndexOf(':');
                if (cut <= 0) continue;
                if (!rec.substring(0, cut).equals(key)) continue;
                try {
                    remote = Long.parseLong(rec.substring(cut + 1).trim());
                } catch (Throwable ignored) {
                }
                break;
            }
            if (remote == f.length()) {
                good++;
                continue;
            }
            // 大小不对 / 不存在 → stdin 流式重写
            Access.Result w = Access.shWithStdin(
                    "mkdir -p \"$S\" 2>/dev/null; cat > " + q(stagingDir(c) + "/" + f.getName())
                            + " && echo OK_CAT", f);
            if (w.out.contains("OK_CAT")) good++;
        }
        return good;
    }

    /**
     * 提交：先删掉 mod 里不在 finalNames 的 .bank，再把 staging 的文件 mv 进去。
     * 返回 true 表示成功（并且已校验）。
     */
    public static boolean commitStaging(Context c, List<String> finalNames) {
        if (isDirect()) {
            File s = new File(stagingDir(c));
            File m = new File(modDir(c));
            if (!m.isDirectory() && !m.mkdirs()) return false;
            deleteBanksNotIn(c, finalNames);
            File[] fs = s.listFiles();
            if (fs == null) return false;
            for (File f : fs) {
                if (!Kit.moveFile(f, new File(m, f.getName()))) return false;
            }
            Kit.deleteRec(s);
            return true;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("S=").append(q(stagingDir(c))).append("; M=").append(q(modDir(c))).append("; ");
        sb.append("mkdir -p \"$M\" 2>/dev/null; ");
        // 1) 删掉不属于新包的旧 .bank
        sb.append("for f in \"$M\"/*; do [ -e \"$f\" ] || continue; ");
        sb.append("case \"$f\" in *.[bB][aA][nN][kK]) keep=0; ");
        for (String name : finalNames) {
            if (name == null || name.length() == 0) continue;
            sb.append("case \"$f\" in */").append(globEscape(name)).append(") keep=1;; esac; ");
        }
        sb.append("[ $keep -eq 0 ] && rm -f \"$f\";; esac; done; ");
        // 2) staging → mod
        sb.append("mv -f \"$S\"/* \"$M/\" 2>/dev/null; rm -rf \"$S\"; ");
        // 3) 校验
        sb.append("bad=0; ");
        for (String name : finalNames) {
            if (name == null || name.length() == 0) continue;
            sb.append("[ -f \"$M/").append(escapeDq(name))
                    .append("\" ] || bad=$((bad+1)); ");
        }
        sb.append("echo \"COMMIT:$bad\"");
        Access.Result r = Access.sh(sb.toString());
        int bad = parseTag(r.out, "COMMIT:");
        return bad == 0;
    }

    private static String globEscape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '*' || ch == '?' || ch == '[' || ch == ']' || ch == '"' || ch == '\\' || ch == '$'
                    || ch == '`' || ch < 0x20) {
                sb.append('\\');
            }
            sb.append(ch);
        }
        return sb.toString();
    }

    private static String escapeDq(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("$", "\\$").replace("`", "\\`");
    }

    private static int parseTag(String out, String tag) {
        if (out == null) return -1;
        int i = out.indexOf(tag);
        if (i < 0) return -1;
        int j = i + tag.length();
        StringBuilder num = new StringBuilder();
        while (j < out.length() && Character.isDigit(out.charAt(j))) {
            num.append(out.charAt(j));
            j++;
        }
        if (num.length() == 0) return -1;
        try {
            return Integer.parseInt(num.toString());
        } catch (Throwable t) {
            return -1;
        }
    }

    // ------------------------------------------------------------------ 探测

    /** 在 Android/data 里找出战争雷霆手游的包名，找不到返回 null。 */
    public static String detectGamePackage(Context c) {
        String cur = Prefs.pkg(c);
        if (existsDir(c, dataRoot() + "/" + cur)) return cur;
        if (isDirect()) {
            File[] fs = new File(dataRoot()).listFiles();
            if (fs != null) {
                for (File f : fs) {
                    String n = f.getName().toLowerCase();
                    if (n.contains("gaijin") || n.contains("wtm") || n.contains("warthunder")) return f.getName();
                }
            }
            return null;
        }
        Access.Result r = Access.sh("ls -1 " + q(dataRoot()) + " 2>/dev/null");
        if (!r.ok()) return null;
        for (String line : r.out.split("\n")) {
            String s = line.trim();
            if (s.length() == 0) continue;
            String l = s.toLowerCase();
            if (l.contains("gaijin") || l.contains("wtm") || l.contains("warthunder")) return s;
        }
        return null;
    }

    public static boolean gameDirExists(Context c) {
        return existsDir(c, dataRoot() + "/" + pkg(c));
    }

    public static boolean existsDir(Context c, String path) {
        if (path == null) return false;
        if (isDirect()) return new File(path).isDirectory();
        Access.Result r = Access.sh("test -d " + q(path) + " && echo OK_DIR");
        return r.out.contains("OK_DIR");
    }

    public static boolean modDirExists(Context c) {
        return existsDir(c, modDir(c));
    }

    /**
     * 把游戏 mod 目录里的指定文件拷回应用可写目录（用于"把当前使用的文件保存到库"）。
     * 返回成功拷回的文件数。
     */
    public static int pullBanks(Context c, List<String> names, File dest) {
        if (names == null || names.isEmpty()) return 0;
        if (!dest.isDirectory() && !dest.mkdirs()) return 0;
        if (isDirect()) {
            int n = 0;
            for (String name : names) {
                File src = new File(modDir(c), name);
                if (!src.isFile()) continue;
                if (Kit.copyFile(src, new File(dest, name))) n++;
            }
            return n;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("M=").append(q(modDir(c))).append("; D=").append(q(dest.getAbsolutePath())).append("; ok=0; ");
        for (String name : names) {
            sb.append("if cp -f \"$M/").append(escapeDq(name)).append("\" \"$D/\" 2>/dev/null; then ")
                    .append("chmod 644 \"$D/").append(escapeDq(name)).append("\" 2>/dev/null; ok=$((ok+1)); fi; ");
        }
        sb.append("echo \"PULLED:$ok\"");
        Access.Result r = Access.sh(sb.toString());
        int n = 0;
        if (r.out != null) {
            int i = r.out.indexOf("PULLED:");
            if (i >= 0) {
                int j = i + 7;
                StringBuilder num = new StringBuilder();
                while (j < r.out.length() && Character.isDigit(r.out.charAt(j))) {
                    num.append(r.out.charAt(j));
                    j++;
                }
                try {
                    n = Integer.parseInt(num.toString());
                } catch (Throwable ignored) {
                }
            }
        }
        return n;
    }

    /** 算某个文件的 md5（启动自检查重复用；没通道时返回 null）。 */
    public static String fileMd5(Context c, String path) {
        try {
            if (isDirect()) {
                java.io.File f = new java.io.File(path);
                if (!f.isFile()) return null;
                java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
                java.io.FileInputStream in = new java.io.FileInputStream(f);
                try {
                    byte[] buf = new byte[128 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
                } finally {
                    try {
                        in.close();
                    } catch (Throwable ignored) {
                    }
                }
                byte[] d = md.digest();
                StringBuilder sb = new StringBuilder(d.length * 2);
                for (byte b : d) {
                    int v = b & 0xff;
                    if (v < 16) sb.append('0');
                    sb.append(Integer.toHexString(v));
                }
                return sb.toString();
            }
            Access.Result r = Access.sh("md5sum " + q(path) + " 2>/dev/null | awk '{print $1}'");
            if (!r.ok()) return null;
            String h = r.out.trim();
            return h.length() >= 32 ? h.substring(0, 32) : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 旧版本写错位置留下的 .bank（游戏不会读，纯占空间）。 */
    public static List<String> legacyBanks(Context c) {
        List<String> out = new ArrayList<String>();
        if (isDirect()) {
            File[] fs = new File(legacyModDir(c)).listFiles();
            if (fs != null) for (File f : fs) {
                if (f.isFile() && f.getName().toLowerCase().endsWith(".bank")) out.add(f.getName());
            }
            return out;
        }
        Access.Result r = Access.sh("ls -1 " + q(legacyModDir(c)) + " 2>/dev/null");
        if (!r.ok()) return out;
        for (String line : r.out.split("\n")) {
            String s = line.trim();
            if (s.toLowerCase().endsWith(".bank")) out.add(s);
        }
        return out;
    }

    /** 删掉旧路径里本软件写过的 .bank（只清 .bank，别的文件不动）。 */
    public static int clearLegacyBanks(Context c) {
        if (isDirect()) {
            int n = 0;
            File[] fs = new File(legacyModDir(c)).listFiles();
            if (fs != null) for (File f : fs) {
                if (f.isFile() && f.getName().toLowerCase().endsWith(".bank") && f.delete()) n++;
            }
            return n;
        }
        List<String> banks = legacyBanks(c);
        if (banks.isEmpty()) return 0;
        Access.sh("rm -f " + q(legacyModDir(c)) + "/*.[bB][aA][nN][kK] 2>/dev/null");
        return banks.size() - legacyBanks(c).size();
    }

    /**
     * 游戏「原版语音」目录（sound/）里的 bank 文件名 —— 移植时就是照着这些名字产出文件。
     * 手游的 mod 是放进 sound/mod 里加载的，这里列的是可被替换/覆盖的原版资产。
     */
    public static List<String> listSoundBanks(Context c) {
        List<String> out = new ArrayList<String>();
        if (isDirect()) {
            File[] fs = new File(soundDir(c)).listFiles();
            if (fs != null) {
                for (File f : fs) {
                    if (f.isFile() && f.getName().toLowerCase().endsWith(".bank")) out.add(f.getName());
                }
            }
            return out;
        }
        Access.Result r = Access.sh("ls -1 " + q(soundDir(c)) + " 2>/dev/null");
        if (!r.ok()) return out;
        for (String line : r.out.split("\n")) {
            String s = line.trim();
            if (s.toLowerCase().endsWith(".bank")) out.add(s);
        }
        return out;
    }
}
