package com.wtm.voicepack;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

/**
 * Shizuku 授权引导。
 *
 * 三种状态分别给不同的下一步，别让用户看到"未就绪"四个字就卡死：
 *   1. 没装 Shizuku      → 给官网/GitHub 链接（只放链接，不内置 APK，避免二次分发风险）
 *   2. 装了但没运行      → 引导去 Shizuku 里启动（无线调试），再回来重新检测
 *   3. 运行了但没授权    → 调 requestPermission（会自动拉起 Shizuku 授权界面），
 *                          并明确告诉用户：Shizuku 的「授权应用」列表里只会显示"请求过权限"的应用，
 *                          找不到就再点一次这个按钮。
 *
 * 关于链接：Shizuku 是 Rikka 的作品，Apache-2.0；这里只引用官方下载页与 GitHub 仓库，
 * 不分发它的安装包、不使用它的图标，也不暗示任何官方关系。
 */
public final class ShizukuGuide {

    public static final String HOME = "https://shizuku.rikka.app/";
    public static final String DOWNLOAD = "https://shizuku.rikka.app/download/";
    public static final String GITHUB = "https://github.com/RikkaApps/Shizuku";

    private ShizukuGuide() {
    }

    /** 把当前状态说清楚，用在自检和首页副标题。 */
    public static String statusText(Context c) {
        try {
            if (!Shizu.available()) return "内置 Shizuku 库缺失（构建异常）";
            if (Shizu.ping()) {
                if (Shizu.hasPermission()) return "Shizuku 已连接并已授权";
                return "Shizuku 已运行，但本应用还没被授权";
            }
            if (installed(c)) return "已安装 Shizuku，但它没在运行";
            return "没安装 Shizuku";
        } catch (Throwable t) {
            return "Shizuku 状态检测异常";
        }
    }

    public static boolean installed(Context c) {
        try {
            android.content.pm.PackageManager pm = c.getPackageManager();
            if (pm.getLaunchIntentForPackage(Shizu.PKG) != null) return true;
            Intent i = new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setPackage(Shizu.PKG);
            return pm.resolveActivity(i, 0) != null;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 主入口：根据状态弹不同的引导。onRefresh 在用户点"重新检测"时调用。 */
    public static void guide(final Activity a, final Runnable onRefresh) {
        try {
            if (!Shizu.available()) {
                Kit.msg(a, "Shizuku 支持缺失",
                        "这个安装包里没有打进去 Shizuku 的库（构建问题）。\n"
                                + "可以先用 root 通道，或换一个完整构建的安装包。");
                return;
            }
            boolean running = Shizu.ping();
            boolean granted = running && Shizu.hasPermission();

            if (granted) {
                if (!Shizu.canNewProcess()) {
                    Kit.msg(a, "Shizuku 版本太旧",
                            "当前 Shizuku 版本不支持创建 shell 进程，请到 Shizuku 里更新到较新版本。\n\n"
                                    + "也可以用 root 方案，本软件会自动识别。");
                    return;
                }
                if (onRefresh != null) onRefresh.run();
                return;
            }

            if (!running) {
                if (installed(a)) {
                    notRunningDialog(a, onRefresh);
                } else {
                    notInstalledDialog(a, onRefresh);
                }
                return;
            }

            // 已运行但未授权：发起请求 + 说明去哪儿勾
            Prefs.p(a).edit().putLong("last_perm_request", System.currentTimeMillis()).apply();
            Shizu.requestPermission(0);
            requestDialog(a, onRefresh);
        } catch (Throwable t) {
            Kit.msg(a, "引导失败", t.toString());
        }
    }

    private static void notInstalledDialog(final Activity a, final Runnable onRefresh) {
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a, R.style.DialogTheme);
        b.setTitle("需要 Shizuku（或 root）");
        b.setMessage("安卓 11 以后，普通应用和系统文件管理器都读不到\n"
                + "Android/data 里的文件，所以要用 Shizuku 借一个 shell 身份来写游戏目录。\n\n"
                + "· 装 Shizuku（免费、开源，作者 Rikka）\n"
                + "· 打开开发者选项里的「无线调试」，在 Shizuku 里按提示启动\n"
                + "· 回来点「获取文件读写权限」并允许\n\n"
                + "已经 root 的手机不用装 Shizuku，本软件会自动识别 su。\n\n"
                + "本软件只是调用 Shizuku 的公开接口，不分发它的安装包，与 Shizuku 作者没有隶属关系。");
        b.setPositiveButton("打开下载页", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.openUrl(a, DOWNLOAD);
            }
        });
        b.setNeutralButton("GitHub 仓库", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.openUrl(a, GITHUB);
            }
        });
        b.setNegativeButton("关闭", null);
        b.show();
    }

    private static void notRunningDialog(final Activity a, final Runnable onRefresh) {
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a, R.style.DialogTheme);
        b.setTitle("Shizuku 没在运行");
        b.setMessage("Shizuku 是「用一次就停」的服务，重启手机或手动停掉之后都要重新启动。\n\n"
                + "启动步骤：\n"
                + "1. 设置 → 关于手机 → 连续点版本号，打开开发者选项\n"
                + "2. 开发者选项里打开「无线调试」\n"
                + "3. 打开 Shizuku，选「通过无线调试启动」，按提示配对\n"
                + "4. 回到本软件，点下面「重新检测」\n\n"
                + "（已经 root 的手机不需要这一步，本软件会用 su。）");
        b.setPositiveButton("打开 Shizuku", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.openApp(a, Shizu.PKG);
            }
        });
        b.setNeutralButton("重新检测", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                if (onRefresh != null) onRefresh.run();
            }
        });
        b.setNegativeButton("关闭", null);
        b.show();
    }

    private static void requestDialog(final Activity a, final Runnable onRefresh) {
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a, R.style.DialogTheme);
        b.setTitle("去 Shizuku 里授权");
        b.setMessage("刚已经帮你发了一次授权请求。接下来：\n\n"
                + "1. 如果 Shizuku 弹了授权框，点「允许」\n"
                + "2. 没弹框就打开 Shizuku → 底部「授权应用」/「应用」列表，"
                + "找到「战雷手游语音包管理器」（包名 com.wtm.voicepack）并打开开关\n\n"
                + "注意：Shizuku 的授权列表只显示「请求过权限」的应用。"
                + "如果列表里找不到它，回到这里再点一次「重新检测」（会重新发请求），"
                + "再去列表里看一次。\n\n"
                + "本软件只是调用 Shizuku 的公开接口，与 Shizuku 作者没有隶属关系。");
        b.setPositiveButton("打开 Shizuku", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.openApp(a, Shizu.PKG);
            }
        });
        b.setNeutralButton("重新检测", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                // 再发一次请求，方便用户去列表里找到本应用
                try {
                    Shizu.requestPermission(0);
                } catch (Throwable ignored) {
                }
                if (onRefresh != null) onRefresh.run();
            }
        });
        b.setNegativeButton("稍后再说", null);
        b.show();
    }

    /** 设置页/首页的纯说明（不判断状态）。 */
    public static void helpDialog(Activity a) {
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a, R.style.DialogTheme);
        b.setTitle("Shizuku 是什么、为什么要用");
        b.setMessage("问题：安卓 11 以后，第三方应用（包括系统文件管理器）都读不到 "
                + "Android/data 里的文件，而游戏的自制语音正好放在 "
                + "Android/data/com.gaijingames.wtm/files/sound/mod。\n\n"
                + "Shizuku 的作用：它用「无线调试」拿到 shell 权限，把这份权限借给本软件，"
                + "本软件就能以 shell 身份写游戏目录。不用 root，随时可以在 Shizuku 里撤销。\n\n"
                + "授权列表里为什么找不到本软件：Shizuku 只显示「请求过权限」的应用。"
                + "先在本软件点一次「获取文件读写权限」，再去列表里找"
                + "「战雷手游语音包管理器」（com.wtm.voicepack）。\n\n"
                + "已 root 的手机不需要 Shizuku，本软件会自动使用 su。");
        b.setPositiveButton("打开 Shizuku", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.openApp(a, Shizu.PKG);
            }
        });
        b.setNeutralButton("官网", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                Kit.openUrl(a, HOME);
            }
        });
        b.setNegativeButton("关闭", null);
        b.show();
    }
}
