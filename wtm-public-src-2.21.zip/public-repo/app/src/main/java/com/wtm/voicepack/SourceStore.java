package com.wtm.voicepack;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * 在线源管理：内置 WT Live + 用户自填的 JSON 订阅源。
 *
 * 订阅源 JSON 格式（schema 1）：
 * {"schema":1,"name":"某某的语音包源","updatedAt":"2026-11-18",
 *  "packs":[{"id":"p1","name":"空战台词替换","note":"作者/风格","size":12345678,
 *            "bankCount":12,"sha256":"可选的64位hex","url":"https://.../p1.zip"}]}
 * 也允许最外层直接是数组，字段都尽量宽容（id/name/url 必需）。
 */
public final class SourceStore {

    public static final String KEY = "online_sources";
    private static final String CACHE = "online_cache.json";

    public static final class Source {
        public String name = "";
        public String url = "";
        public String type = "json";   // wtlive / json
        public boolean enabled = true;

        public boolean builtin() {
            return "wtlive".equals(type);
        }

        public JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("name", name);
                o.put("url", url);
                o.put("type", type);
                o.put("enabled", enabled);
            } catch (Throwable ignored) {
            }
            return o;
        }

        public static Source fromJson(JSONObject o) {
            Source s = new Source();
            s.name = o.optString("name", "");
            s.url = o.optString("url", "");
            s.type = o.optString("type", "json");
            s.enabled = o.optBoolean("enabled", true);
            return s;
        }
    }

    private SourceStore() {
    }

    public static List<Source> list(Context c) {
        List<Source> out = new ArrayList<Source>();
        try {
            String s = Prefs.p(c).getString(KEY, "");
            if (s == null || s.length() == 0) {
                out.add(defaultWtLive());
                return out;
            }
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) out.add(Source.fromJson(o));
            }
        } catch (Throwable t) {
            out.clear();
        }
        if (out.isEmpty()) out.add(defaultWtLive());
        return out;
    }

    /** 内置源默认关闭：它是端游素材，普通用户点进去只会看到一堆用不了的大包。 */
    private static Source defaultWtLive() {
        Source s = new Source();
        s.name = WtLive.NAME;
        s.url = "builtin:wtlive";
        s.type = "wtlive";
        s.enabled = false;
        return s;
    }

    /** 老版本装过的人：把内置 WT Live 关掉一次，之后以用户设置为准。 */
    public static void ensureMigrated(Context c) {
        if (Prefs.p(c).getBoolean("src_migrated_v16", false)) return;
        List<Source> srcs = list(c);
        boolean changed = false;
        for (Source s : srcs) {
            if (s.builtin() && s.enabled) {
                s.enabled = false;
                changed = true;
            }
        }
        if (changed) save(c, srcs);
        Prefs.p(c).edit().putBoolean("src_migrated_v16", true).apply();
    }

    public static int enabledCount(Context c) {
        int n = 0;
        for (Source s : list(c)) if (s.enabled) n++;
        return n;
    }

    public static void save(Context c, List<Source> srcs) {
        JSONArray a = new JSONArray();
        for (Source s : srcs) a.put(s.toJson());
        Prefs.p(c).edit().putString(KEY, a.toString()).apply();
    }

    public static boolean add(Context c, String name, String url) {
        String u = url == null ? "" : url.trim();
        if (u.length() == 0) return false;

        // github:用户/仓库 或 https://github.com/用户/仓库 → Release 附件源，不用写 index.json
        String repo = GitHubSource.normalizeRepo(u);
        boolean isJson = u.startsWith("http://") || u.startsWith("https://");
        if (repo == null && !isJson) return false;

        List<Source> srcs = list(c);
        String key = repo != null ? repo : u;
        String type = repo != null ? "github" : "json";
        for (Source s : srcs) {
            if (key.equals(s.url)) return false;   // 已经有了
        }
        Source s = new Source();
        s.type = type;
        s.url = key;
        s.name = (name == null || name.trim().length() == 0)
                ? (repo != null ? "GitHub · " + repo : shortUrl(u))
                : name.trim();
        s.enabled = true;
        srcs.add(s);
        save(c, srcs);
        return true;
    }

    public static void remove(Context c, Source src) {
        List<Source> srcs = list(c);
        List<Source> keep = new ArrayList<Source>();
        for (Source s : srcs) {
            if (s == src) continue;
            if (s.url.equals(src.url) && s.type.equals(src.type)) continue;
            keep.add(s);
        }
        save(c, keep);
    }

    public static void setEnabled(Context c, Source src, boolean enabled) {
        List<Source> srcs = list(c);
        for (Source s : srcs) {
            if (s.url.equals(src.url) && s.type.equals(src.type)) s.enabled = enabled;
        }
        save(c, srcs);
    }

    public static Source find(Context c, String url) {
        for (Source s : list(c)) if (s.url.equals(url)) return s;
        return null;
    }

    static String shortUrl(String u) {
        try {
            String host = new java.net.URL(u).getHost();
            return host == null ? "订阅源" : host;
        } catch (Throwable t) {
            return "订阅源";
        }
    }

    // ------------------------------------------------------------------ 拉取

    /**
     * page=0 拉第一页；其它页只有 WT Live 支持（自定义源通常一次给全量）。
     * errors 会收集每个源的失败原因，界面可以提示。
     */
    public static List<OnlinePack> fetch(Context c, int page, String sort, String search,
                                        List<String> errors) {
        List<OnlinePack> out = new ArrayList<OnlinePack>();
        for (Source s : list(c)) {
            if (!s.enabled) continue;
            try {
                if (s.builtin()) {
                    out.addAll(WtLive.fetch(page, sort, search));
                } else if ("github".equals(s.type)) {
                    if (page == 0) out.addAll(GitHubSource.fetch(s.url, search));
                } else if (page == 0) {
                    out.addAll(fetchJson(s, search));
                }
            } catch (Throwable t) {
                if (errors != null) {
                    String m = t.getMessage();
                    if (m == null || m.length() == 0) m = t.getClass().getSimpleName();
                    errors.add(s.name + "：" + (m.length() > 90 ? m.substring(0, 90) + "…" : m));
                }
            }
        }

        // 按 url 去重（不同源可能有同一个包）
        List<OnlinePack> uniq = new ArrayList<OnlinePack>();
        List<String> seen = new ArrayList<String>();
        for (OnlinePack p : out) {
            if (p.url.length() == 0 || seen.contains(p.url)) continue;
            seen.add(p.url);
            uniq.add(p);
        }
        sort(uniq, sort);
        return uniq;
    }

    public static void sort(List<OnlinePack> list, final String sort) {
        Collections.sort(list, new Comparator<OnlinePack>() {
            public int compare(OnlinePack a, OnlinePack b) {
                if ("date".equals(sort)) {
                    if (a.updatedAt != b.updatedAt) return a.updatedAt > b.updatedAt ? -1 : 1;
                    return a.downloads > b.downloads ? -1 : (a.downloads == b.downloads ? 0 : 1);
                }
                if ("size".equals(sort)) {
                    // 体积未知的（0）排最后
                    long as = a.size <= 0 ? Long.MAX_VALUE : a.size;
                    long bs = b.size <= 0 ? Long.MAX_VALUE : b.size;
                    return as < bs ? -1 : (as == bs ? 0 : 1);
                }
                if (a.downloads != b.downloads) return a.downloads > b.downloads ? -1 : 1;
                return a.updatedAt > b.updatedAt ? -1 : (a.updatedAt == b.updatedAt ? 0 : 1);
            }
        });
    }

    // ------------------------------------------------------------------ 自定义 JSON 源

    static List<OnlinePack> fetchJson(Source src, String search) throws Exception {
        String text = Net.get(src.url, null);
        JSONArray arr = null;
        String sourceName = src.name;
        String t = text.trim();
        if (t.startsWith("[")) {
            arr = new JSONArray(t);
        } else {
            JSONObject root = new JSONObject(t);
            arr = root.optJSONArray("packs");
            String n = root.optString("name", "");
            if (n.length() > 0) sourceName = n;
        }
        List<OnlinePack> out = new ArrayList<OnlinePack>();
        if (arr == null) return out;
        String q = search == null ? "" : search.trim().toLowerCase(Locale.US);
        if (q.startsWith("#")) q = q.substring(1);

        for (int i = 0; i < arr.length() && i < 300; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String url = o.optString("url", "");
            if (url.length() == 0) continue;
            OnlinePack p = new OnlinePack();
            p.source = sourceName;
            p.sourceType = "json";
            p.url = url;
            p.id = o.optString("id", "j" + i);
            p.title = o.optString("name", o.optString("title", "未命名语音包"));
            p.note = o.optString("note", o.optString("author", ""));
            p.desc = o.optString("desc", o.optString("description", ""));
            p.size = o.optLong("size", 0);
            p.bankCount = o.optInt("bankCount", o.optInt("count", 0));
            p.sha256 = o.optString("sha256", "");
            p.pageUrl = o.optString("page", "");
            long ts = o.optLong("updatedAt", 0);
            if (ts > 0 && ts < 100000000000L) ts *= 1000L;   // 兼容秒级时间戳
            p.updatedAt = ts;

            JSONArray tags = o.optJSONArray("tags");
            if (tags != null && tags.length() > 0) {
                StringBuilder sb = new StringBuilder();
                for (int k = 0; k < tags.length(); k++) {
                    if (sb.length() > 0) sb.append(' ');
                    sb.append(tags.optString(k));
                }
                p.note = p.note.length() > 0 ? (p.note + " · " + sb) : sb.toString();
            }

            if (q.length() > 0) {
                String hay = (p.title + " " + p.note + " " + p.desc).toLowerCase(Locale.US);
                if (!hay.contains(q)) continue;
            }
            out.add(p);
        }
        return out;
    }

    /** 试读结果：添加前先确认这个源是什么、有多少包。 */
    public static final class Preview {
        public boolean ok;
        public String name = "";
        public int count = 0;
        public String error = "";
        public List<OnlinePack> packs = new ArrayList<OnlinePack>();
    }

    /** 试读一个源地址：index.json / 任意 http(s) 清单 / github:用户/仓库。 */
    public static Preview preview(Context c, String input) {
        Preview pv = new Preview();
        String u = input == null ? "" : input.trim();
        if (u.length() == 0) {
            pv.error = "地址是空的";
            return pv;
        }
        try {
            String repo = GitHubSource.normalizeRepo(u);
            List<OnlinePack> list;
            if (repo != null) {
                list = GitHubSource.fetch(repo, "");
                pv.name = "GitHub · " + repo;
            } else if (u.startsWith("http://") || u.startsWith("https://")) {
                Source s = new Source();
                s.name = shortUrl(u);
                s.url = u;
                s.type = "json";
                list = fetchJson(s, "");
                pv.name = s.name;
                if (!list.isEmpty() && list.get(0).source != null && list.get(0).source.length() > 0) {
                    pv.name = list.get(0).source;
                }
            } else {
                pv.error = "地址要 http(s) 开头，或者写成 github:用户/仓库";
                return pv;
            }
            pv.packs = list;
            pv.count = list.size();
            pv.ok = true;
            if (pv.count == 0) pv.error = "能打开，但里面没有可用的包（检查清单格式）";
        } catch (Throwable t) {
            String m = t.getMessage();
            pv.error = (m == null || m.length() == 0) ? t.toString() : m;
        }
        return pv;
    }

    // ------------------------------------------------------------------ 断网缓存

    static File cacheFile(Context c) {
        return new File(PackStore.baseDir(c), CACHE);
    }

    public static void saveCache(Context c, List<OnlinePack> list) {
        try {
            JSONArray a = new JSONArray();
            int n = 0;
            for (OnlinePack p : list) {
                if (n++ >= 200) break;
                a.put(p.toJson());
            }
            File f = cacheFile(c);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            fos.write(a.toString().getBytes("UTF-8"));
            fos.flush();
            fos.close();
        } catch (Throwable ignored) {
        }
    }

    public static List<OnlinePack> loadCache(Context c) {
        List<OnlinePack> out = new ArrayList<OnlinePack>();
        try {
            File f = cacheFile(c);
            if (!f.isFile()) return out;
            String s = PackStore.readText(f);
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) out.add(OnlinePack.fromJson(o));
            }
        } catch (Throwable ignored) {
        }
        return out;
    }
}
