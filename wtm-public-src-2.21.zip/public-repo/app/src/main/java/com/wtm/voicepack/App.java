package com.wtm.voicepack;

import android.app.Application;

public final class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // 崩溃兜底：未捕获异常写到应用目录，设置页可一键导出诊断
        CrashLog.install(this);
    }
}
