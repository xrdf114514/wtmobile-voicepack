package com.wtm.voicepack;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 把一个语音包导出成「可以发出去」的 zip：
 *   banks/<xxx>.bank ...
 *   meta.json           （名称/备注/文件数/指纹，本软件导入时会用）
 *   README.txt          （给拿到包的人看）
 *
 * 导出的包既能再次被本软件导入，也能作为订阅源里的成品包发出去。
 */
public final class ExportUtil {

    private ExportUtil() {
    }

    public static File toZip(Context c, Pack p) throws Exception {
        File dir = c.getCacheDir();
        if (dir == null) dir = new File("/data/local/tmp");
        String base = Kit.safeName(p.name);
        if (base.length() == 0) base = "voicepack";
        File out = new File(dir, "wtm_export_" + base + ".zip");

        File banks = p.banksDir(c);
        File[] files = banks.listFiles();
        if (files == null || files.length == 0) throw new Exception("这个语音包的文件不在了");

        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out));
        try {
            for (File f : files) {
                if (!f.isFile()) continue;
                ZipEntry e = new ZipEntry("banks/" + f.getName());
                e.setTime(f.lastModified());
                zos.putNextEntry(e);
                InputStream in = new java.io.FileInputStream(f);
                try {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
                } finally {
                    try {
                        in.close();
                    } catch (Throwable ignored) {
                    }
                }
                zos.closeEntry();
            }

            JSONObject meta = p.toJson();
            meta.put("exportedBy", "战雷手游语音包管理器 v2.10-private");
            meta.put("exportedAt", System.currentTimeMillis());
            writeEntry(zos, "meta.json", meta.toString(2).getBytes("UTF-8"));

            StringBuilder readme = new StringBuilder();
            readme.append("语音包：").append(p.name).append('\n');
            if (p.note != null && p.note.length() > 0) readme.append("备注：").append(p.note).append('\n');
            readme.append("文件：").append(p.count).append(" 个 .bank\n");
            readme.append("解压后把 banks 里的 .bank 放进游戏的 files/sound/mod 目录即可（手游要先把游戏改成优先加载 mod）。\n");
            readme.append("注意：端游(PC)的音效包不能直接用于手游，需要移植；本包如果是从本软件导出的，通常是手游可用的。\n");
            writeEntry(zos, "README.txt", readme.toString().getBytes("UTF-8"));
        } finally {
            try {
                zos.close();
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    private static void writeEntry(ZipOutputStream zos, String name, byte[] data) throws Exception {
        ZipEntry e = new ZipEntry(name);
        zos.putNextEntry(e);
        zos.write(data);
        zos.closeEntry();
    }

    public static String sha256(File f) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            InputStream in = new java.io.FileInputStream(f);
            try {
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            } finally {
                try {
                    in.close();
                } catch (Throwable ignored) {
                }
            }
            byte[] d = md.digest();
            StringBuilder sb = new StringBuilder(d.length * 2);
            for (byte b : d) {
                int v = b & 0xff;
                if (v < 16) sb.append('0');
                sb.append(Integer.toHexString(v));
            }
            return sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    /** 生成订阅源 index.json 里可以直接粘的一条。 */
    public static String indexEntry(Context c, Pack p, File zip) throws Exception {
        JSONObject o = new JSONObject();
        String base = Kit.safeName(p.name).replace(' ', '_');
        if (base.length() == 0) base = "pack";
        o.put("id", base + "_" + (p.id.length() > 8 ? p.id.substring(0, 8) : p.id));
        o.put("name", p.name);
        if (p.note != null && p.note.length() > 0) o.put("note", p.note);
        o.put("size", zip.length());
        o.put("bankCount", p.count);
        String sha = sha256(zip);
        if (sha.length() > 0) o.put("sha256", sha);
        o.put("url", "把这里换成本包直链（比如 GitHub Release 的 zip 链接）");
        return o.toString(2);
    }
}
