package com.wtm.voicepack;

import android.content.Context;
import android.os.Build;

import java.util.List;
import java.util.Locale;

/** 环境自检：把定位问题需要的信息一次性列出来，可复制发人。 */
public final class SelfCheck {

    private SelfCheck() {
    }

    public static String build(Context c) {
        StringBuilder sb = new StringBuilder();
        sb.append("应用: 战雷手游语音包管理器 ").append(CrashLog.appVersion(c)).append('\n');
        sb.append("系统: Android ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("机型: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        sb.append("ABI: ").append(Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "?").append('\n');
        sb.append('\n');

        // 权限通道
        sb.append("— 权限通道 —\n");
        sb.append("当前通道: ").append(Access.channelName()).append('\n');
        sb.append("说明: ").append(Access.detail).append('\n');
        try {
            sb.append("Shizuku 库加载: ").append(Shizu.available() ? "OK" : "失败（" + Shizu.loadError() + "）").append('\n');
            sb.append("Shizuku 在线: ").append(Shizu.ping() ? "是" : "否").append('\n');
            sb.append("Shizuku 授权: ").append(Shizu.hasPermission() ? "已授权" : "未授权").append('\n');
            int v = Shizu.version();
            sb.append("Shizuku 版本: ").append(v > 0 ? String.valueOf(v) : "获取不到").append('\n');
            sb.append("可创建 shell 进程: ").append(Shizu.canNewProcess() ? "是" : "否").append('\n');
            if (Shizu.loadError().length() > 0) {
                sb.append("Shizuku 说明: ").append(Shizu.loadError()).append('\n');
            }
            // provider 是否真的合并进了清单（合并失败的话 Shizuku 永远收不到 binder）
            try {
                boolean prov = c.getPackageManager().resolveContentProvider(
                        c.getPackageName() + ".shizuku", 0) != null;
                sb.append("Shizuku 接收器(provider): ").append(prov ? "已注册" : "缺失！").append('\n');
            } catch (Throwable t) {
                sb.append("Shizuku 接收器(provider): 检测失败\n");
            }
            long lastReq = Prefs.p(c).getLong("last_perm_request", 0);
            sb.append("上次请求授权: ").append(lastReq == 0 ? "从未" : Kit.fmtAgo(lastReq)).append('\n');
            sb.append("Shizuku 安装状态: ").append(ShizukuGuide.installed(c) ? "已安装" : "未安装").append('\n');
            if (Shizu.ping() && Shizu.hasPermission()) {
                sb.append("shell 执行测试: ").append(probe())
                        .append(Shizu.rawCode() > 0 ? " [原生事务 " + Shizu.rawCode() + "]" : " [API]")
                        .append('\n');
            }
        } catch (Throwable t) {
            sb.append("Shizuku 检测异常: ").append(t).append('\n');
        }
        sb.append('\n');

        // 游戏目录
        sb.append("— 游戏目录 —\n");
        String pkg = Prefs.pkg(c);
        sb.append("游戏包名: ").append(pkg).append('\n');
        sb.append("目标目录: ").append(GameDir.modDir(c)).append('\n');
        try {
            boolean game = GameDir.gameDirExists(c);
            boolean sound = GameDir.existsDir(c, GameDir.soundDir(c));
            boolean mod = GameDir.modDirExists(c);
            boolean w = Access.ready() && GameDir.probeWritable(c);
            sb.append("游戏数据目录: ").append(game ? "存在" : "不存在").append('\n');
            sb.append("sound 目录: ").append(sound ? "存在" : "不存在").append('\n');
            sb.append("mod 目录: ").append(mod ? "存在" : "不存在")
                    .append(" · ").append(w ? "可写" : "不可写/未检测").append('\n');
            if (Access.ready()) {
                sb.append("sound 里原版 bank: ").append(GameDir.listSoundBanks(c).size()).append(" 个\n");
                int legacy = GameDir.legacyBanks(c).size();
                if (legacy > 0) {
                    sb.append("⚠ 旧路径残留: ").append(legacy).append(" 个 bank（")
                            .append(GameDir.legacyModDir(c)).append("，可清理）\n");
                }
                sb.append("mod 里 bank: ").append(GameDir.listBanks(c).size()).append(" 个\n");
                long modSize = GameDir.modSize(c);
                if (modSize >= 0) sb.append("mod 占用: ").append(Kit.fmtSize(modSize)).append('\n');
            }
        } catch (Throwable t) {
            sb.append("目录检测异常: ").append(t).append('\n');
        }
        sb.append('\n');

        // 语音包库
        sb.append("— 语音包库 —\n");
        try {
            List<Pack> packs = PackStore.list(c);
            long total = 0;
            int fav = 0;
            long biggest = 0;
            for (Pack p : packs) {
                total += p.size;
                if (p.favorite) fav++;
                if (p.size > biggest) biggest = p.size;
            }
            sb.append("包数量: ").append(packs.size()).append(" 个（收藏 ").append(fav).append("）\n");
            sb.append("总占用: ").append(Kit.fmtSize(total))
                    .append(" · 最大单包: ").append(Kit.fmtSize(biggest)).append('\n');
            sb.append("库位置: ").append(PackStore.libraryDir(c)).append('\n');
            sb.append("临时目录: ").append(Kit.fmtSize(Kit.dirSize(PackStore.tmpDir(c)))).append('\n');
            java.io.File base = PackStore.baseDir(c);
            long free = base.getFreeSpace();
            long totalSpace = base.getTotalSpace();
            sb.append("应用存储剩余: ").append(Kit.fmtSize(free))
                    .append(" / ").append(Kit.fmtSize(totalSpace)).append('\n');
        } catch (Throwable t) {
            sb.append("库检测异常: ").append(t).append('\n');
        }
        sb.append('\n');

        // 当前生效
        sb.append("— 当前状态 —\n");
        String appliedName = Prefs.appliedName(c);
        sb.append("当前语音包: ").append(appliedName == null || appliedName.length() == 0
                ? "未应用（原版）" : appliedName).append('\n');
        sb.append("上次换包: ").append(Kit.fmtAgo(Prefs.appliedAt(c))).append('\n');
        sb.append("崩溃记录: ").append(CrashLog.count(c)).append(" 条");
        if (CrashLog.count(c) > 0) {
            sb.append("（最近 ").append(Kit.fmtTime(CrashLog.lastAt(c))).append("）");
        }
        sb.append('\n');
        sb.append('\n').append(String.format(Locale.US, "生成于 %s", new java.util.Date().toString()));
        return sb.toString();
    }

    /**
     * 真起一条 shell 命令：把「库/授权都正常但进程起不来」和「进程能起但读不到目录」分开。
     * 结果压成一行，方便直接贴出来。
     */
    private static String probe() {
        Process p = null;
        try {
            p = Shizu.newProcess(new String[]{"/system/bin/sh", "-c",
                    "id; echo ---; ls -1 /sdcard/Android/data 2>&1 | head -3"});
            StringBuilder out = new StringBuilder();
            java.io.InputStream in = p.getInputStream();
            byte[] b = new byte[4096];
            long end = System.currentTimeMillis() + 4000;
            while (System.currentTimeMillis() < end) {
                if (in.available() > 0) {
                    int n = in.read(b);
                    if (n > 0) out.append(new String(b, 0, n, "UTF-8"));
                } else if (!alive(p)) {
                    break;
                } else {
                    Thread.sleep(30);
                }
            }
            String s = out.toString().replace("\r", "").trim().replace("\n", " / ");
            return s.length() > 0 ? s : "无输出（超时）";
        } catch (Throwable t) {
            return "失败 → " + Shizu.describe(t);
        } finally {
            if (p != null) {
                try {
                    p.destroy();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    private static boolean alive(Process p) {
        try {
            p.exitValue();
            return false;
        } catch (IllegalArgumentException running) {
            // 远端进程把 IllegalThreadStateException 折成了 IllegalArgumentException
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
