package com.wtm.voicepack;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.net.URLEncoder;

/** 使用教程：说清楚「为什么需要 Shizuku」「为什么必须先改包」，并提供 B 站入口。 */
public final class GuideActivity extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_guide);

        TextView tvTitle = (TextView) findViewById(R.id.tvTitle);
        TextView btnBack = (TextView) findViewById(R.id.btnBack);
        TextView tvGuide = (TextView) findViewById(R.id.tvGuide);
        TextView btnBili = (TextView) findViewById(R.id.btnBili);
        TextView btnCopyPath = (TextView) findViewById(R.id.btnCopyPath);
        TextView btnCopyPkg = (TextView) findViewById(R.id.btnCopyPkg);

        tvTitle.setText("使用教程");
        btnBack.setOnClickListener(this);
        btnBili.setOnClickListener(this);
        btnCopyPath.setOnClickListener(this);
        btnCopyPkg.setOnClickListener(this);

        tvGuide.setText(
                "① 先把权限配好（一次性）\n"
                        + "安卓 11 之后，谷歌收紧了 Android/data 目录：第三方应用读不到，连系统文件管理器也不容易写进去。\n"
                        + "解决办法是装一个 Shizuku，它通过「无线调试」拿到 shell 权限，本软件借用这个身份去写游戏目录，"
                        + "不用 root，随时可以在 Shizuku 里撤销。\n"
                        + "步骤：装 Shizuku → 打开开发者选项里的「无线调试」→ 在 Shizuku 里按提示启动 → 回到本软件首页点「获取文件读写权限」并允许。\n"
                        + "已经 root 的手机不用管这些，本软件会自动检测 su。\n\n"
                        + "② 游戏必须先改包（软件不负责改包）\n"
                        + "自制语音包只有在游戏的 mod 目录下、并且游戏被改成「优先加载 mod」时才会生效。\n"
                        + "这是改包教程才能解决的事，B 站搜「战争雷霆手游 改包」即可；改好之后游戏才会读 "
                        + GameDir.modDir(this) + " 这个目录。\n"
                        + "注意目录名是 mod，不是 mods。\n\n"
                        + "③ 导入语音包\n"
                        + "首页 →「导入语音包」→ 选作者发的 .zip（也可以直接多选 .bank 文件）→ 起个自己好记的名字。\n"
                        + "软件会自动从压缩包里提取 .bank，其余文件忽略；中文乱码的压缩包也能正确识别。\n"
                        + "起名建议带上作者或风格，比如「某某作者-空战台词」，以后检索更快。\n\n"
                        + "④ 快捷更换\n"
                        + "首页 →「快捷更换语音包」（或「语音包库」）→ 点一下即可。\n"
                        + "换包时会先清空 mod 目录里旧的 .bank，再写入新包的 .bank，所以目录里永远只有当前这一套，不会越换越多。\n"
                        + "库里按内容指纹去重：同一个包重复导入也只占一份空间。\n\n"
                        + "⑤ 想回原版\n"
                        + "首页 →「恢复原版」，会清空 mod 目录里的 .bank，游戏就用回原版语音；库里存的包不会删，随时能换回来。\n\n"
                        + "⑥ 常见问题\n"
                        + "· 提示没找到 .bank：确认下载的是语音包本体，不是网盘里的说明文件；有些作者会二次压缩，需要先解压一层。\n"
                        + "· 提示目录不可写：回首页重新获取权限；Shizuku 被杀掉后要重新启动一次。\n"
                        + "· 换了包但游戏里没变化：先确认改包成功了、进游戏前完全退出过；部分机型需要清一下游戏缓存。\n"
                        + "· 目录里有别人的 mod：换包前会提醒会被覆盖的文件，介意的话先手动备份。\n"
        );
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnBack) {
            finish();
        } else if (id == R.id.btnBili) {
            try {
                String kw = URLEncoder.encode("战争雷霆手游 改包 语音包", "UTF-8");
                Kit.openUrl(this, "https://search.bilibili.com/all?keyword=" + kw);
            } catch (Throwable t) {
                Kit.openUrl(this, "https://search.bilibili.com/");
            }
        } else if (id == R.id.btnCopyPath) {
            Kit.copy(this, GameDir.modDir(this), "目标目录路径");
        } else if (id == R.id.btnCopyPkg) {
            Kit.copy(this, Prefs.pkg(this), "游戏包名");
        }
    }
}
