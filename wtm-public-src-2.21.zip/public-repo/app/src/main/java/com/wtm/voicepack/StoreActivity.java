package com.wtm.voicepack;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 在线语音包。
 *
 * 两类来源，行为不一样：
 *   · 订阅源（json，制作者自建）= 手游可用的成品包 → 下载后直接入库，可一键换包
 *   · WT Live   = 端游素材，bank 不能直接用，要移植 → 只能下载到 Download 供你在电脑上处理
 */
public final class StoreActivity extends Activity implements View.OnClickListener {

    private static final long SIZE_LIMIT = 150L * 1024 * 1024;
    private static final String[] SORTS = {"downloads", "date", "size"};
    private static final String[] SORT_NAMES = {"下载最多", "最新", "体积最小"};

    private EditText etSearch;
    private TextView btnSearch, btnSort, btnSize, tvStat, tvEmpty, btnRetry, btnMore, btnSources,
            tvTitle, btnRight, btnBack, tvBanner, btnAddSource;
    private boolean firstResume = true;
    private ListView listOnline;
    private View emptyBox;

    private final List<OnlinePack> data = new ArrayList<OnlinePack>();
    private final List<OnlinePack> shown = new ArrayList<OnlinePack>();
    private OnlineAdapter adapter;

    private int page = 0;
    private String sort = "downloads";
    private String search = "";
    private boolean sizeFilter = false;
    private boolean loading = false;
    private boolean hasMore = true;
    private volatile boolean downloading = false;
    private volatile boolean cancelFlag = false;

    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_store);

        tvTitle = (TextView) findViewById(R.id.tvTitle);
        btnBack = (TextView) findViewById(R.id.btnBack);
        btnRight = (TextView) findViewById(R.id.btnRight);
        etSearch = (EditText) findViewById(R.id.etSearch);
        btnSearch = (TextView) findViewById(R.id.btnSearch);
        btnSort = (TextView) findViewById(R.id.btnSort);
        btnSize = (TextView) findViewById(R.id.btnSize);
        tvStat = (TextView) findViewById(R.id.tvStat);
        listOnline = (ListView) findViewById(R.id.listOnline);
        emptyBox = findViewById(R.id.emptyBox);
        tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        btnRetry = (TextView) findViewById(R.id.btnRetry);
        btnMore = (TextView) findViewById(R.id.btnMore);
        btnSources = (TextView) findViewById(R.id.btnSources);
        tvBanner = (TextView) findViewById(R.id.tvBanner);
        btnAddSource = (TextView) findViewById(R.id.btnAddSource);

        tvTitle.setText("在线语音包");
        btnRight.setText("刷新");
        btnRight.setVisibility(View.VISIBLE);
        btnBack.setOnClickListener(this);
        btnRight.setOnClickListener(this);
        btnSearch.setOnClickListener(this);
        btnSort.setOnClickListener(this);
        btnSize.setOnClickListener(this);
        btnRetry.setOnClickListener(this);
        btnMore.setOnClickListener(this);
        btnSources.setOnClickListener(this);
        if (tvBanner != null) tvBanner.setOnClickListener(this);
        if (btnAddSource != null) btnAddSource.setOnClickListener(this);

        btnSort.setText(SORT_NAMES[0]);
        updateSizeChip();

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b2, int c) {
            }

            public void afterTextChanged(Editable s) {
                String t = s.toString().trim();
                if (t.length() == 0 && search.length() > 0) {
                    search = "";
                    load(0, false);
                }
            }
        });

        adapter = new OnlineAdapter();
        listOnline.setAdapter(adapter);
        listOnline.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                if (pos < 0 || pos >= shown.size()) return;
                showDetail(shown.get(pos));
            }
        });

        SourceStore.ensureMigrated(this);
        load(0, false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (firstResume) {
            firstResume = false;
            return;
        }
        load(0, false);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnBack) {
            finish();
        } else if (id == R.id.btnRight) {
            load(0, false);
        } else if (id == R.id.btnSearch) {
            search = etSearch.getText().toString().trim();
            load(0, false);
        } else if (id == R.id.btnSort) {
            sort = SORTS[(indexOf(SORTS, sort) + 1) % SORTS.length];
            btnSort.setText(SORT_NAMES[indexOf(SORTS, sort)]);
            load(0, false);
        } else if (id == R.id.btnSize) {
            sizeFilter = !sizeFilter;
            updateSizeChip();
            applyFilter();
        } else if (id == R.id.btnRetry) {
            load(0, false);
        } else if (id == R.id.btnMore) {
            load(page + 1, true);
        } else if (id == R.id.btnSources || id == R.id.btnAddSource || id == R.id.tvBanner) {
            startActivity(new android.content.Intent(this, SourceActivity.class));
        }
    }

    private static int indexOf(String[] arr, String v) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(v)) return i;
        return 0;
    }

    private void updateSizeChip() {
        btnSize.setText(sizeFilter ? "≤150MB" : "全部体积");
        btnSize.setTextColor(getResources().getColor(sizeFilter ? R.color.gold : R.color.sub));
    }

    // ------------------------------------------------------------------ 加载

    private void load(final int p, final boolean append) {
        if (loading) return;
        if (SourceStore.enabledCount(this) == 0) {
            loading = false;
            data.clear();
            applyFilter();
            tvBanner.setVisibility(View.GONE);
            showEmpty("还没有可用的订阅源\n\n"
                    + "「订阅源」是别人（制作者/社区）维护的一份手游成品包清单，"
                    + "本软件不内置任何包内容。\n\n"
                    + "· 有现成地址：点下面「添加订阅源」填进去（index.json 地址或 github:用户/仓库）\n"
                    + "· 没有的话：找制作者要一个，或者点右上「订阅源」自己建一个（有模板）", true);
            if (btnAddSource != null) btnAddSource.setVisibility(View.VISIBLE);
            btnRetry.setText("重新检查");
            return;
        }
        loading = true;
        if (!append) showEmpty("正在加载…", false);
        final String q = search;
        final String s = sort;
        new Thread(new Runnable() {
            public void run() {
                List<String> errors = new ArrayList<String>();
                List<OnlinePack> res = new ArrayList<OnlinePack>();
                try {
                    res = SourceStore.fetch(StoreActivity.this, p, s, q, errors);
                } catch (Throwable t) {
                    String m = t.getMessage();
                    errors.add("加载失败：" + (m == null ? t.getClass().getSimpleName() : m));
                }
                final List<OnlinePack> fr = res;
                final List<String> fe = errors;
                ui.post(new Runnable() {
                    public void run() {
                        loading = false;
                        if (!Kit.alive(StoreActivity.this)) return;
                        page = p;
                        if (!append) data.clear();
                        data.addAll(fr);
                        hasMore = fr.size() > 0;
                        if (p == 0 && !fr.isEmpty()) SourceStore.saveCache(StoreActivity.this, fr);
                        applyFilter();
                        if (!fe.isEmpty() && !fr.isEmpty()) {
                            Kit.toast(StoreActivity.this, "部分源加载失败：" + fe.get(0));
                        }
                        if (fr.isEmpty() && !fe.isEmpty()) {
                            // 断网/源挂了：回退到上次缓存的列表（仍可查看，下载需要网络）
                            List<OnlinePack> cache = p == 0 && !append
                                    ? SourceStore.loadCache(StoreActivity.this) : new ArrayList<OnlinePack>();
                            if (!cache.isEmpty()) {
                                data.clear();
                                data.addAll(cache);
                                applyFilter();
                                Kit.toast(StoreActivity.this, "连不上源，显示的是上次缓存的列表");
                                return;
                            }
                            showEmpty("加载失败：\n" + fe.get(0) + "\n\n检查网络，或在「订阅源」里只留能连上的源。", true);
                        } else if (fr.isEmpty()) {
                            showEmpty("没有结果。\n换个人气标签试试，比如 #voice、#crew。", true);
                        }
                    }
                });
            }
        }, "wtm-online").start();
    }

    private void showEmpty(String text, boolean retry) {
        emptyBox.setVisibility(View.VISIBLE);
        listOnline.setVisibility(View.GONE);
        tvEmpty.setText(text);
        btnRetry.setVisibility(retry ? View.VISIBLE : View.GONE);
        if (btnAddSource != null) {
            btnAddSource.setVisibility(SourceStore.enabledCount(this) == 0 ? View.VISIBLE : View.GONE);
        }
    }

    private void applyFilter() {
        shown.clear();
        int hidden = 0;
        for (OnlinePack p : data) {
            if (sizeFilter && p.size > SIZE_LIMIT) {
                hidden++;
                continue;
            }
            shown.add(p);
        }
        adapter.notifyDataSetChanged();
        boolean empty = shown.isEmpty();
        emptyBox.setVisibility(empty ? View.VISIBLE : View.GONE);
        listOnline.setVisibility(empty ? View.GONE : View.VISIBLE);
        if (!empty) {
            tvEmpty.setText("");
        }
        btnMore.setVisibility(hasMore && !empty ? View.VISIBLE : View.GONE);

        boolean allWt = !shown.isEmpty();
        for (OnlinePack op : shown) {
            if (!"wtlive".equals(op.sourceType)) {
                allWt = false;
                break;
            }
        }
        if (tvBanner != null) {
            if (allWt) {
                tvBanner.setVisibility(View.VISIBLE);
                tvBanner.setText("现在显示的是 WT Live 的端游素材（bank 不能直接用，要移植）。\n"
                        + "想要能直接换包的手游成品，点这里添加订阅源 →");
            } else if (shown.isEmpty() && !data.isEmpty()) {
                tvBanner.setVisibility(View.VISIBLE);
                tvBanner.setText("当前过滤条件下没有结果，点这里调整订阅源或体积过滤");
            } else {
                tvBanner.setVisibility(View.GONE);
            }
        }
        StringBuilder stat = new StringBuilder();
        stat.append(shown.size()).append(" 个");
        if (hidden > 0) stat.append("（隐藏 ").append(hidden).append(" 个大包）");
        tvStat.setText(stat.toString());
    }

    // ------------------------------------------------------------------ 详情

    private void showDetail(final OnlinePack p) {
        boolean wt = "wtlive".equals(p.sourceType);
        StringBuilder sb = new StringBuilder();
        sb.append(p.source);
        if (wt) sb.append(" · 端游素材（需移植）");
        else sb.append(" · 手游成品包");
        sb.append('\n');
        sb.append("体积：").append(p.size > 0 ? Kit.fmtSize(p.size) : "未知").append('\n');
        if (p.downloads > 0) sb.append("下载量：").append(WtLive.human(p.downloads)).append('\n');
        if (p.updatedAt > 0) sb.append("更新时间：").append(Kit.fmtTime(p.updatedAt)).append('\n');
        if (p.bankCount > 0) sb.append("bank 数量：").append(p.bankCount).append('\n');
        if (wt) {
            sb.append("\n⚠️ 这是端游音效包，bank 文件不能直接放进手游，");
            sb.append("要在电脑上解包、提取音频再按手游的 bank 重打包。\n");
            sb.append("推荐：先「下载素材」到手机下载目录，再拷到电脑处理。");
        }
        if (p.desc != null && p.desc.length() > 0) {
            sb.append("\n\n").append(p.desc);
        }

        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DialogTheme);
        b.setTitle(p.title);
        b.setMessage(sb.toString());
        if (wt) {
            b.setPositiveButton("下载素材", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    download(p, true, false);
                }
            });
            b.setNeutralButton("仍要试导入", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    download(p, false, false);
                }
            });
            b.setNegativeButton("复制直链", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    Kit.copy(StoreActivity.this, p.url, "直链");
                }
            });
        } else {
            b.setPositiveButton("下载并导入", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    download(p, false, true);
                }
            });
            b.setNeutralButton("复制直链", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    Kit.copy(StoreActivity.this, p.url, "直链");
                }
            });
            b.setNegativeButton("关闭", null);
        }
        b.show();
    }

    // ------------------------------------------------------------------ 下载

    private void download(final OnlinePack p, final boolean saveOnly, final boolean applyAfterAsk) {
        if (downloading) {
            Kit.toast(this, "正在下载另一个包，稍等");
            return;
        }
        final Runnable start = new Runnable() {
            public void run() {
                doDownload(p, saveOnly, applyAfterAsk);
            }
        };
        if (p.size > 200L * 1024 * 1024) {
            Kit.confirm(this, "这个包挺大",
                    "体积约 " + Kit.fmtSize(p.size) + "，建议连 WiFi 下载，流量党慎点。",
                    "继续下载", start);
            return;
        }
        start.run();
    }

    private void doDownload(final OnlinePack p, final boolean saveOnly, final boolean applyAfterAsk) {
        long free = getCacheDir().getFreeSpace();
        if (p.size > 0 && free > 0 && free < p.size + 20L * 1024 * 1024) {
            Kit.msg(this, "空间不足",
                    "临时空间只剩 " + Kit.fmtSize(free) + "，这个包要 " + Kit.fmtSize(p.size)
                            + "。\n清点存储后再试。");
            return;
        }
        downloading = true;
        cancelFlag = false;

        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("准备下载…");
        pd.setCancelable(true);
        pd.setButton(DialogInterface.BUTTON_NEGATIVE, "取消", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                cancelFlag = true;
                d.dismiss();
            }
        });
        try {
            pd.show();
        } catch (Throwable ignored) {
        }

        new Thread(new Runnable() {
            public void run() {
                File tmp = new File(getCacheDir(), "wtm_online_" + System.currentTimeMillis() + ".zip");
                File workDir = null;
                String err = null;
                String okMsg = null;
                Pack finalPack = null;
                boolean savedOnly = false;
                boolean dup = false;
                Pack dupPack = null;
                try {
                    Net.download(p.url, tmp, WtLive.REFERER, p.size, p.sha256, new Net.Progress() {
                        public boolean onProgress(final long done, final long total) {
                            ui.post(new Runnable() {
                                public void run() {
                                    try {
                                        pd.setMessage(total > 0
                                                ? "下载中 " + Kit.fmtSize(done) + " / " + Kit.fmtSize(total)
                                                : "下载中 " + Kit.fmtSize(done));
                                    } catch (Throwable ignored) {
                                    }
                                }
                            });
                            return cancelFlag;
                        }
                    });

                    if (saveOnly) {
                        String where = SaveToDownload.save(StoreActivity.this, tmp, p.title + ".zip");
                        savedOnly = true;
                        okMsg = "素材已保存到 " + where + "\n\n拷到电脑上解包、提取音频，再按手游 bank 重打包。";
                    } else {
                        ui.post(new Runnable() {
                            public void run() {
                                try {
                                    pd.setMessage("正在解压导入…");
                                } catch (Throwable ignored) {
                                }
                            }
                        });
                        workDir = new File(PackStore.tmpDir(StoreActivity.this),
                                "online_" + System.currentTimeMillis());
                        BankImporter.Result r = BankImporter.importFromZipFile(StoreActivity.this, tmp,
                                p.title + ".zip", workDir, null);
                        dupPack = PackStore.findByHash(StoreActivity.this, r.hash);
                        if (dupPack != null) {
                            dup = true;
                            finalPack = dupPack;
                        } else {
                            String name = PackStore.uniqueName(StoreActivity.this, p.title, null);
                            String note = (p.note == null ? "" : p.note);
                            finalPack = PackStore.save(StoreActivity.this, r, name, note,
                                    p.source + " · " + p.title);
                            Prefs.bumpImportCount(StoreActivity.this);
                            okMsg = "已导入语音包库：" + finalPack.name + "\n"
                                    + finalPack.count + " 个文件 · " + Kit.fmtSize(finalPack.size);
                        }
                    }
                } catch (Throwable t) {
                    String m = t.getMessage();
                    err = (m == null || m.length() == 0) ? t.toString() : m;
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                    if (workDir != null) Kit.deleteRec(workDir);
                }

                final String fErr = err;
                final String fOk = okMsg;
                final Pack fp = finalPack;
                final boolean fSaved = savedOnly;
                final boolean fDup = dup;
                final Pack fDupPack = dupPack;

                ui.post(new Runnable() {
                    public void run() {
                        downloading = false;
                        try {
                            pd.dismiss();
                        } catch (Throwable ignored) {
                        }
                        if (!Kit.alive(StoreActivity.this)) return;
                        if (fErr != null) {
                            Kit.msg(StoreActivity.this, "没成功", fErr);
                            return;
                        }
                        if (fSaved) {
                            Kit.msg(StoreActivity.this, "素材已保存", fOk);
                            return;
                        }
                        if (fDup) {
                            Kit.confirm(StoreActivity.this, "这个包库里已经有了",
                                    "内容一样：「" + fDupPack.name + "」，不再重复存一份。\n\n直接用它换包吗？",
                                    "用它换包", new Runnable() {
                                        public void run() {
                                            apply(fDupPack);
                                        }
                                    });
                            return;
                        }
                        if (fp != null) {
                            if (applyAfterAsk) {
                                Kit.confirm(StoreActivity.this, "导入成功", fOk + "\n\n现在换到游戏里吗？",
                                        "立即应用", new Runnable() {
                                            public void run() {
                                                apply(fp);
                                            }
                                        });
                            } else {
                                Kit.msg(StoreActivity.this, "导入成功", fOk);
                            }
                        }
                    }
                });
            }
        }, "wtm-download").start();
    }

    private void apply(final Pack p) {
        if (!Access.ready()) {
            Kit.msg(this, "还没有权限通道",
                    "语音包已经存进库里了。回首页启用 Shizuku（或 root）之后就能一键换包。");
            return;
        }
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("正在写入游戏目录…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        Installer.applyAsync(this, p, new Installer.Listener() {
            public void onProgress(String text) {
                try {
                    pd.setMessage(text);
                } catch (Throwable ignored) {
                }
            }

            public void onDone(boolean ok, String message) {
                try {
                    pd.dismiss();
                } catch (Throwable ignored) {
                }
                if (!Kit.alive(StoreActivity.this)) return;
                Kit.msg(StoreActivity.this, ok ? "换好了" : "没成功", message);
            }
        });
    }

    // ------------------------------------------------------------------ 适配器

    private final class OnlineAdapter extends BaseAdapter {

        private final int[] ACCENTS = new int[]{
                0xFFF5B324, 0xFF4DA3FF, 0xFF3ED598, 0xFFFF8A5B, 0xFFB98BFF, 0xFFFF6B9A
        };

        public int getCount() {
            return shown.size();
        }

        public Object getItem(int i) {
            return shown.get(i);
        }

        public long getItemId(int i) {
            return i;
        }

        public View getView(int pos, View convert, ViewGroup parent) {
            View v = convert;
            if (v == null) {
                v = LayoutInflater.from(StoreActivity.this)
                        .inflate(R.layout.item_online, parent, false);
            }
            OnlinePack p = shown.get(pos);
            TextView title = (TextView) v.findViewById(R.id.tvTitle);
            TextView meta = (TextView) v.findViewById(R.id.tvMeta);
            TextView desc = (TextView) v.findViewById(R.id.tvDesc);
            TextView action = (TextView) v.findViewById(R.id.tvAction);
            View accent = v.findViewById(R.id.vAccent);

            title.setText(p.title);

            StringBuilder m = new StringBuilder();
            if ("wtlive".equals(p.sourceType)) m.append("端游素材·需移植");
            else if ("github".equals(p.sourceType)) m.append("手游成品·GitHub");
            else m.append("手游成品");
            if (p.size > 0) m.append(" · ").append(Kit.fmtSize(p.size));
            if (p.note != null && p.note.length() > 0) m.append(" · ").append(p.note);
            meta.setText(m.toString());

            String d = p.desc == null ? "" : p.desc;
            if (d.length() > 0) {
                desc.setVisibility(View.VISIBLE);
                desc.setText(d);
            } else {
                desc.setVisibility(View.GONE);
            }
            action.setText("wtlive".equals(p.sourceType) ? "素材" : "下载");

            int color = ACCENTS[((p.url == null ? "" : p.url).hashCode() & 0x7fffffff) % ACCENTS.length];
            accent.setBackground(Kit.round(StoreActivity.this, color, 3, 0));
            return v;
        }
    }
}
