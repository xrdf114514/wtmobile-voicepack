package com.wtm.voicepack;

import android.content.Context;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * 语音包库：内容寻址存储。
 *
 * 目录结构（应用专属外部目录，不需要任何存储权限）：
 *   .../files/packs/<内容哈希前20位>/banks/*.bank
 *   .../files/packs/<内容哈希前20位>/meta.json
 *
 * 因为目录名就是内容哈希，同一个语音包无论导入多少次都只占一份空间；
 * 换包时是「清空游戏目录 + 从库里 cp」，库里不会再多一份副本。
 */
public final class PackStore {

    private PackStore() {
    }

    public static File baseDir(Context c) {
        File ext = c.getExternalFilesDir(null);
        if (ext == null) ext = c.getFilesDir();
        return ext;
    }

    public static File libraryDir(Context c) {
        File d = new File(baseDir(c), "packs");
        if (!d.exists()) //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        return d;
    }

    public static File tmpDir(Context c) {
        File d = new File(baseDir(c), "tmp");
        if (!d.exists()) //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        return d;
    }

    // ------------------------------------------------------------------ 查询

    public static List<Pack> list(Context c) {
        List<Pack> out = new ArrayList<Pack>();
        File[] dirs = libraryDir(c).listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (!d.isDirectory()) continue;
            Pack p = readMeta(d);
            if (p != null) out.add(p);
        }
        return out;
    }

    static Pack readMeta(File dir) {
        File m = new File(dir, "meta.json");
        if (!m.isFile()) return null;
        if (!new File(dir, "banks").isDirectory()) return null;
        try {
            Pack p = Pack.fromJson(new JSONObject(readText(m)));
            if (p.id == null || p.id.length() == 0) p.id = dir.getName();
            if (p.name == null || p.name.length() == 0) p.name = dir.getName();
            return p;
        } catch (Throwable t) {
            return null;
        }
    }

    public static Pack findById(Context c, String id) {
        if (id == null || id.length() == 0) return null;
        File d = new File(libraryDir(c), id);
        if (!d.isDirectory()) return null;
        return readMeta(d);
    }

    /** 按内容哈希找已有语音包（去重判定用）。 */
    public static Pack findByHash(Context c, String hash) {
        if (hash == null || hash.length() < 8) return null;
        File direct = new File(libraryDir(c), idOf(hash));
        Pack p = readMeta(direct);
        if (p != null) return p;
        for (Pack q : list(c)) {
            if (hash.equals(q.hash) || hash.startsWith(q.id)) return q;
        }
        return null;
    }

    public static String idOf(String hash) {
        return hash.length() > 20 ? hash.substring(0, 20) : hash;
    }

    // ------------------------------------------------------------------ 写入

    /**
     * 落库。已存在同内容语音包时直接返回已有条目（不再复制文件）。
     */
    public static Pack save(Context c, BankImporter.Result r, String name, String note, String source)
            throws Exception {
        String id = idOf(r.hash);
        Pack existing = findByHash(c, r.hash);
        if (existing != null) return existing;

        File dest = new File(libraryDir(c), id);
        if (dest.exists()) Kit.deleteRec(dest);
        if (!dest.mkdirs()) throw new Exception("创建语音包目录失败：" + dest);

        File banksDst = new File(dest, "banks");
        if (!r.banksDir.renameTo(banksDst)) {
            if (!copyDirRec(r.banksDir, banksDst)) throw new Exception("写入语音包库失败（空间不足？）");
            Kit.deleteRec(r.banksDir);
        }

        // 落库前再核对一次：目录里的文件数必须和 Result 对得上
        File[] actual = banksDst.listFiles();
        int actualCount = 0;
        long actualSize = 0;
        if (actual != null) {
            for (File f : actual) {
                if (f.isFile()) {
                    actualCount++;
                    actualSize += f.length();
                }
            }
        }
        if (actualCount == 0 || actualCount != r.names.size()) {
            Kit.deleteRec(dest);
            throw new Exception("写入语音包库不完整（应有 " + r.names.size() + " 个文件，实际 "
                    + actualCount + " 个）");
        }

        Pack p = new Pack();
        p.id = id;
        p.hash = r.hash;
        p.name = name;
        p.note = note == null ? "" : note;
        p.source = source == null ? "" : source;
        p.size = actualSize;
        p.count = actualCount;
        p.banks = new ArrayList<String>(r.names);
        p.addedAt = System.currentTimeMillis();
        p.favorite = false;
        if (!writeMeta(c, p)) {
            Kit.deleteRec(dest);   // 没有 meta 的目录会被当孤儿清掉，宁可失败也别留半成品
            throw new Exception("写语音包信息失败（存储空间不足？）");
        }
        return p;
    }

    /** 原子写 meta.json：先写 .tmp 再改名，避免写一半断电留下坏文件被当孤儿删掉。 */
    public static boolean writeMeta(Context c, Pack p) {
        File tmp = null;
        try {
            File dir = new File(libraryDir(c), p.id);
            if (!dir.exists() && !dir.mkdirs()) return false;
            File target = new File(dir, "meta.json");
            tmp = new File(dir, "meta.json.tmp");
            FileOutputStream fos = new FileOutputStream(tmp);
            OutputStreamWriter w = new OutputStreamWriter(fos, "UTF-8");
            w.write(p.toJson().toString(2));
            w.flush();
            fos.getFD().sync();
            w.close();
            if (!tmp.renameTo(target)) {
                // 某些文件系统不支持覆盖改名
                //noinspection ResultOfMethodCallIgnored
                target.delete();
                if (!tmp.renameTo(target)) return false;
            }
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            if (tmp != null && tmp.exists()) //noinspection ResultOfMethodCallIgnored
                tmp.delete();
        }
    }

    public static boolean rename(Context c, Pack p, String name, String note) {
        p.name = name;
        p.note = note == null ? "" : note;
        return writeMeta(c, p);
    }

    /** 编辑信息：名称 / 备注 / 标签。 */
    public static boolean edit(Context c, Pack p, String name, String note, List<String> tags) {
        p.name = name;
        p.note = note == null ? "" : note;
        p.tags = tags == null ? new ArrayList<String>() : tags;
        return writeMeta(c, p);
    }

    public static boolean setFavorite(Context c, Pack p, boolean fav) {
        p.favorite = fav;
        return writeMeta(c, p);
    }

    public static boolean markApplied(Context c, Pack p) {
        p.lastAppliedAt = System.currentTimeMillis();
        return writeMeta(c, p);
    }

    public static boolean delete(Context c, Pack p) {
        if (p == null) return false;
        Kit.deleteRec(new File(libraryDir(c), p.id));
        return true;
    }

    // ------------------------------------------------------------------ 存储

    public static long totalSize(Context c) {
        return Kit.dirSize(libraryDir(c));
    }

    public static int count(Context c) {
        return list(c).size();
    }

    /**
     * 清理：临时目录、没有 meta.json 的孤儿目录、残留的 zip 缓存。
     * 返回释放的字节数。
     */
    public static long cleanup(Context c) {
        long before = 0;
        long freed = 0;

        File tmp = tmpDir(c);
        before = Kit.dirSize(tmp);
        Kit.clearDir(tmp);

        File lib = libraryDir(c);
        File[] dirs = lib.listFiles();
        long now = System.currentTimeMillis();
        if (dirs != null) {
            for (File d : dirs) {
                if (!d.isDirectory()) continue;
                // 只清理「1 小时内没动过」的孤儿目录，避免误删正在写入的包
                if (now - d.lastModified() < 3600_000L) continue;
                if (readMeta(d) != null) continue;
                // 没有 meta：只有 banks 是空的才当垃圾删，里面还有文件就先留着（宁可不省空间也别丢包）
                File banksDir = new File(d, "banks");
                File[] inner = banksDir.listFiles();
                if (inner == null || inner.length == 0) {
                    long sz = Kit.dirSize(d);
                    Kit.deleteRec(d);
                    freed += sz;
                }
            }
        }

        File cache = c.getCacheDir();
        File[] cs = cache == null ? null : cache.listFiles();
        if (cs != null) {
            for (File f : cs) {
                if (f.getName().startsWith("wtm_src_")) {
                    if (f.isFile()) freed += f.length();
                    Kit.deleteRec(f);
                }
            }
        }

        //noinspection ResultOfMethodCallIgnored
        tmp.mkdirs();
        return freed + before;
    }

    /** 名字去重：重名时自动加 (2)(3)… */
    public static String uniqueName(Context c, String base, String ignoreId) {
        String name = Kit.safeName(base);
        if (name == null || name.length() == 0) name = "未命名语音包";
        List<Pack> all = list(c);
        String candidate = name;
        int i = 2;
        while (true) {
            boolean clash = false;
            for (Pack p : all) {
                if (ignoreId != null && ignoreId.equals(p.id)) continue;
                if (candidate.equalsIgnoreCase(p.name)) {
                    clash = true;
                    break;
                }
            }
            if (!clash) return candidate;
            candidate = name + " (" + i + ")";
            i++;
            if (i > 99) return name + "_" + System.currentTimeMillis();
        }
    }

    // ------------------------------------------------------------------ 文件工具

    private static boolean copyDirRec(File src, File dst) {
        if (!dst.exists() && !dst.mkdirs()) return false;
        File[] fs = src.listFiles();
        if (fs == null) return false;
        for (File f : fs) {
            if (f.isDirectory()) {
                if (!copyDirRec(f, new File(dst, f.getName()))) return false;
            } else if (!Kit.copyFile(f, new File(dst, f.getName()))) {
                return false;
            }
        }
        return true;
    }

    static String readText(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line).append('\n');
        r.close();
        return sb.toString();
    }
}
