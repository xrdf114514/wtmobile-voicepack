package com.wtm.voicepack;

import android.app.Activity;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 导入语音包：选 zip / bank → 提取到临时目录 → 算内容指纹去重 → 落库。 */
public final class ImportActivity extends Activity implements View.OnClickListener {

    private static final int REQ_PICK = 2101;

    /** 从「分享/打开方式/链接导入」传进来的文件。 */
    public static final String EXTRA_URIS = "extra_uris";

    private TextView btnPick, tvPicked, btnDoImport, tvLog, tvTitle, btnBack;
    private EditText etName, etNote;
    private CheckBox cbApply;
    private ProgressBar pb;

    private final List<Uri> picked = new ArrayList<Uri>();
    private final List<String> pickedNames = new ArrayList<String>();
    private String defaultName = "";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean busy = false;
    private boolean namingHintShown = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_import);

        tvTitle = (TextView) findViewById(R.id.tvTitle);
        btnBack = (TextView) findViewById(R.id.btnBack);
        btnPick = (TextView) findViewById(R.id.btnPick);
        tvPicked = (TextView) findViewById(R.id.tvPicked);
        btnDoImport = (TextView) findViewById(R.id.btnDoImport);
        etName = (EditText) findViewById(R.id.etName);
        etNote = (EditText) findViewById(R.id.etNote);
        cbApply = (CheckBox) findViewById(R.id.cbApply);
        pb = (ProgressBar) findViewById(R.id.pb);
        tvLog = (TextView) findViewById(R.id.tvLog);

        tvTitle.setText("导入语音包");
        btnBack.setOnClickListener(this);
        btnPick.setOnClickListener(this);
        View linkBtn = findViewById(R.id.btnLink);
        if (linkBtn != null) linkBtn.setOnClickListener(this);
        btnDoImport.setOnClickListener(this);

        // 从分享面板 / 文件管理器「打开方式」进来：直接带上文件
        try {
            java.util.ArrayList<android.net.Uri> incoming =
                    getIntent().getParcelableArrayListExtra(EXTRA_URIS);
            if (incoming != null && !incoming.isEmpty()) {
                for (android.net.Uri u : incoming) {
                    if (u == null) continue;
                    picked.add(u);
                    pickedNames.add(quickName(u));
                    takePersistable(u);
                }
                updatePicked();
            }
        } catch (Throwable ignored) {
        }

        if (!Access.ready()) {
            cbApply.setChecked(false);
            cbApply.setText("导入后立即应用（还没权限通道，先只入库）");
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnBack) {
            finish();
        } else if (id == R.id.btnPick) {
            pickFiles();
        } else if (id == R.id.btnLink) {
            startActivity(new Intent(this, LinkImportActivity.class));
        } else if (id == R.id.btnDoImport) {
            startImport();
        }
    }

    private void pickFiles() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(i, REQ_PICK);
        } catch (Throwable t) {
            // 有些设备没有文档选择器，退回旧的 GET_CONTENT
            Intent i2 = new Intent(Intent.ACTION_GET_CONTENT);
            i2.setType("*/*");
            i2.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(i2, REQ_PICK);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        picked.clear();
        pickedNames.clear();
        ClipData cp = data.getClipData();
        if (cp != null) {
            for (int i = 0; i < cp.getItemCount(); i++) {
                Uri u = cp.getItemAt(i).getUri();
                if (u != null) {
                    picked.add(u);
                    pickedNames.add(quickName(u));
                    takePersistable(u);
                }
            }
        } else if (data.getData() != null) {
            picked.add(data.getData());
            pickedNames.add(quickName(data.getData()));
            takePersistable(data.getData());
        }
        updatePicked();
    }

    /** 主线程里只做轻量取名（真正的 DISPLAY_NAME 在后台线程由导入器解析）。 */
    private String quickName(Uri u) {
        try {
            String last = u.getLastPathSegment();
            if (last != null && last.length() > 0) {
                int slash = last.lastIndexOf('/');
                return slash >= 0 ? last.substring(slash + 1) : last;
            }
        } catch (Throwable ignored) {
        }
        return "文件";
    }

    /** 让选中的文件在进程被杀后依然可读。 */
    private void takePersistable(Uri u) {
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Throwable ignored) {
            // GET_CONTENT 之类不支持的 provider，忽略即可
        }
    }

    private void updatePicked() {
        if (picked.isEmpty()) {
            tvPicked.setText("尚未选择文件");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("已选 ").append(picked.size()).append(" 个文件：\n");
        for (int i = 0; i < pickedNames.size(); i++) {
            if (i >= 5) {
                sb.append("…等 ").append(picked.size()).append(" 个");
                break;
            }
            sb.append("· ").append(pickedNames.get(i)).append('\n');
        }
        tvPicked.setText(sb.toString());

        String guess = "";
        for (String n : pickedNames) {
            String lower = n.toLowerCase(Locale.US);
            if (lower.endsWith(".zip")) {
                guess = n.substring(0, n.length() - 4);
                break;
            }
        }
        if (guess.length() == 0) {
            for (String n : pickedNames) {
                String lower = n.toLowerCase(Locale.US);
                if (lower.endsWith(".bank")) {
                    guess = n.substring(0, n.length() - 5);
                    break;
                }
            }
        }
        defaultName = Kit.safeName(guess);
        if (etName.getText().toString().trim().length() == 0 && defaultName.length() > 0) {
            etName.setText(defaultName);
        }
        // 第一次导入时提醒起名：包一多，名字就是唯一线索
        if (!namingHintShown && Prefs.importCount(this) == 0) {
            namingHintShown = true;
            Kit.msg(this, "给语音包起个自己的名字",
                    "上面的名称默认取自压缩包文件名，可以改成「作者-风格」，"
                            + "例如「某某-空战台词」「官方中文替换」。\n\n"
                            + "以后语音包多了，在语音包库里就靠名字和备注检索。\n"
                            + "同一个包重复导入只占一份空间，不用担心。");
        }
    }

    private void log(final String s) {
        ui.post(new Runnable() {
            public void run() {
                tvLog.setVisibility(View.VISIBLE);
                tvLog.append(s + "\n");
            }
        });
    }

    private void startImport() {
        if (busy) return;
        if (picked.isEmpty()) {
            Kit.toast(this, "先选一个语音包文件");
            return;
        }
        busy = true;
        btnDoImport.setEnabled(false);
        btnDoImport.setText("处理中…");
        pb.setVisibility(View.VISIBLE);
        tvLog.setVisibility(View.VISIBLE);
        tvLog.setText("");

        final String typed = etName.getText().toString().trim();
        final String note = etNote.getText().toString().trim();
        final boolean applyNow = cbApply.isChecked();
        final List<Uri> uris = new ArrayList<Uri>(picked);

        new Thread(new Runnable() {
            public void run() {
                final File workDir = new File(PackStore.tmpDir(ImportActivity.this),
                        "imp_" + System.currentTimeMillis());
                String err = null;
                String successMsg = null;
                Pack finalPack = null;
                boolean duplicate = false;
                Pack existingPack = null;
                try {
                    BankImporter.Result r = BankImporter.importAll(ImportActivity.this, uris, workDir,
                            new BankImporter.Progress() {
                                public void onStep(String text) {
                                    log(text);
                                }
                            });
                    existingPack = PackStore.findByHash(ImportActivity.this, r.hash);
                    if (existingPack != null) {
                        duplicate = true;
                        log("库里已有相同内容的语音包：「" + existingPack.name + "」，不再复制一份");
                    } else {
                        String name = typed.length() > 0 ? typed
                                : (r.sourceName.length() > 0 ? stripExt(r.sourceName) : "未命名语音包");
                        name = PackStore.uniqueName(ImportActivity.this, name, null);
                        finalPack = PackStore.save(ImportActivity.this, r, name, note, r.sourceName);
                        log("已入库：" + finalPack.name + "（" + finalPack.count + " 个文件，"
                                + Kit.fmtSize(finalPack.size) + "）");
                        Prefs.bumpImportCount(ImportActivity.this);
                        successMsg = "已导入：" + finalPack.name;
                    }
                } catch (Throwable t) {
                    err = t.getMessage() == null ? t.toString() : t.getMessage();
                    log("失败：" + err);
                } finally {
                    Kit.deleteRec(workDir);
                }

                final String fErr = err;
                final String fOk = successMsg;
                final Pack saved = finalPack;
                final boolean dup = duplicate;
                final Pack dupPack = existingPack;

                ui.post(new Runnable() {
                    public void run() {
                        busy = false;
                        pb.setVisibility(View.GONE);
                        btnDoImport.setEnabled(true);
                        btnDoImport.setText("开始导入");

                        if (!Kit.alive(ImportActivity.this)) return;
                        if (fErr != null) {
                            Kit.msg(ImportActivity.this, "导入失败", fErr);
                            return;
                        }
                        if (dup) {
                            Kit.confirm(ImportActivity.this, "这个语音包已经有了",
                                    "内容完全一样，「" + dupPack.name + "」已经在库里了，"
                                            + "为了不占两份空间，这次没有再存一份。\n\n"
                                            + "想直接用它换包吗？",
                                    "用它换包", new Runnable() {
                                        public void run() {
                                            applyFromImport(dupPack, true);
                                        }
                                    });
                            return;
                        }
                        Kit.toast(ImportActivity.this, fOk);
                        if (applyNow && saved != null) {
                            applyFromImport(saved, true);
                        } else {
                            finish();
                        }
                    }
                });
            }
        }, "wtm-import").start();
    }

    private void applyFromImport(final Pack p, final boolean finishAfter) {
        // 从分享面板 / 文件管理器「打开方式」进来：直接带上文件
        try {
            java.util.ArrayList<android.net.Uri> incoming =
                    getIntent().getParcelableArrayListExtra(EXTRA_URIS);
            if (incoming != null && !incoming.isEmpty()) {
                for (android.net.Uri u : incoming) {
                    if (u == null) continue;
                    picked.add(u);
                    pickedNames.add(quickName(u));
                    takePersistable(u);
                }
                updatePicked();
            }
        } catch (Throwable ignored) {
        }

        if (!Access.ready()) {
            Kit.msg(this, "已入库", "语音包已经保存到库里。\n当前没有权限通道，回首页启用 Shizuku/root 后就能换包。");
            finish();
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                final List<String> unknown = Installer.unknownBanks(ImportActivity.this);
                ui.post(new Runnable() {
                    public void run() {
                        if (!unknown.isEmpty()) {
                            Kit.confirm(ImportActivity.this, "目标目录里有别的语音文件",
                                    "换包会删掉目录里现有的 " + unknown.size() + " 个 .bank（不是本软件写入的）。\n\n"
                                            + "继续吗？", "继续覆盖", new Runnable() {
                                        public void run() {
                                            reallyApply(p);
                                        }
                                    });
                        } else {
                            reallyApply(p);
                        }
                    }
                });
            }
        }).start();
    }

    private void reallyApply(final Pack p) {
        final android.app.ProgressDialog pd = new android.app.ProgressDialog(this);
        pd.setMessage("正在写入游戏目录…");
        pd.setCancelable(false);
        try {
            pd.show();
        } catch (Throwable ignored) {
        }
        Installer.applyAsync(this, p, new Installer.Listener() {
            public void onProgress(String text) {
                try {
                    pd.setMessage(text);
                } catch (Throwable ignored) {
                }
            }

            public void onDone(boolean ok, String message) {
                try {
                    pd.dismiss();
                } catch (Throwable ignored) {
                }
                if (!Kit.alive(ImportActivity.this)) return;
                final boolean[] retrying = new boolean[]{false};
                android.app.AlertDialog dlg;
                if (ok) {
                    dlg = Kit.done(ImportActivity.this, "换好了", message, "启动游戏",
                            new Runnable() {
                                public void run() {
                                    if (!GameLauncher.launch(ImportActivity.this)) {
                                        GameLauncher.explain(ImportActivity.this);
                                    }
                                }
                            });
                } else {
                    dlg = Kit.failed(ImportActivity.this, "写入了库，但换包没成功", message,
                            new Runnable() {
                                public void run() {
                                    retrying[0] = true;
                                    reallyApply(p);
                                }
                            }, "启动游戏", new Runnable() {
                                public void run() {
                                    if (!GameLauncher.launch(ImportActivity.this)) {
                                        GameLauncher.explain(ImportActivity.this);
                                    }
                                }
                            });
                }
                dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                    public void onDismiss(android.content.DialogInterface d) {
                        if (!retrying[0]) finish();
                    }
                });
            }
        });
    }

    private static String stripExt(String name) {
        int dot = name.lastIndexOf('.');
        if (dot > 0) return name.substring(0, dot);
        return name;
    }
}
