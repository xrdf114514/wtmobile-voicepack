package com.wtm.voicepack;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** 把文件存到手机「下载」目录（不需要存储权限：Android 10+ 走 MediaStore）。 */
public final class SaveToDownload {

    private SaveToDownload() {
    }

    /** 存到下载目录并返回 content:// Uri（用于「分享给其它应用」）；失败返回 null。 */
    public static Uri saveAndGetUri(Context c, File src, String displayName) {
        try {
            if (Build.VERSION.SDK_INT < 29) return null;   // 旧系统没有 MediaStore Downloads，分享走不了 content://
            String name = Kit.safeName(displayName);
            if (name.length() == 0) name = "voicepack.zip";
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/zip");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return null;
            OutputStream os = c.getContentResolver().openOutputStream(uri);
            if (os == null) return null;
            InputStream in = new java.io.FileInputStream(src);
            try {
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                os.flush();
            } finally {
                try {
                    in.close();
                } catch (Throwable ignored) {
                }
                try {
                    os.close();
                } catch (Throwable ignored) {
                }
            }
            return uri;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 返回给用户看的路径。 */
    public static String save(Context c, File src, String displayName) throws Exception {
        String name = Kit.safeName(displayName);
        if (name.length() == 0) name = "voicepack.zip";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/zip");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("无法在下载目录创建文件");
            OutputStream os = c.getContentResolver().openOutputStream(uri);
            if (os == null) throw new Exception("无法写入下载目录");
            InputStream in = new java.io.FileInputStream(src);
            try {
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                os.flush();
            } finally {
                try {
                    in.close();
                } catch (Throwable ignored) {
                }
                try {
                    os.close();
                } catch (Throwable ignored) {
                }
            }
            return "Download/" + name;
        }
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = new File("/sdcard/Download"); //noinspection ResultOfMethodCallIgnored
        if (!dir.exists()) //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
        File dst = new File(dir, name);
        if (!Kit.copyFile(src, dst)) throw new Exception("写入下载目录失败");
        return dst.getAbsolutePath();
    }
}
