package com.wtm.voicepack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 从「视频简介 / 分享文本 / 剪贴板」里抽链接和提取码。
 *
 * 说明：网盘链接（百度/夸克/阿里/微云/115/天翼）都需要登录且带风控，
 * 这个软件不会去破解它们，只做识别 + 复制 + 跳转，下载靠用户自己在网盘里点；
 * 直链（.zip/.bank 或 GitHub Release 之类的对象存储）才能由本软件直接下载导入。
 */
public final class LinkIn {

    public static final class Link {
        public String url = "";
        public String kind = "other";   // direct/baidu/quark/alipan/lanzou/123pan/weiyun/115/tianyi/other
        public String pwd = "";

        public boolean isNetdisk() {
            return !"direct".equals(kind) && !"other".equals(kind);
        }

        public boolean isDirect() {
            return "direct".equals(kind);
        }

        public String label() {
            String k = kind;
            if ("direct".equals(k)) return "直链文件";
            if ("baidu".equals(k)) return "百度网盘";
            if ("quark".equals(k)) return "夸克网盘";
            if ("alipan".equals(k)) return "阿里云盘";
            if ("lanzou".equals(k)) return "蓝奏云";
            if ("123pan".equals(k)) return "123云盘";
            if ("weiyun".equals(k)) return "腾讯微云";
            if ("115".equals(k)) return "115 网盘";
            if ("tianyi".equals(k)) return "天翼云盘";
            return "链接";
        }

        /** 复制用的完整分享信息（带提取码）。 */
        public String fullText() {
            if (pwd != null && pwd.length() > 0) {
                return url + "\n提取码：" + pwd;
            }
            return url;
        }
    }

    private static final Pattern URL = Pattern.compile("https?://[^\\s\"'<>，。、；;）)】\\]]+");
    private static final Pattern[] PWD_PATTERNS = new Pattern[]{
            Pattern.compile("[?&]pwd=([A-Za-z0-9]{4,8})", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(?:提取码|提取碼|密码|密碼|访问码|訪問碼|口令|code)\\s*[:：=]?\\s*([A-Za-z0-9]{4,8})",
                    Pattern.CASE_INSENSITIVE)
    };

    private LinkIn() {
    }

    public static List<Link> parse(String text) {
        List<Link> out = new ArrayList<Link>();
        if (text == null) return out;
        String pwd = guessPwd(text);
        Matcher m = URL.matcher(text);
        while (m.find()) {
            String url = trim(m.group());
            if (url.length() < 10) continue;
            if (contains(out, url)) continue;
            Link l = new Link();
            l.url = url;
            l.kind = detectKind(url);
            l.pwd = pwd;
            out.add(l);
            if (out.size() >= 20) break;
        }
        return out;
    }

    private static boolean contains(List<Link> list, String url) {
        for (Link l : list) if (l.url.equals(url)) return true;
        return false;
    }

    static String trim(String url) {
        String s = url.trim();
        while (s.length() > 0) {
            char c = s.charAt(s.length() - 1);
            if (c == '.' || c == ',' || c == ')' || c == '）' || c == '。' || c == '，'
                    || c == ';' || c == '；' || c == '"' || c == '\'' || c == ']' || c == '】') {
                s = s.substring(0, s.length() - 1);
            } else {
                break;
            }
        }
        return s;
    }

    public static String guessPwd(String text) {
        if (text == null) return "";
        for (Pattern p : PWD_PATTERNS) {
            Matcher m = p.matcher(text);
            if (m.find()) return m.group(1);
        }
        return "";
    }

    public static String host(String url) {
        try {
            String h = new java.net.URL(url).getHost();
            return h == null ? "" : h.toLowerCase(Locale.US);
        } catch (Throwable t) {
            return "";
        }
    }

    public static String detectKind(String url) {
        String h = host(url);
        if (h.length() == 0) return "other";
        if (h.endsWith("baidu.com")) return "baidu";
        if (h.contains("quark")) return "quark";
        if (h.contains("alipan") || h.contains("aliyundrive")) return "alipan";
        if (h.contains("lanzou") || h.contains("lanzt") || h.contains("lanzn") || h.contains("lanzh")) {
            return "lanzou";
        }
        if (h.contains("123pan") || h.contains("123684") || h.contains("123865")
                || h.contains("123912") || h.contains("123pan")) {
            return "123pan";
        }
        if (h.contains("weiyun")) return "weiyun";
        if (h.contains("115.com") || h.contains("115cdn") || h.contains("115img")) return "115";
        if (h.contains("189.cn")) return "tianyi";

        String path = url.toLowerCase(Locale.US);
        int q = path.indexOf('?');
        if (q > 0) path = path.substring(0, q);
        if (path.endsWith(".zip") || path.endsWith(".bank") || path.endsWith(".7z")
                || path.endsWith(".rar")) {
            return "direct";
        }
        return "other";
    }

    /** 给用户的下一步提示。 */
    public static String hint(Link l) {
        if ("direct".equals(l.kind)) {
            return "这是直链文件，可以直接下载并导入（下完自动抽取 .bank）。";
        }
        if ("lanzou".equals(l.kind)) {
            return "蓝奏云一般不需要登录：打开后点下载，下载完回到本软件「导入语音包」选择那个 zip；"
                    + "或者在文件管理器里长按 zip →「打开方式」→ 本软件。";
        }
        if ("baidu".equals(l.kind)) {
            return "百度网盘需要先登录：打开链接 → 输入提取码 → 保存到我的网盘 → 下载；"
                    + "下载完在文件管理器里长按 zip →「打开方式」→ 本软件，或者直接「分享」到本软件。";
        }
        if ("quark".equals(l.kind)) {
            return "夸克网盘：打开链接 → 保存/下载；下载完用本软件打开那个 zip，或从网盘里「分享」到本软件。";
        }
        if ("alipan".equals(l.kind)) {
            return "阿里云盘：先保存再下载；下载完用本软件打开那个 zip，或从云盘里分享到本软件。";
        }
        if ("weiyun".equals(l.kind) || "115".equals(l.kind) || "tianyi".equals(l.kind)
                || "123pan".equals(l.kind)) {
            return "这个网盘要登录/可能限速：打开后下载，下载完用本软件打开那个 zip，"
                    + "或者从网盘 App 里「分享」到本软件。";
        }
        return "普通链接：如果是文件直链可以直接下载；打不开就用浏览器看看。";
    }

    public static boolean looksLikeArchiveUrl(String url) {
        String u = url.toLowerCase(Locale.US);
        int q = u.indexOf('?');
        if (q > 0) u = u.substring(0, q);
        return u.endsWith(".zip") || u.endsWith(".bank") || u.endsWith(".7z") || u.endsWith(".rar");
    }
}
